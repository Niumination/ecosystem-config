# KAI Avatar Model Folder

Tempatkan model avatar produksi di folder ini.

Nama default yang dicari jika URL memakai `?model=default`:

```text
public/models/kai-avatar.glb
```

Jalankan frontend R3F:

```bash
cd kai-assistant/frontend-r3f
npm install
npm run dev
```

Buka dengan fallback avatar:

```text
http://localhost:5173
```

Buka dengan model default:

```text
http://localhost:5173?model=default
```

Buka dengan model custom:

```text
http://localhost:5173?model=/models/nama-model.glb
```

Model harus mengikuti kontrak morph target di `../../assets/avatar-contract/kai_morph_contract.json`.
