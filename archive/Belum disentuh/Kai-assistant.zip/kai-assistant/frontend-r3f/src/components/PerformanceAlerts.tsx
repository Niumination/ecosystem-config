import type { PerformanceMetrics } from '../hooks/usePerformanceMetrics'

type PerformanceAlertsProps = {
  latencyMs: number
  ttsBufferMs?: number
  adaptiveJitterBufferMs?: number
  networkJitterMs?: number
  underrunEstimate?: number
  performanceMetrics?: PerformanceMetrics
}

type AlertLevel = 'ok' | 'warn' | 'bad'

type AlertItem = {
  id: string
  label: string
  value: string
  level: AlertLevel
  hint: string
}

function levelClass(level: AlertLevel) {
  return `alert-item ${level}`
}

export function PerformanceAlerts({
  latencyMs,
  ttsBufferMs,
  adaptiveJitterBufferMs,
  networkJitterMs,
  underrunEstimate,
  performanceMetrics
}: PerformanceAlertsProps) {
  const fps = performanceMetrics?.fps || 0
  const frameMs = performanceMetrics?.frameMs || 0
  const longFrames = performanceMetrics?.longFrameCount || 0
  const buffer = ttsBufferMs || 0
  const jitter = networkJitterMs || 0
  const target = adaptiveJitterBufferMs || 0
  const underruns = underrunEstimate || 0

  const alerts: AlertItem[] = [
    {
      id: 'fps',
      label: 'FPS',
      value: fps ? String(fps) : '-',
      level: fps === 0 ? 'warn' : fps < 24 ? 'bad' : fps < 45 ? 'warn' : 'ok',
      hint: fps < 45 ? 'Kurangi kualitas render, texture, atau post-processing.' : 'Render loop sehat.'
    },
    {
      id: 'latency',
      label: 'Latency',
      value: latencyMs ? `${latencyMs} ms` : '-',
      level: latencyMs > 1800 ? 'bad' : latencyMs > 900 ? 'warn' : 'ok',
      hint: latencyMs > 900 ? 'Cek LLM/TTS backend dan round-trip WebSocket.' : 'Latency respons normal.'
    },
    {
      id: 'buffer',
      label: 'Audio Buffer',
      value: buffer ? `${buffer} ms` : '-',
      level: buffer > 0 && buffer < 70 ? 'bad' : buffer > 0 && buffer < 130 ? 'warn' : 'ok',
      hint: buffer > 0 && buffer < 130 ? 'Buffer rendah; risiko gap audio meningkat.' : 'Buffer audio cukup.'
    },
    {
      id: 'jitter',
      label: 'Network Jitter',
      value: jitter ? `${jitter} ms` : '-',
      level: jitter > 120 ? 'bad' : jitter > 55 ? 'warn' : 'ok',
      hint: jitter > 55 ? 'Koneksi/chunk arrival tidak stabil; adaptive buffer akan naik.' : 'Jitter rendah.'
    },
    {
      id: 'underrun',
      label: 'Underrun',
      value: String(underruns),
      level: underruns > 8 ? 'bad' : underruns > 2 ? 'warn' : 'ok',
      hint: underruns > 2 ? 'Audio buffer terlalu sering rendah; naikkan jitter buffer atau optimasi decode.' : 'Tidak ada indikasi underrun signifikan.'
    },
    {
      id: 'frame',
      label: 'Frame Time',
      value: frameMs ? `${frameMs} ms` : '-',
      level: frameMs > 50 ? 'bad' : frameMs > 28 ? 'warn' : 'ok',
      hint: frameMs > 28 ? 'Main thread berat; cek GLB complexity dan UI updates.' : 'Frame time normal.'
    },
    {
      id: 'longframes',
      label: 'Long Frames',
      value: String(longFrames),
      level: longFrames > 20 ? 'bad' : longFrames > 5 ? 'warn' : 'ok',
      hint: longFrames > 5 ? 'Ada frame >50ms; bisa menyebabkan stutter animasi/audio.' : 'Stutter rendah.'
    },
    {
      id: 'target',
      label: 'Jitter Target',
      value: target ? `${target} ms` : '-',
      level: target > 420 ? 'warn' : 'ok',
      hint: target > 420 ? 'Adaptive buffer tinggi; jaringan atau backend chunking tidak stabil.' : 'Target buffer wajar.'
    }
  ]

  const worst: AlertLevel = alerts.some(item => item.level === 'bad') ? 'bad' : alerts.some(item => item.level === 'warn') ? 'warn' : 'ok'
  const title = worst === 'bad' ? 'Needs Attention' : worst === 'warn' ? 'Watch' : 'Healthy'

  return (
    <div className={`performance-alerts ${worst}`}>
      <div className="alerts-head">
        <h3>Performance Alerts</h3>
        <span>{title}</span>
      </div>
      <div className="alerts-list">
        {alerts.map(item => (
          <div className={levelClass(item.level)} key={item.id} title={item.hint}>
            <i />
            <div>
              <b>{item.label}</b>
              <small>{item.hint}</small>
            </div>
            <strong>{item.value}</strong>
          </div>
        ))}
      </div>
    </div>
  )
}
