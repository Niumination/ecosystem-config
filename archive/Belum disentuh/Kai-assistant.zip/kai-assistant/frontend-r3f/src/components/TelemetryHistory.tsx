import type { TelemetryItem, TelemetrySummary } from '../hooks/useTelemetryHistory'

type TelemetryHistoryProps = {
  items: TelemetryItem[]
  summary?: TelemetrySummary
  loading: boolean
  error?: string
  onRefresh: () => void
}

const SERIES = [
  { key: 'fps', label: 'FPS', color: '#6dffb1' },
  { key: 'latencyMs', label: 'Latency', color: '#ffd36d' },
  { key: 'networkJitterMs', label: 'Jitter', color: '#ff6d8a' },
  { key: 'bufferedMs', label: 'Buffer', color: '#27d7ff' }
]

function numeric(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function valuesFor(items: TelemetryItem[], key: string): number[] {
  return items.map(item => numeric(item.metrics?.[key])).filter((value): value is number => value !== undefined)
}

function Sparkline({ values, color }: { values: number[]; color: string }) {
  if (values.length < 2) {
    return <div className="spark-empty">not enough data</div>
  }
  const width = 220
  const height = 54
  const min = Math.min(...values)
  const max = Math.max(...values)
  const range = Math.max(1e-6, max - min)
  const points = values.map((value, index) => {
    const x = (index / Math.max(1, values.length - 1)) * width
    const y = height - ((value - min) / range) * (height - 8) - 4
    return `${x.toFixed(1)},${y.toFixed(1)}`
  }).join(' ')

  return (
    <svg className="sparkline" viewBox={`0 0 ${width} ${height}`} role="img">
      <polyline points={points} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <line x1="0" x2={width} y1={height - 4} y2={height - 4} stroke="rgba(159,179,209,.22)" />
    </svg>
  )
}

export function TelemetryHistory({ items, summary, loading, error, onRefresh }: TelemetryHistoryProps) {
  return (
    <div className="telemetry-history">
      <div className="telemetry-head">
        <div>
          <h3>Telemetry History</h3>
          <p>{summary?.count || items.length || 0} snapshots</p>
        </div>
        <button type="button" onClick={onRefresh} disabled={loading}>{loading ? 'Loading…' : 'Refresh'}</button>
      </div>

      {error ? <p className="voice-error">Telemetry: {error}</p> : null}

      <div className="telemetry-grid">
        {SERIES.map(series => {
          const values = valuesFor(items, series.key)
          const latest = values.length ? values[values.length - 1] : undefined
          const avg = summary?.averages?.[series.key]
          const max = summary?.max?.[series.key]
          return (
            <div className="telemetry-card" key={series.key}>
              <div className="telemetry-card-title">
                <span style={{ color: series.color }}>{series.label}</span>
                <b>{latest !== undefined ? Math.round(latest) : '-'}</b>
              </div>
              <Sparkline values={values} color={series.color} />
              <div className="telemetry-stats">
                <span>avg {avg !== undefined ? Math.round(avg) : '-'}</span>
                <span>max {max !== undefined ? Math.round(max) : '-'}</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
