import { OrbitControls, useGLTF } from '@react-three/drei'
import { Canvas, useFrame } from '@react-three/fiber'
import { Suspense, useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import type { AvatarCommand } from '../types/kai'

const DEFAULT_MODEL_URL = '/models/kai-avatar.glb'

const VISEME_NAMES = new Set(['AA', 'E', 'IH', 'OH', 'OU', 'FV', 'L', 'MBP', 'WQ', 'CH', 'TH', 'NDT', 'R'])

const VISUAL_MORPH_DEFAULTS: Record<string, number> = {
  smile: 0,
  frown: 0,
  angry: 0,
  confused: 0,
  browUp: 0,
  browDown: 0,
  surprised: 0,
  blink_L: 0,
  blink_R: 0,
  AA: 0,
  E: 0,
  IH: 0,
  OH: 0,
  OU: 0,
  FV: 0,
  L: 0,
  MBP: 0,
  WQ: 0,
  CH: 0,
  TH: 0,
  NDT: 0,
  R: 0
}

type KaiAvatarProps = {
  command: AvatarCommand
  modelUrl?: string
  /** Optional mapping from KAI contract names to model-specific morph target names. */
  morphMap?: Record<string, string>
}

function setMorph(mesh: THREE.Mesh, name: string, value: number, lerp = 0.22) {
  if (!mesh.morphTargetDictionary || !mesh.morphTargetInfluences) return
  const index = mesh.morphTargetDictionary[name]
  if (index === undefined) return
  mesh.morphTargetInfluences[index] = THREE.MathUtils.lerp(mesh.morphTargetInfluences[index] || 0, value, lerp)
}

function ModelAvatar({ command, modelUrl = DEFAULT_MODEL_URL, morphMap = {} }: KaiAvatarProps) {
  const groupRef = useRef<THREE.Group>(null)
  const gltf = useGLTF(modelUrl)
  const morphTargets = useMemo(() => ({ ...VISUAL_MORPH_DEFAULTS, ...(command.morphs || {}) }), [command.morphs])

  useFrame(({ clock }) => {
    const group = groupRef.current
    if (!group) return
    group.rotation.y = Math.sin(clock.elapsedTime * 0.35) * 0.035
    group.position.y = Math.sin(clock.elapsedTime * 1.4) * 0.018

    const blink = Math.sin(clock.elapsedTime * 2.25) > 0.985 ? 1 : 0
    const visemeName = command.viseme?.name || 'REST'
    const visemeWeight = command.viseme?.weight || 0

    group.traverse(obj => {
      const mesh = obj as THREE.Mesh
      if (!mesh.isMesh) return

      for (const key of Object.keys(VISUAL_MORPH_DEFAULTS)) {
        // Visemes release slightly slower than expressions to avoid chattering mouth shapes.
        setMorph(mesh, morphMap[key] || key, 0, VISEME_NAMES.has(key) ? 0.16 : 0.18)
      }
      for (const [key, value] of Object.entries(morphTargets)) setMorph(mesh, morphMap[key] || key, value, 0.2)
      if (visemeName !== 'REST') {
        // Active viseme attacks faster; release is handled by the reset pass above.
        setMorph(mesh, morphMap[visemeName] || visemeName, visemeWeight, 0.48)
      }
      setMorph(mesh, morphMap.blink_L || 'blink_L', blink, 0.65)
      setMorph(mesh, morphMap.blink_R || 'blink_R', blink, 0.65)
    })
  })

  return <primitive ref={groupRef} object={gltf.scene} position={[0, -1.15, 0]} scale={1.35} />
}

function FallbackAvatar({ command }: { command: AvatarCommand }) {
  const headRef = useRef<THREE.Group>(null)
  const mouthRef = useRef<THREE.Mesh>(null)
  const leftEyeRef = useRef<THREE.Mesh>(null)
  const rightEyeRef = useRef<THREE.Mesh>(null)
  const smoothMouthRef = useRef(0)
  const smoothSmileRef = useRef(0)
  const smile = command.morphs?.smile || 0
  const confused = command.morphs?.confused || 0
  const visemeWeight = command.viseme?.weight || 0

  useFrame(({ clock }) => {
    const t = clock.elapsedTime
    if (headRef.current) {
      headRef.current.position.y = Math.sin(t * 1.6) * 0.035
      headRef.current.rotation.y = Math.sin(t * 0.7) * 0.07
      headRef.current.rotation.z = confused * 0.08
    }
    const mouthOpen = command.viseme?.name !== 'REST' ? visemeWeight : 0
    smoothMouthRef.current = THREE.MathUtils.lerp(smoothMouthRef.current, mouthOpen, mouthOpen > smoothMouthRef.current ? 0.42 : 0.18)
    smoothSmileRef.current = THREE.MathUtils.lerp(smoothSmileRef.current, smile, 0.16)
    if (mouthRef.current) {
      mouthRef.current.scale.set(1 + smoothSmileRef.current * 0.35, 0.22 + smoothMouthRef.current * 0.9, 1)
      mouthRef.current.position.y = -0.34 - smoothMouthRef.current * 0.05
    }
    const blink = Math.sin(t * 2.1) > 0.988 ? 0.08 : 1
    if (leftEyeRef.current) leftEyeRef.current.scale.y = blink
    if (rightEyeRef.current) rightEyeRef.current.scale.y = blink
  })

  return (
    <group position={[0, -0.5, 0]}>
      <group ref={headRef}>
        <mesh position={[0, 0.2, 0]}>
          <capsuleGeometry args={[0.58, 0.62, 12, 28]} />
          <meshStandardMaterial color="#c98772" roughness={0.62} metalness={0.02} />
        </mesh>
        <mesh position={[0, 0.82, -0.03]} rotation={[0.05, 0, 0]}>
          <sphereGeometry args={[0.66, 32, 18, 0, Math.PI * 2, 0, Math.PI * 0.55]} />
          <meshStandardMaterial color="#071d40" roughness={0.35} metalness={0.08} />
        </mesh>
        <mesh position={[-0.22, 0.25, 0.53]} ref={leftEyeRef}>
          <sphereGeometry args={[0.075, 16, 12]} />
          <meshStandardMaterial color="#9cecff" emissive="#27d7ff" emissiveIntensity={0.8} />
        </mesh>
        <mesh position={[0.22, 0.25, 0.53]} ref={rightEyeRef}>
          <sphereGeometry args={[0.075, 16, 12]} />
          <meshStandardMaterial color="#9cecff" emissive="#27d7ff" emissiveIntensity={0.8} />
        </mesh>
        <mesh position={[0, -0.32, 0.56]} ref={mouthRef}>
          <sphereGeometry args={[0.16, 24, 12]} />
          <meshStandardMaterial color="#35121b" roughness={0.5} />
        </mesh>
      </group>
      <mesh position={[0, -1.0, 0]}>
        <capsuleGeometry args={[0.72, 1.3, 8, 24]} />
        <meshStandardMaterial color="#111d34" roughness={0.42} metalness={0.16} />
      </mesh>
      <mesh position={[-0.38, -0.7, 0.57]} rotation={[0, 0, -0.25]}>
        <boxGeometry args={[0.05, 1.15, 0.03]} />
        <meshStandardMaterial color="#27d7ff" emissive="#27d7ff" emissiveIntensity={1.4} />
      </mesh>
      <mesh position={[0.38, -0.7, 0.57]} rotation={[0, 0, 0.25]}>
        <boxGeometry args={[0.05, 1.15, 0.03]} />
        <meshStandardMaterial color="#8c6cff" emissive="#8c6cff" emissiveIntensity={1.2} />
      </mesh>
    </group>
  )
}

function AvatarScene({ command, modelUrl, morphMap }: KaiAvatarProps) {
  const useModel = Boolean(modelUrl)

  useEffect(() => {
    if (modelUrl) useGLTF.preload(modelUrl)
  }, [modelUrl])

  return (
    <>
      <color attach="background" args={["#070b14"]} />
      <fog attach="fog" args={["#070b14", 4, 10]} />
      <ambientLight intensity={0.8} />
      <directionalLight position={[2.5, 3.2, 4]} intensity={2.3} color="#d9f8ff" />
      <pointLight position={[-2.2, 1.8, 2]} intensity={2.0} color="#8c6cff" />
      <Suspense fallback={<FallbackAvatar command={command} />}>
        {useModel ? <ModelAvatar command={command} modelUrl={modelUrl} morphMap={morphMap} /> : <FallbackAvatar command={command} />}
      </Suspense>
      <mesh position={[0, -1.9, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[2.2, 64]} />
        <meshStandardMaterial color="#08101e" roughness={0.7} metalness={0.1} />
      </mesh>
      <OrbitControls enablePan={false} enableZoom={false} minPolarAngle={Math.PI / 2.8} maxPolarAngle={Math.PI / 2.05} />
    </>
  )
}

export function KaiAvatar({ command, modelUrl, morphMap }: KaiAvatarProps) {
  return (
    <Canvas camera={{ position: [0, 0.15, 4.2], fov: 38 }} dpr={[1, 2]}>
      <AvatarScene command={command} modelUrl={modelUrl} morphMap={morphMap} />
    </Canvas>
  )
}
