import { FormEvent, useState } from 'react'
import type { ChatMessage, ConnectionState } from '../types/kai'

type ChatPanelProps = {
  connection: ConnectionState
  sessionId: string
  messages: ChatMessage[]
  onSend: (text: string) => void
  onHistory: () => void
}

export function ChatPanel({ connection, sessionId, messages, onSend, onHistory }: ChatPanelProps) {
  const [text, setText] = useState('')

  function submit(event: FormEvent) {
    event.preventDefault()
    const trimmed = text.trim()
    if (!trimmed) return
    onSend(trimmed)
    setText('')
  }

  return (
    <aside className="panel chat-panel">
      <div className="brand-block">
        <span className={`status-pill ${connection}`}>
          <i /> {connection}
        </span>
        <h1>KAI</h1>
        <p>React Three Fiber avatar interface</p>
        <small title={sessionId}>{sessionId ? `session ${sessionId.slice(0, 8)}` : 'new session'}</small>
      </div>

      <div className="messages">
        {messages.map((message, index) => (
          <div className={`message ${message.role === 'user' ? 'user' : 'assistant'}`} key={`${message.created_at || index}-${message.role}`}>
            <small>{message.role === 'user' ? 'Anda' : 'KAI'}{message.emotion ? ` · ${message.emotion}` : ''}</small>
            <span>{message.content}</span>
          </div>
        ))}
      </div>

      <form className="composer" onSubmit={submit}>
        <input value={text} onChange={event => setText(event.target.value)} placeholder="Tulis pesan untuk KAI…" />
        <button type="button" onClick={onHistory} title="Ambil riwayat session">↺</button>
        <button type="submit">Kirim</button>
      </form>
    </aside>
  )
}
