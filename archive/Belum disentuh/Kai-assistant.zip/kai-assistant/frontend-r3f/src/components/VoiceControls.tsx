type VoiceControlsProps = {
  sttSupported: boolean
  ttsSupported: boolean
  listening: boolean
  speaking: boolean
  autoSpeak: boolean
  language: string
  ttsMode: 'browser' | 'backend' | 'stream' | 'binary'
  error?: string
  onLanguageChange: (lang: string) => void
  onAutoSpeakChange: (enabled: boolean) => void
  onTtsModeChange: (mode: 'browser' | 'backend' | 'stream' | 'binary') => void
  onListen: () => void
  onStopSpeaking: () => void
}

export function VoiceControls({
  sttSupported,
  ttsSupported,
  listening,
  speaking,
  autoSpeak,
  language,
  ttsMode,
  error,
  onLanguageChange,
  onAutoSpeakChange,
  onTtsModeChange,
  onListen,
  onStopSpeaking
}: VoiceControlsProps) {
  return (
    <div className="voice-controls">
      <div className="voice-row">
        <button type="button" onClick={onListen} disabled={!sttSupported || listening}>
          {listening ? 'Listening…' : '🎙 Push to talk'}
        </button>
        <button type="button" onClick={onStopSpeaking} disabled={(ttsMode === 'browser' && !ttsSupported) || !speaking}>
          {speaking ? 'Stop voice' : 'TTS idle'}
        </button>
      </div>
      <div className="voice-row compact">
        <label>
          Language
          <select value={language} onChange={event => onLanguageChange(event.target.value)}>
            <option value="id-ID">id-ID</option>
            <option value="en-US">en-US</option>
            <option value="ja-JP">ja-JP</option>
            <option value="ko-KR">ko-KR</option>
          </select>
        </label>
        <label>
          TTS mode
          <select value={ttsMode} onChange={event => onTtsModeChange(event.target.value as 'browser' | 'backend' | 'stream' | 'binary')}>
            <option value="browser">browser</option>
            <option value="backend">backend WAV</option>
            <option value="stream">stream WS JSON</option>
            <option value="binary">stream WS binary</option>
          </select>
        </label>
      </div>
      <div className="voice-row compact">
        <label className="toggle">
          <input type="checkbox" checked={autoSpeak} onChange={event => onAutoSpeakChange(event.target.checked)} />
          Auto speak
        </label>
      </div>
      <div className="voice-status">
        <span className={sttSupported ? 'ok' : 'bad'}>STT {sttSupported ? 'ready' : 'unavailable'}</span>
        <span className={ttsSupported ? 'ok' : 'bad'}>TTS {ttsSupported ? 'ready' : 'unavailable'}</span>
      </div>
      {error ? <p className="voice-error">{error}</p> : null}
    </div>
  )
}
