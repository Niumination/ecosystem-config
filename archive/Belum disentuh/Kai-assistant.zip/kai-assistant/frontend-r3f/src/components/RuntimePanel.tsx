import type { PerformanceMetrics } from '../hooks/usePerformanceMetrics'
import type { TelemetryItem, TelemetrySummary } from '../hooks/useTelemetryHistory'
import { PerformanceAlerts } from './PerformanceAlerts'
import { TelemetryHistory } from './TelemetryHistory'
import type { AvatarCommand, KaiEvent } from '../types/kai'

type RuntimePanelProps = {
  command: AvatarCommand
  latencyMs: number
  lastEvent?: KaiEvent
  modelUrl?: string
  ttsProvider?: string
  ttsDurationMs?: number
  ttsBufferMs?: number
  adaptiveJitterBufferMs?: number
  networkJitterMs?: number
  receivedChunks?: number
  underrunEstimate?: number
  performanceMetrics?: PerformanceMetrics
  telemetryItems?: TelemetryItem[]
  telemetrySummary?: TelemetrySummary
  telemetryLoading?: boolean
  telemetryError?: string
  onTelemetryRefresh?: () => void
}

export function RuntimePanel({ command, latencyMs, lastEvent, modelUrl, ttsProvider, ttsDurationMs, ttsBufferMs, adaptiveJitterBufferMs, networkJitterMs, receivedChunks, underrunEstimate, performanceMetrics, telemetryItems = [], telemetrySummary, telemetryLoading = false, telemetryError, onTelemetryRefresh = () => undefined }: RuntimePanelProps) {
  const emotion = command.emotion?.name || 'neutral'
  const intensity = Math.round((command.emotion?.intensity || 0) * 100)
  const viseme = command.viseme?.name || 'REST'

  return (
    <aside className="panel runtime-panel">
      <h2>Runtime</h2>
      <div className="kv"><span>Renderer</span><b>Three.js / R3F</b></div>
      <div className="kv"><span>Avatar</span><b>{modelUrl ? 'GLB/VRM' : 'Fallback 3D'}</b></div>
      <div className="kv"><span>Emotion</span><b>{emotion}</b></div>
      <div className="meter"><i style={{ width: `${intensity}%` }} /></div>
      <div className="kv"><span>Viseme</span><b>{viseme}</b></div>
      <div className="kv"><span>Latency</span><b>{latencyMs} ms</b></div>
      <div className="kv"><span>TTS provider</span><b>{ttsProvider || 'browser/default'}</b></div>
      <div className="kv"><span>TTS duration</span><b>{ttsDurationMs ? `${ttsDurationMs} ms` : '-'}</b></div>
      <div className="kv"><span>Audio buffer</span><b>{ttsBufferMs ? `${ttsBufferMs} ms` : '-'}</b></div>
      <div className="kv"><span>Jitter target</span><b>{adaptiveJitterBufferMs ? `${adaptiveJitterBufferMs} ms` : '-'}</b></div>
      <div className="kv"><span>Network jitter</span><b>{networkJitterMs ? `${networkJitterMs} ms` : '-'}</b></div>
      <div className="kv"><span>Audio chunks</span><b>{receivedChunks ?? '-'}</b></div>
      <div className="kv"><span>Underrun estimate</span><b>{underrunEstimate ?? '-'}</b></div>
      <div className="kv"><span>FPS</span><b>{performanceMetrics?.fps || '-'}</b></div>
      <div className="kv"><span>Frame time</span><b>{performanceMetrics ? `${performanceMetrics.frameMs} ms` : '-'}</b></div>
      <div className="kv"><span>Long frames</span><b>{performanceMetrics?.longFrameCount ?? '-'}</b></div>
      <div className="kv"><span>JS heap</span><b>{performanceMetrics?.memoryMb ? `${performanceMetrics.memoryMb} MB` : '-'}</b></div>
      <PerformanceAlerts
        latencyMs={latencyMs}
        ttsBufferMs={ttsBufferMs}
        adaptiveJitterBufferMs={adaptiveJitterBufferMs}
        networkJitterMs={networkJitterMs}
        underrunEstimate={underrunEstimate}
        performanceMetrics={performanceMetrics}
      />
      <TelemetryHistory
        items={telemetryItems}
        summary={telemetrySummary}
        loading={telemetryLoading}
        error={telemetryError}
        onRefresh={onTelemetryRefresh}
      />
      <div>
        <p className="muted">Morph command</p>
        <pre>{JSON.stringify(command, null, 2)}</pre>
      </div>
      <div>
        <p className="muted">Last event</p>
        <pre>{JSON.stringify(lastEvent || {}, null, 2)}</pre>
      </div>
    </aside>
  )
}
