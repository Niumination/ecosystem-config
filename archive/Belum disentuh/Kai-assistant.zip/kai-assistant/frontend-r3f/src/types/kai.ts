export type EmotionName = 'neutral' | 'happy' | 'focused' | 'concerned' | 'confused' | 'angry' | 'surprised'

export type EmotionState = {
  name: EmotionName | string
  intensity: number
}

export type VisemeName =
  | 'REST'
  | 'AA'
  | 'E'
  | 'IH'
  | 'OH'
  | 'OU'
  | 'FV'
  | 'L'
  | 'MBP'
  | 'WQ'
  | 'CH'
  | 'TH'
  | 'NDT'
  | 'R'
  | string

export type VisemeState = {
  name: VisemeName
  weight: number
}

export type AvatarCommand = {
  session_id?: string
  emotion?: EmotionState
  morphs?: Record<string, number>
  viseme?: VisemeState
}

export type KaiEvent = {
  type: string
  ts?: number
  session_id?: string
  text?: string
  index?: number
  message?: string
  emotion?: EmotionState
  morphs?: Record<string, number>
  viseme?: VisemeState
  visemes?: Array<{ at_ms: number; name: string; weight: number }>
  provider?: string
  mime_type?: string
  audio_base64?: string
  audio_blob?: Blob
  chunk_id?: string
  byte_length?: number
  duration_ms?: number
  sample_rate?: number
  messages?: ChatMessage[]
  capabilities?: Record<string, unknown>
}

export type ChatMessage = {
  id?: number
  session_id?: string
  role: 'user' | 'assistant' | 'kai' | string
  content: string
  emotion?: string | null
  created_at?: number
}

export type ConnectionState = 'connecting' | 'connected' | 'offline-demo' | 'error'
