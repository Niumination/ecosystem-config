import { useEffect, useMemo, useState } from 'react'
import { ChatPanel } from './components/ChatPanel'
import { KaiAvatar } from './components/KaiAvatar'
import { RuntimePanel } from './components/RuntimePanel'
import { VoiceControls } from './components/VoiceControls'
import { useBackendTTS } from './hooks/useBackendTTS'
import { useBrowserVoice } from './hooks/useBrowserVoice'
import { useKaiSocket } from './hooks/useKaiSocket'
import { useMorphMap } from './hooks/useMorphMap'
import { usePerformanceMetrics } from './hooks/usePerformanceMetrics'
import { useStreamingAudioQueue } from './hooks/useStreamingAudioQueue'
import { useTelemetryHistory } from './hooks/useTelemetryHistory'
import { useTelemetryReporter } from './hooks/useTelemetryReporter'
import type { VisemeState } from './types/kai'
import './styles/app.css'

function queryParam(name: string): string | undefined {
  const params = new URLSearchParams(window.location.search)
  return params.get(name) || undefined
}

function modelUrlFromQuery(): string | undefined {
  const model = queryParam('model')
  if (model === 'default') return '/models/kai-avatar.glb'
  return model
}

export default function App() {
  const modelUrl = modelUrlFromQuery()
  const morphMapUrl = queryParam('morphMap')
  const morphMap = useMorphMap(morphMapUrl)
  const perf = usePerformanceMetrics()
  const kai = useKaiSocket()
  const telemetryHistory = useTelemetryHistory(kai.sessionId, Boolean(kai.sessionId))
  const voice = useBrowserVoice()
  const [backendViseme, setBackendViseme] = useState<VisemeState>({ name: 'REST', weight: 0 })
  const [streamViseme, setStreamViseme] = useState<VisemeState>({ name: 'REST', weight: 0 })
  const backendTTS = useBackendTTS({ onViseme: setBackendViseme })
  const streamAudio = useStreamingAudioQueue({ onViseme: setStreamViseme })
  const [language, setLanguage] = useState(localStorage.getItem('kai_r3f_language') || 'id-ID')
  const [autoSpeak, setAutoSpeak] = useState(localStorage.getItem('kai_r3f_auto_speak') !== 'false')
  const [ttsMode, setTtsMode] = useState<'browser' | 'backend' | 'stream' | 'binary'>((localStorage.getItem('kai_r3f_tts_mode') as 'browser' | 'backend' | 'stream' | 'binary') || 'browser')

  useEffect(() => {
    localStorage.setItem('kai_r3f_language', language)
  }, [language])

  useEffect(() => {
    localStorage.setItem('kai_r3f_auto_speak', String(autoSpeak))
  }, [autoSpeak])

  useEffect(() => {
    localStorage.setItem('kai_r3f_tts_mode', ttsMode)
    kai.setAudioTransport(ttsMode === 'binary' ? 'binary' : 'json')
  }, [kai.setAudioTransport, ttsMode])

  useEffect(() => {
    if (!autoSpeak) return
    if (kai.lastEvent?.type === 'assistant.start' && kai.lastEvent.text) {
      if (ttsMode === 'backend') backendTTS.speak(kai.lastEvent.text, language)
      else if (ttsMode === 'browser') voice.speak(kai.lastEvent.text, language)
      else streamAudio.reset()
    }
  }, [autoSpeak, kai.lastEvent, language, ttsMode, voice.speak, backendTTS.speak, streamAudio.reset])

  useEffect(() => {
    if (!autoSpeak || (ttsMode !== 'stream' && ttsMode !== 'binary')) return
    const event = kai.lastEvent
    if (ttsMode === 'stream') {
      if (event?.type !== 'voice.audio.chunk') return
      if (!event.audio_base64 || !event.mime_type || !event.visemes) return
      streamAudio.enqueue({
        id: `${event.session_id || 'session'}:${event.index ?? 0}`,
        mime_type: event.mime_type,
        audio_base64: event.audio_base64,
        visemes: event.visemes
      })
    }
    if (ttsMode === 'binary') {
      if (event?.type !== 'voice.audio.binary.chunk') return
      if (!event.audio_blob || !event.mime_type || !event.visemes) return
      streamAudio.enqueue({
        id: event.chunk_id || `${event.session_id || 'session'}:${event.index ?? 0}`,
        mime_type: event.mime_type,
        audio_blob: event.audio_blob,
        visemes: event.visemes
      })
    }
  }, [autoSpeak, kai.lastEvent, streamAudio, ttsMode])

  const effectiveAvatarCommand = useMemo(() => {
    if (ttsMode === 'backend') {
      return { ...kai.avatarCommand, viseme: backendViseme }
    }
    if (ttsMode === 'stream' || ttsMode === 'binary') {
      return { ...kai.avatarCommand, viseme: streamViseme }
    }
    return kai.avatarCommand
  }, [backendViseme, kai.avatarCommand, streamViseme, ttsMode])

  const audioMetrics = useMemo(() => ({
    ttsMode,
    latencyMs: kai.latencyMs,
    queued: streamAudio.queued,
    scheduled: streamAudio.scheduled,
    bufferedMs: streamAudio.bufferedMs,
    adaptiveJitterBufferMs: streamAudio.adaptiveJitterBufferMs,
    networkJitterMs: streamAudio.networkJitterMs,
    receivedChunks: streamAudio.receivedChunks,
    underrunEstimate: streamAudio.underrunEstimate
  }), [kai.latencyMs, streamAudio.adaptiveJitterBufferMs, streamAudio.bufferedMs, streamAudio.networkJitterMs, streamAudio.queued, streamAudio.receivedChunks, streamAudio.scheduled, streamAudio.underrunEstimate, ttsMode])

  useTelemetryReporter({
    enabled: true,
    sessionId: kai.sessionId,
    performanceMetrics: perf,
    audioMetrics
  })

  return (
    <div className="app-shell">
      <ChatPanel
        connection={kai.connection}
        sessionId={kai.sessionId}
        messages={kai.messages}
        onSend={kai.sendText}
        onHistory={kai.requestHistory}
      />

      <main className="panel stage-panel">
        <div className="stage-hud">
          <span>KAI Avatar Runtime</span>
          <b>{modelUrl ? modelUrl : 'fallback geometry avatar'}</b>
        </div>
        <KaiAvatar command={effectiveAvatarCommand} modelUrl={modelUrl} morphMap={morphMap} />
        <VoiceControls
          sttSupported={voice.sttSupported}
          ttsSupported={voice.ttsSupported}
          listening={voice.listening}
          speaking={voice.speaking || backendTTS.playing || streamAudio.playing}
          autoSpeak={autoSpeak}
          language={language}
          ttsMode={ttsMode}
          error={voice.error || backendTTS.error || streamAudio.error}
          onLanguageChange={setLanguage}
          onAutoSpeakChange={setAutoSpeak}
          onTtsModeChange={setTtsMode}
          onListen={() => voice.listenOnce(kai.sendText, language)}
          onStopSpeaking={() => {
            voice.stopSpeaking()
            backendTTS.stop()
            streamAudio.reset()
          }}
        />
      </main>

      <RuntimePanel
        command={effectiveAvatarCommand}
        latencyMs={kai.latencyMs}
        lastEvent={kai.lastEvent}
        modelUrl={modelUrl}
        ttsProvider={ttsMode === 'backend' ? backendTTS.provider : (ttsMode === 'stream' || ttsMode === 'binary') ? `websocket-${ttsMode}/${streamAudio.engine} queued:${streamAudio.queued}` : 'browser-speechSynthesis'}
        ttsDurationMs={ttsMode === 'backend' ? backendTTS.durationMs : 0}
        ttsBufferMs={(ttsMode === 'stream' || ttsMode === 'binary') ? streamAudio.bufferedMs : 0}
        adaptiveJitterBufferMs={(ttsMode === 'stream' || ttsMode === 'binary') ? streamAudio.adaptiveJitterBufferMs : 0}
        networkJitterMs={(ttsMode === 'stream' || ttsMode === 'binary') ? streamAudio.networkJitterMs : 0}
        receivedChunks={(ttsMode === 'stream' || ttsMode === 'binary') ? streamAudio.receivedChunks : 0}
        underrunEstimate={(ttsMode === 'stream' || ttsMode === 'binary') ? streamAudio.underrunEstimate : 0}
        performanceMetrics={perf}
        telemetryItems={telemetryHistory.items}
        telemetrySummary={telemetryHistory.summary}
        telemetryLoading={telemetryHistory.loading}
        telemetryError={telemetryHistory.error}
        onTelemetryRefresh={telemetryHistory.refresh}
      />
    </div>
  )
}
