import { useEffect, useRef, useState } from 'react'

export type PerformanceMetrics = {
  fps: number
  frameMs: number
  memoryMb?: number
  longFrameCount: number
}

export function usePerformanceMetrics(): PerformanceMetrics {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({ fps: 0, frameMs: 0, longFrameCount: 0 })
  const framesRef = useRef(0)
  const lastReportRef = useRef(performance.now())
  const lastFrameRef = useRef(performance.now())
  const longFrameCountRef = useRef(0)

  useEffect(() => {
    let raf = 0
    const tick = () => {
      const now = performance.now()
      const frameMs = now - lastFrameRef.current
      lastFrameRef.current = now
      framesRef.current += 1
      if (frameMs > 50) longFrameCountRef.current += 1

      const elapsed = now - lastReportRef.current
      if (elapsed >= 750) {
        const fps = Math.round((framesRef.current * 1000) / elapsed)
        const memory = (performance as Performance & { memory?: { usedJSHeapSize: number } }).memory
        setMetrics({
          fps,
          frameMs: Math.round(frameMs * 10) / 10,
          longFrameCount: longFrameCountRef.current,
          memoryMb: memory ? Math.round(memory.usedJSHeapSize / 1024 / 1024) : undefined
        })
        framesRef.current = 0
        lastReportRef.current = now
      }
      raf = window.requestAnimationFrame(tick)
    }
    raf = window.requestAnimationFrame(tick)
    return () => window.cancelAnimationFrame(raf)
  }, [])

  return metrics
}
