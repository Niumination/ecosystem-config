import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { AvatarCommand, ChatMessage, ConnectionState, KaiEvent } from '../types/kai'

export type UseKaiSocketOptions = {
  backend?: string
  autoConnect?: boolean
}

export type UseKaiSocketResult = {
  connection: ConnectionState
  sessionId: string
  messages: ChatMessage[]
  lastEvent?: KaiEvent
  avatarCommand: AvatarCommand
  latencyMs: number
  sendText: (text: string) => void
  setAudioTransport: (mode: 'json' | 'binary') => void
  requestHistory: () => void
  reconnect: () => void
}

const STORAGE_SESSION = 'kai_r3f_session_id'
const STORAGE_BACKEND = 'kai_r3f_backend'

function defaultBackend(): string {
  const params = new URLSearchParams(window.location.search)
  const fromQuery = params.get('backend')
  if (fromQuery) {
    localStorage.setItem(STORAGE_BACKEND, fromQuery)
    return fromQuery
  }
  return localStorage.getItem(STORAGE_BACKEND) || 'localhost:8000'
}

function demoReply(text: string): string {
  const lower = text.toLowerCase()
  if (lower.includes('avatar') || lower.includes('3d')) {
    return 'Frontend React Three Fiber siap menerima model GLB atau VRM dengan morph target ekspresi dan viseme. Jika model belum tersedia, fallback avatar 3D tetap ditampilkan.'
  }
  if (lower.includes('deploy') || lower.includes('tauri')) {
    return 'Untuk deployment native, build PWA/React frontend, bundle backend Python sebagai sidecar, lalu package menggunakan Tauri ke DMG, AppImage, DEB, atau RPM.'
  }
  return 'Saya KAI dalam mode demo offline. Sambungkan backend FastAPI untuk mendapatkan WebSocket, memory SQLite, dan adapter LLM.'
}

export function useKaiSocket(options: UseKaiSocketOptions = {}): UseKaiSocketResult {
  const backend = options.backend || defaultBackend()
  const [connection, setConnection] = useState<ConnectionState>('connecting')
  const [sessionId, setSessionId] = useState(localStorage.getItem(STORAGE_SESSION) || '')
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: 'Halo, saya KAI versi React Three Fiber. Saya siap menampilkan avatar GLB/VRM dengan morph target real-time.'
    }
  ])
  const [lastEvent, setLastEvent] = useState<KaiEvent>()
  const [avatarCommand, setAvatarCommand] = useState<AvatarCommand>({
    emotion: { name: 'neutral', intensity: 0.3 },
    morphs: { smile: 0.18 },
    viseme: { name: 'REST', weight: 0 }
  })
  const [latencyMs, setLatencyMs] = useState(0)
  const wsRef = useRef<WebSocket | null>(null)
  const lastSendRef = useRef(0)
  const reconnectTimerRef = useRef<number | null>(null)
  const pendingBinaryMetaRef = useRef<KaiEvent | null>(null)

  const wsUrl = useMemo(() => {
    const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
    const query = sessionId ? `?session_id=${encodeURIComponent(sessionId)}` : ''
    return `${proto}://${backend}/ws/kai${query}`
  }, [backend, sessionId])

  const applyEvent = useCallback((event: KaiEvent) => {
    setLastEvent(event)

    if (event.type === 'session.ready' && event.session_id) {
      setConnection('connected')
      setSessionId(event.session_id)
      localStorage.setItem(STORAGE_SESSION, event.session_id)
    }

    if (event.type === 'avatar.command') {
      setAvatarCommand({
        session_id: event.session_id,
        emotion: event.emotion,
        morphs: event.morphs,
        viseme: event.viseme
      })
    }

    if (event.type === 'assistant.start') {
      setAvatarCommand({
        session_id: event.session_id,
        emotion: event.emotion,
        morphs: event.morphs,
        viseme: { name: 'AA', weight: 0.6 }
      })
      setMessages(prev => [...prev, { role: 'assistant', content: '' }])
    }

    if (event.type === 'assistant.delta' && typeof event.text === 'string') {
      setMessages(prev => {
        const next = [...prev]
        const last = next[next.length - 1]
        if (last?.role === 'assistant') {
          next[next.length - 1] = { ...last, content: last.content + event.text }
          return next
        }
        return [...next, { role: 'assistant', content: event.text || '' }]
      })
    }

    if (event.type === 'assistant.done') {
      setLatencyMs(Math.round(performance.now() - lastSendRef.current))
      setAvatarCommand({
        session_id: event.session_id,
        emotion: { name: 'neutral', intensity: 0.3 },
        morphs: { smile: 0.18 },
        viseme: { name: 'REST', weight: 0 }
      })
    }

    if (event.type === 'session.history' && event.messages) {
      setMessages(event.messages)
    }
  }, [])

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN || wsRef.current?.readyState === WebSocket.CONNECTING) return
    setConnection('connecting')
    try {
      const ws = new WebSocket(wsUrl)
      wsRef.current = ws
      ws.binaryType = 'blob'
      ws.onopen = () => {
        setConnection('connected')
        const mode = localStorage.getItem('kai_r3f_tts_mode') === 'binary' ? 'binary' : 'json'
        ws.send(JSON.stringify({ type: 'session.audio_transport', mode }))
      }
      ws.onmessage = message => {
        if (typeof message.data === 'string') {
          const event = JSON.parse(message.data) as KaiEvent
          if (event.type === 'voice.audio.chunk.meta') pendingBinaryMetaRef.current = event
          applyEvent(event)
          return
        }

        const meta = pendingBinaryMetaRef.current
        pendingBinaryMetaRef.current = null
        const blob = message.data instanceof Blob ? message.data : new Blob([message.data], { type: meta?.mime_type || 'audio/wav' })
        applyEvent({
          ...(meta || {}),
          type: 'voice.audio.binary.chunk',
          audio_blob: blob,
          mime_type: meta?.mime_type || blob.type || 'audio/wav'
        })
      }
      ws.onerror = () => setConnection('error')
      ws.onclose = () => {
        setConnection('offline-demo')
        if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current)
        reconnectTimerRef.current = window.setTimeout(connect, 2500)
      }
    } catch {
      setConnection('offline-demo')
    }
  }, [applyEvent, wsUrl])

  useEffect(() => {
    if (options.autoConnect === false) return
    connect()
    return () => {
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current)
      wsRef.current?.close()
    }
  }, [connect, options.autoConnect])

  const sendText = useCallback((text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    setMessages(prev => [...prev, { role: 'user', content: trimmed }])
    lastSendRef.current = performance.now()

    const ws = wsRef.current
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'user.text', text: trimmed }))
      return
    }

    const reply = demoReply(trimmed)
    setConnection('offline-demo')
    setAvatarCommand({ emotion: { name: 'focused', intensity: 0.65 }, morphs: { smile: 0.25, browUp: 0.25 }, viseme: { name: 'AA', weight: 0.8 } })
    setMessages(prev => [...prev, { role: 'assistant', content: reply }])
    window.setTimeout(() => {
      setAvatarCommand({ emotion: { name: 'neutral', intensity: 0.3 }, morphs: { smile: 0.18 }, viseme: { name: 'REST', weight: 0 } })
      setLatencyMs(Math.round(performance.now() - lastSendRef.current))
    }, 900)
  }, [])

  const setAudioTransport = useCallback((mode: 'json' | 'binary') => {
    const ws = wsRef.current
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'session.audio_transport', mode }))
    }
  }, [])

  const requestHistory = useCallback(() => {
    const ws = wsRef.current
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'session.history' }))
  }, [])

  return {
    connection,
    sessionId,
    messages,
    lastEvent,
    avatarCommand,
    latencyMs,
    sendText,
    setAudioTransport,
    requestHistory,
    reconnect: connect
  }
}
