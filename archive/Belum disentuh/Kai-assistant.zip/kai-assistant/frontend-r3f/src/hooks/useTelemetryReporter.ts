import { useEffect } from 'react'
import type { PerformanceMetrics } from './usePerformanceMetrics'

type TelemetryInput = {
  enabled?: boolean
  backend?: string
  sessionId?: string
  performanceMetrics: PerformanceMetrics
  audioMetrics: Record<string, unknown>
}

function defaultBackend(): string {
  const params = new URLSearchParams(window.location.search)
  return params.get('backend') || localStorage.getItem('kai_r3f_backend') || 'localhost:8000'
}

export function useTelemetryReporter({ enabled = true, backend = defaultBackend(), sessionId, performanceMetrics, audioMetrics }: TelemetryInput) {
  useEffect(() => {
    if (!enabled) return
    const interval = window.setInterval(() => {
      fetch(`http://${backend}/api/telemetry/snapshot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session_id: sessionId,
          source: 'kai-frontend-r3f',
          timestamp_ms: performance.now(),
          metrics: {
            ...performanceMetrics,
            ...audioMetrics
          }
        })
      }).catch(() => undefined)
    }, 5000)
    return () => window.clearInterval(interval)
  }, [audioMetrics, backend, enabled, performanceMetrics, sessionId])
}
