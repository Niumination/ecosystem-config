import { useCallback, useEffect, useRef, useState } from 'react'
import type { VisemeState } from '../types/kai'

type AudioChunk = {
  id: string
  mime_type: string
  audio_base64?: string
  audio_blob?: Blob
  visemes: Array<{ at_ms: number; name: string; weight: number }>
}

type ScheduledVisemeTrack = {
  chunkId: string
  startAt: number
  endAt: number
  visemes: Array<{ at: number; name: string; weight: number }>
}

type Options = {
  /** Initial playout buffer to reduce underruns/jitter for streaming chunks. */
  jitterBufferMs?: number
  /** Lower adaptive jitter buffer bound. */
  minJitterBufferMs?: number
  /** Upper adaptive jitter buffer bound. */
  maxJitterBufferMs?: number
  onViseme?: (viseme: VisemeState) => void
  onStart?: (chunk: AudioChunk) => void
  onEnd?: () => void
}

type AudioContextConstructor = typeof AudioContext

declare global {
  interface Window {
    webkitAudioContext?: AudioContextConstructor
  }
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i)
  return bytes.buffer
}

async function chunkToArrayBuffer(chunk: AudioChunk): Promise<ArrayBuffer> {
  if (chunk.audio_blob) return chunk.audio_blob.arrayBuffer()
  return base64ToArrayBuffer(chunk.audio_base64 || '')
}

function createAudioContext(): AudioContext | undefined {
  const Ctor = window.AudioContext || window.webkitAudioContext
  if (!Ctor) return undefined
  return new Ctor()
}

export function useStreamingAudioQueue(options: Options = {}) {
  const initialBufferMs = options.jitterBufferMs ?? 180
  const minBufferMs = options.minJitterBufferMs ?? 110
  const maxBufferMs = options.maxJitterBufferMs ?? 520

  const [playing, setPlaying] = useState(false)
  const [queued, setQueued] = useState(0)
  const [error, setError] = useState<string>()
  const [scheduledCount, setScheduledCount] = useState(0)
  const [bufferedMs, setBufferedMs] = useState(0)
  const [adaptiveJitterBufferMs, setAdaptiveJitterBufferMs] = useState(initialBufferMs)
  const [networkJitterMs, setNetworkJitterMs] = useState(0)
  const [receivedChunks, setReceivedChunks] = useState(0)
  const [underrunEstimate, setUnderrunEstimate] = useState(0)

  const queueRef = useRef<AudioChunk[]>([])
  const seenRef = useRef<Set<string>>(new Set())
  const sourcesRef = useRef<AudioBufferSourceNode[]>([])
  const callbacksRef = useRef<Options>({})
  const audioCtxRef = useRef<AudioContext | null>(null)
  const nextStartTimeRef = useRef(0)
  const processingRef = useRef(false)
  const activeSourcesRef = useRef(0)
  const tracksRef = useRef<ScheduledVisemeTrack[]>([])
  const rafRef = useRef<number | null>(null)
  const lastVisemeKeyRef = useRef('REST:0')

  const adaptiveJitterBufferMsRef = useRef(initialBufferMs)
  const networkJitterMsRef = useRef(0)
  const lastArrivalMsRef = useRef<number | null>(null)
  const smoothedIntervalMsRef = useRef<number | null>(null)
  const smoothedDeviationMsRef = useRef(0)

  useEffect(() => {
    callbacksRef.current = options
  }, [options])

  useEffect(() => {
    adaptiveJitterBufferMsRef.current = clamp(initialBufferMs, minBufferMs, maxBufferMs)
    setAdaptiveJitterBufferMs(adaptiveJitterBufferMsRef.current)
  }, [initialBufferMs, maxBufferMs, minBufferMs])

  const currentJitterSeconds = useCallback(() => adaptiveJitterBufferMsRef.current / 1000, [])

  const updateAdaptiveJitter = useCallback(() => {
    const now = performance.now()
    const last = lastArrivalMsRef.current
    lastArrivalMsRef.current = now
    if (last === null) return

    const interval = now - last
    const previousInterval = smoothedIntervalMsRef.current
    if (previousInterval === null) {
      smoothedIntervalMsRef.current = interval
      return
    }

    // Exponential moving averages: network interval and absolute deviation.
    const alpha = 0.12
    const beta = 0.18
    const deviation = Math.abs(interval - previousInterval)
    const nextInterval = previousInterval + alpha * (interval - previousInterval)
    const nextDeviation = smoothedDeviationMsRef.current + beta * (deviation - smoothedDeviationMsRef.current)

    smoothedIntervalMsRef.current = nextInterval
    smoothedDeviationMsRef.current = nextDeviation
    networkJitterMsRef.current = nextDeviation

    // Base buffer plus jitter allowance. Rise faster than fall to avoid underruns.
    const target = clamp(initialBufferMs + nextDeviation * 2.4, minBufferMs, maxBufferMs)
    const current = adaptiveJitterBufferMsRef.current
    const adapt = target > current ? 0.28 : 0.045
    const next = current + adapt * (target - current)
    adaptiveJitterBufferMsRef.current = next

    setNetworkJitterMs(Math.round(nextDeviation))
    setAdaptiveJitterBufferMs(Math.round(next))
  }, [initialBufferMs, maxBufferMs, minBufferMs])

  const ensureAudioContext = useCallback(async () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = createAudioContext() || null
      if (audioCtxRef.current) nextStartTimeRef.current = audioCtxRef.current.currentTime + currentJitterSeconds()
    }
    const ctx = audioCtxRef.current
    if (!ctx) throw new Error('WebAudio AudioContext is not available in this browser')
    if (ctx.state === 'suspended') await ctx.resume()
    return ctx
  }, [currentJitterSeconds])

  const emitViseme = useCallback((viseme: VisemeState) => {
    const key = `${viseme.name}:${Math.round((viseme.weight || 0) * 1000)}`
    if (key === lastVisemeKeyRef.current) return
    lastVisemeKeyRef.current = key
    callbacksRef.current.onViseme?.(viseme)
  }, [])

  const emitRest = useCallback(() => {
    emitViseme({ name: 'REST', weight: 0 })
  }, [emitViseme])

  const stopVisemeLoop = useCallback(() => {
    if (rafRef.current !== null) window.cancelAnimationFrame(rafRef.current)
    rafRef.current = null
  }, [])

  const startVisemeLoop = useCallback(() => {
    if (rafRef.current !== null) return

    const tick = () => {
      const ctx = audioCtxRef.current
      if (!ctx) {
        rafRef.current = null
        return
      }

      const now = ctx.currentTime
      const tracks = tracksRef.current
      let active: VisemeState | undefined

      for (const track of tracks) {
        if (now < track.startAt || now > track.endAt + 0.08) continue
        let selected = track.visemes[0]
        for (const item of track.visemes) {
          if (item.at <= now) selected = item
          else break
        }
        if (selected && selected.at <= now) {
          active = { name: selected.name, weight: selected.weight }
        }
        break
      }

      if (active) emitViseme(active)
      else if (activeSourcesRef.current === 0) emitRest()

      tracksRef.current = tracksRef.current.filter(track => track.endAt + 1.0 > now)
      const bufferNowMs = Math.max(0, Math.round((nextStartTimeRef.current - now) * 1000))
      setBufferedMs(bufferNowMs)
      if ((activeSourcesRef.current > 0 || queueRef.current.length > 0) && bufferNowMs < 35) {
        setUnderrunEstimate(value => value + 1)
      }

      if (activeSourcesRef.current > 0 || queueRef.current.length > 0 || tracksRef.current.length > 0 || processingRef.current) {
        rafRef.current = window.requestAnimationFrame(tick)
      } else {
        rafRef.current = null
      }
    }

    rafRef.current = window.requestAnimationFrame(tick)
  }, [emitRest, emitViseme])

  const addVisemeTrack = useCallback((chunk: AudioChunk, startAt: number, duration: number) => {
    const visemes = chunk.visemes.length > 0
      ? chunk.visemes.map(item => ({ at: startAt + item.at_ms / 1000, name: item.name, weight: item.weight }))
      : [{ at: startAt, name: 'REST', weight: 0 }]

    tracksRef.current.push({
      chunkId: chunk.id,
      startAt,
      endAt: startAt + duration,
      visemes
    })
    tracksRef.current.sort((a, b) => a.startAt - b.startAt)
    startVisemeLoop()
  }, [startVisemeLoop])

  const processQueue = useCallback(async () => {
    if (processingRef.current) return
    processingRef.current = true

    try {
      const ctx = await ensureAudioContext()
      while (queueRef.current.length > 0) {
        const chunk = queueRef.current.shift()!
        setQueued(queueRef.current.length)

        const raw = await chunkToArrayBuffer(chunk)
        const decoded = await ctx.decodeAudioData(raw.slice(0))
        const source = ctx.createBufferSource()
        source.buffer = decoded
        const gain = ctx.createGain()
        source.connect(gain)
        gain.connect(ctx.destination)

        const hasNothingScheduled = activeSourcesRef.current === 0 && sourcesRef.current.length === 0 && nextStartTimeRef.current <= ctx.currentTime
        const leadTime = hasNothingScheduled ? currentJitterSeconds() : 0.045
        const startAt = Math.max(ctx.currentTime + leadTime, nextStartTimeRef.current)
        nextStartTimeRef.current = startAt + decoded.duration + 0.012
        activeSourcesRef.current += 1
        sourcesRef.current.push(source)
        setScheduledCount(value => value + 1)
        setPlaying(true)
        setBufferedMs(Math.max(0, Math.round((nextStartTimeRef.current - ctx.currentTime) * 1000)))

        const fade = Math.min(0.018, Math.max(0.004, decoded.duration / 4))
        gain.gain.setValueAtTime(0.0001, startAt)
        gain.gain.exponentialRampToValueAtTime(1.0, startAt + fade)
        if (decoded.duration > fade * 2) {
          gain.gain.setValueAtTime(1.0, startAt + decoded.duration - fade)
        }
        gain.gain.exponentialRampToValueAtTime(0.0001, startAt + decoded.duration)

        callbacksRef.current.onStart?.(chunk)
        addVisemeTrack(chunk, startAt, decoded.duration)

        source.onended = () => {
          activeSourcesRef.current = Math.max(0, activeSourcesRef.current - 1)
          sourcesRef.current = sourcesRef.current.filter(item => item !== source)
          setScheduledCount(value => Math.max(0, value - 1))
          if (activeSourcesRef.current === 0 && queueRef.current.length === 0) {
            setPlaying(false)
            callbacksRef.current.onEnd?.()
          }
        }

        source.start(startAt)
      }
    } catch (exc) {
      setError(`WebAudio streaming failed: ${exc instanceof Error ? exc.message : String(exc)}`)
      setPlaying(false)
      emitRest()
    } finally {
      processingRef.current = false
      if (queueRef.current.length > 0) window.setTimeout(processQueue, 0)
    }
  }, [addVisemeTrack, currentJitterSeconds, emitRest, ensureAudioContext])

  const enqueue = useCallback((chunk: AudioChunk) => {
    if (seenRef.current.has(chunk.id)) return
    seenRef.current.add(chunk.id)
    updateAdaptiveJitter()
    setReceivedChunks(value => value + 1)
    queueRef.current.push(chunk)
    setQueued(queueRef.current.length)
    window.setTimeout(processQueue, 0)
  }, [processQueue, updateAdaptiveJitter])

  const reset = useCallback(() => {
    queueRef.current = []
    seenRef.current.clear()
    setQueued(0)
    stopVisemeLoop()
    tracksRef.current = []
    for (const source of sourcesRef.current) {
      try {
        source.stop()
      } catch {
        // already stopped
      }
      try {
        source.disconnect()
      } catch {
        // already disconnected
      }
    }
    sourcesRef.current = []
    activeSourcesRef.current = 0
    processingRef.current = false
    lastArrivalMsRef.current = null
    smoothedIntervalMsRef.current = null
    smoothedDeviationMsRef.current = 0
    networkJitterMsRef.current = 0
    adaptiveJitterBufferMsRef.current = clamp(initialBufferMs, minBufferMs, maxBufferMs)
    const ctx = audioCtxRef.current
    if (ctx) nextStartTimeRef.current = ctx.currentTime + currentJitterSeconds()
    setNetworkJitterMs(0)
    setAdaptiveJitterBufferMs(Math.round(adaptiveJitterBufferMsRef.current))
    setReceivedChunks(0)
    setUnderrunEstimate(0)
    setScheduledCount(0)
    setBufferedMs(0)
    setPlaying(false)
    emitRest()
  }, [currentJitterSeconds, emitRest, initialBufferMs, maxBufferMs, minBufferMs, stopVisemeLoop])

  useEffect(() => () => {
    reset()
    audioCtxRef.current?.close().catch(() => undefined)
    audioCtxRef.current = null
  }, [reset])

  return {
    enqueue,
    reset,
    playing,
    queued,
    scheduled: scheduledCount,
    bufferedMs,
    adaptiveJitterBufferMs,
    networkJitterMs,
    receivedChunks,
    underrunEstimate,
    error,
    engine: 'webaudio-clock-adaptive' as const
  }
}
