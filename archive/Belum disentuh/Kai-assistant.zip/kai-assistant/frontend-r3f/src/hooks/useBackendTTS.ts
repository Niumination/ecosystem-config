import { useCallback, useEffect, useRef, useState } from 'react'
import type { VisemeState } from '../types/kai'

type BackendTTSOptions = {
  backend?: string
  onViseme?: (viseme: VisemeState) => void
  onStart?: () => void
  onEnd?: () => void
}

type TTSJsonResponse = {
  provider: string
  mime_type: string
  audio_base64: string
  duration_ms: number
  sample_rate: number
  visemes: Array<{ at_ms: number; name: string; weight: number }>
}

function defaultBackend(): string {
  const params = new URLSearchParams(window.location.search)
  return params.get('backend') || localStorage.getItem('kai_r3f_backend') || 'localhost:8000'
}

function base64ToBlob(base64: string, mimeType: string): Blob {
  const binary = atob(base64)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i)
  return new Blob([bytes], { type: mimeType })
}

export function useBackendTTS(options: BackendTTSOptions = {}) {
  const [playing, setPlaying] = useState(false)
  const [error, setError] = useState<string>()
  const [durationMs, setDurationMs] = useState(0)
  const [provider, setProvider] = useState('')
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const objectUrlRef = useRef<string | null>(null)
  const timersRef = useRef<number[]>([])
  const callbacksRef = useRef<Pick<BackendTTSOptions, 'onViseme' | 'onStart' | 'onEnd'>>({})
  const backend = options.backend || defaultBackend()

  useEffect(() => {
    callbacksRef.current = {
      onViseme: options.onViseme,
      onStart: options.onStart,
      onEnd: options.onEnd
    }
  }, [options.onViseme, options.onStart, options.onEnd])

  const clearTimers = useCallback(() => {
    for (const timer of timersRef.current) window.clearTimeout(timer)
    timersRef.current = []
  }, [])

  const cleanup = useCallback(() => {
    clearTimers()
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current)
      objectUrlRef.current = null
    }
    audioRef.current = null
    callbacksRef.current.onViseme?.({ name: 'REST', weight: 0 })
  }, [clearTimers])

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
    }
    cleanup()
    setPlaying(false)
    callbacksRef.current.onEnd?.()
  }, [cleanup])

  const scheduleVisemes = useCallback((visemes: TTSJsonResponse['visemes']) => {
    clearTimers()
    for (const item of visemes) {
      const timer = window.setTimeout(() => {
        callbacksRef.current.onViseme?.({ name: item.name, weight: item.weight })
      }, Math.max(0, item.at_ms))
      timersRef.current.push(timer)
    }
  }, [clearTimers])

  const speak = useCallback(async (text: string, language = 'id-ID') => {
    if (!text.trim()) return
    stop()
    setError(undefined)
    try {
      const response = await fetch(`http://${backend}/api/tts/synthesize-json`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, language, voice: 'kai-mock-voice', format: 'wav' })
      })
      if (!response.ok) throw new Error(`HTTP ${response.status}`)
      const data = (await response.json()) as TTSJsonResponse
      setDurationMs(data.duration_ms)
      setProvider(data.provider)

      const blob = base64ToBlob(data.audio_base64, data.mime_type)
      const url = URL.createObjectURL(blob)
      objectUrlRef.current = url
      const audio = new Audio(url)
      audioRef.current = audio

      audio.onplay = () => {
        setPlaying(true)
        callbacksRef.current.onStart?.()
        scheduleVisemes(data.visemes)
      }
      audio.onended = () => {
        setPlaying(false)
        cleanup()
        callbacksRef.current.onEnd?.()
      }
      audio.onerror = () => {
        setPlaying(false)
        setError('Backend TTS audio playback failed')
        cleanup()
        callbacksRef.current.onEnd?.()
      }
      await audio.play()
    } catch (exc) {
      setPlaying(false)
      cleanup()
      setError(`Backend TTS failed: ${exc instanceof Error ? exc.message : String(exc)}`)
      callbacksRef.current.onEnd?.()
    }
  }, [backend, cleanup, scheduleVisemes, stop])

  return { speak, stop, playing, error, durationMs, provider }
}
