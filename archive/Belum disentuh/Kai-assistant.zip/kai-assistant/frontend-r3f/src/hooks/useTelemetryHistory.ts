import { useEffect, useState } from 'react'

type TelemetryItem = {
  id: number
  session_id?: string
  source: string
  timestamp_ms?: number
  created_at: number
  metrics: Record<string, unknown>
}

type TelemetrySummary = {
  count: number
  session_id?: string
  averages: Record<string, number>
  max: Record<string, number>
  min: Record<string, number>
  latest?: TelemetryItem
}

type TelemetryHistoryState = {
  items: TelemetryItem[]
  summary?: TelemetrySummary
  loading: boolean
  error?: string
  refresh: () => void
}

function defaultBackend(): string {
  const params = new URLSearchParams(window.location.search)
  return params.get('backend') || localStorage.getItem('kai_r3f_backend') || 'localhost:8000'
}

export function useTelemetryHistory(sessionId?: string, enabled = true): TelemetryHistoryState {
  const [items, setItems] = useState<TelemetryItem[]>([])
  const [summary, setSummary] = useState<TelemetrySummary>()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>()
  const [refreshIndex, setRefreshIndex] = useState(0)
  const backend = defaultBackend()

  useEffect(() => {
    if (!enabled) return
    let cancelled = false
    const load = async () => {
      if (!sessionId) return
      setLoading(true)
      setError(undefined)
      try {
        const query = new URLSearchParams({ session_id: sessionId, limit: '80' })
        const [recentRes, summaryRes] = await Promise.all([
          fetch(`http://${backend}/api/telemetry/recent?${query.toString()}`),
          fetch(`http://${backend}/api/telemetry/summary?${query.toString()}`)
        ])
        if (!recentRes.ok) throw new Error(`recent HTTP ${recentRes.status}`)
        if (!summaryRes.ok) throw new Error(`summary HTTP ${summaryRes.status}`)
        const recentData = await recentRes.json()
        const summaryData = await summaryRes.json()
        if (!cancelled) {
          setItems(recentData.items || [])
          setSummary(summaryData)
        }
      } catch (exc) {
        if (!cancelled) setError(exc instanceof Error ? exc.message : String(exc))
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    const interval = window.setInterval(load, 6000)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [backend, enabled, refreshIndex, sessionId])

  return {
    items,
    summary,
    loading,
    error,
    refresh: () => setRefreshIndex(value => value + 1)
  }
}

export type { TelemetryItem, TelemetrySummary }
