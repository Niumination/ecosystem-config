import { useCallback, useMemo, useState } from 'react'

type SpeechRecognitionLike = {
  lang: string
  interimResults: boolean
  continuous: boolean
  onresult: ((event: any) => void) | null
  onerror: ((event: any) => void) | null
  onend: (() => void) | null
  start: () => void
  stop: () => void
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor
    webkitSpeechRecognition?: SpeechRecognitionConstructor
  }
}

export type BrowserVoiceState = {
  sttSupported: boolean
  ttsSupported: boolean
  listening: boolean
  speaking: boolean
  error?: string
  speak: (text: string, lang?: string) => void
  stopSpeaking: () => void
  listenOnce: (onText: (text: string) => void, lang?: string) => void
}

export function useBrowserVoice(): BrowserVoiceState {
  const [listening, setListening] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [error, setError] = useState<string>()

  const Recognition = useMemo(() => window.SpeechRecognition || window.webkitSpeechRecognition, [])
  const sttSupported = Boolean(Recognition)
  const ttsSupported = 'speechSynthesis' in window

  const stopSpeaking = useCallback(() => {
    if (!ttsSupported) return
    window.speechSynthesis.cancel()
    setSpeaking(false)
  }, [ttsSupported])

  const speak = useCallback((text: string, lang = 'id-ID') => {
    if (!ttsSupported || !text.trim()) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = lang
    utterance.rate = 1.02
    utterance.pitch = 1.05
    utterance.onstart = () => setSpeaking(true)
    utterance.onend = () => setSpeaking(false)
    utterance.onerror = event => {
      setSpeaking(false)
      setError(`TTS error: ${event.error}`)
    }
    window.speechSynthesis.speak(utterance)
  }, [ttsSupported])

  const listenOnce = useCallback((onText: (text: string) => void, lang = 'id-ID') => {
    if (!Recognition) {
      setError('SpeechRecognition tidak tersedia di browser ini.')
      return
    }
    const rec = new Recognition()
    rec.lang = lang
    rec.interimResults = false
    rec.continuous = false
    rec.onresult = event => {
      const text = event.results?.[0]?.[0]?.transcript || ''
      if (text) onText(text)
    }
    rec.onerror = event => {
      setError(`STT error: ${event.error || 'unknown'}`)
      setListening(false)
    }
    rec.onend = () => setListening(false)
    setError(undefined)
    setListening(true)
    rec.start()
  }, [Recognition])

  return {
    sttSupported,
    ttsSupported,
    listening,
    speaking,
    error,
    speak,
    stopSpeaking,
    listenOnce
  }
}
