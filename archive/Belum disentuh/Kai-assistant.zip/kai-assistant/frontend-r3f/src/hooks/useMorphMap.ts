import { useEffect, useState } from 'react'

export function useMorphMap(url?: string): Record<string, string> {
  const [mapping, setMapping] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!url) {
      setMapping({})
      return
    }
    let cancelled = false
    fetch(url)
      .then(response => response.json())
      .then(data => {
        if (cancelled) return
        setMapping(data.kaiToModel || data || {})
      })
      .catch(() => {
        if (!cancelled) setMapping({})
      })
    return () => {
      cancelled = true
    }
  }, [url])

  return mapping
}
