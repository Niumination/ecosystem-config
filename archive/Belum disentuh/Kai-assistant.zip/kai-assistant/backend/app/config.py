from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    app_name: str = "KAI Backend"
    version: str = "0.2.0"
    host: str = os.getenv("KAI_HOST", "127.0.0.1")
    port: int = int(os.getenv("KAI_PORT", "8000"))
    data_dir: Path = Path(os.getenv("KAI_DATA_DIR", "data"))
    sqlite_path: Path = Path(os.getenv("KAI_SQLITE_PATH", "data/kai_memory.sqlite3"))
    ollama_base_url: str | None = os.getenv("OLLAMA_BASE_URL")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.1")
    tts_provider: str = os.getenv("KAI_TTS_PROVIDER", "browser-speechSynthesis")
    stt_provider: str = os.getenv("KAI_STT_PROVIDER", "browser-SpeechRecognition-or-placeholder")


settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
