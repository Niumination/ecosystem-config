from __future__ import annotations

from pydantic import BaseModel, Field


class TelemetrySnapshot(BaseModel):
    session_id: str | None = None
    source: str = "kai-frontend-r3f"
    timestamp_ms: float | None = None
    metrics: dict = Field(default_factory=dict)
