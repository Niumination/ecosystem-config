from __future__ import annotations

from pydantic import BaseModel, Field


class TTSRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=4000)
    voice: str = "kai-mock-voice"
    language: str = "id-ID"
    format: str = "wav"


class TTSJsonResponse(BaseModel):
    provider: str
    mime_type: str
    audio_base64: str
    duration_ms: int
    sample_rate: int
    visemes: list[dict]


class STTResponse(BaseModel):
    provider: str
    text: str
    language: str | None = None
    duration_ms: int | None = None
    confidence: float | None = None
    segments: list[dict] = []
    note: str | None = None
