from __future__ import annotations

import asyncio
import time
import uuid
from typing import Any

from fastapi import FastAPI, File, Form, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response

from app.config import settings
from app.models.audio import TTSRequest
from app.models.telemetry import TelemetrySnapshot
from app.services.llm import chunk_text, generate_reply
from app.services.memory import add_message, clear_session, init_db, list_messages, list_sessions
from app.services.sentiment import analyze_emotion
from app.services.stt import transcribe_audio_upload
from app.services.tts import synthesize_mock_json, synthesize_mock_wav
from app.services.telemetry import add_telemetry_snapshot, init_telemetry_db, list_recent_telemetry, telemetry_summary
from app.services.viseme import generate_viseme_timeline

app = FastAPI(title=settings.app_name, version=settings.version)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup() -> None:
    init_db()
    init_telemetry_db()


@app.get("/health")
async def health() -> JSONResponse:
    return JSONResponse(
        {
            "ok": True,
            "service": "kai-backend",
            "version": settings.version,
            "capabilities": capabilities(),
        }
    )


@app.get("/api/config")
async def api_config() -> JSONResponse:
    return JSONResponse(
        {
            "name": "KAI",
            "persona": "Ramah, profesional, cerdas secara teknis, mudah didekati",
            "transport": "websocket-json-control-plus-binary-audio-ready",
            "providers": {
                "llm": "ollama" if settings.ollama_base_url else "mock-local",
                "stt": settings.stt_provider,
                "tts": settings.tts_provider,
            },
            "capabilities": capabilities(),
        }
    )


@app.get("/api/avatar/morph-targets")
async def api_morph_targets() -> JSONResponse:
    return JSONResponse(
        {
            "expressions": ["neutral", "smile", "frown", "angry", "confused", "blink_L", "blink_R", "browUp", "browDown", "surprised"],
            "visemes": ["REST", "AA", "E", "IH", "OH", "OU", "FV", "L", "MBP", "WQ", "CH", "TH", "NDT", "R"],
            "format": "GLB/GLTF or VRM with morphTargetDictionary names matching these keys",
        }
    )


@app.get("/api/tts/voices")
async def api_voices() -> JSONResponse:
    return JSONResponse(
        {
            "default": "kai-mock-voice",
            "voices": [
                {"id": "kai-mock-voice", "provider": "kai-mock-tts", "languages": ["id-ID", "en-US", "ja-JP", "ko-KR"], "status": "available-for-pipeline-testing"},
                {"id": "browser-default", "provider": "browser", "languages": ["id-ID", "en-US"]},
                {"id": "styletts2-local-placeholder", "provider": "styletts2", "status": "planned"},
                {"id": "elevenlabs-api-placeholder", "provider": "elevenlabs", "status": "planned"},
            ],
        }
    )


@app.post("/api/tts/synthesize")
async def api_tts_synthesize(req: TTSRequest) -> Response:
    wav, duration_ms, _visemes = synthesize_mock_wav(req.text, language=req.language)
    return Response(
        content=wav,
        media_type="audio/wav",
        headers={
            "X-KAI-TTS-Provider": "kai-mock-tts",
            "X-KAI-Duration-Ms": str(duration_ms),
        },
    )


@app.post("/api/tts/synthesize-json")
async def api_tts_synthesize_json(req: TTSRequest) -> JSONResponse:
    return JSONResponse(synthesize_mock_json(req.text, language=req.language))


@app.post("/api/stt/transcribe")
async def api_stt_transcribe(
    file: UploadFile = File(...),
    language: str | None = Form(default=None),
) -> JSONResponse:
    result = await transcribe_audio_upload(file.file, file.filename or "audio", file.content_type, language)
    return JSONResponse(result)


@app.post("/api/telemetry/snapshot")
async def api_telemetry_snapshot(snapshot: TelemetrySnapshot) -> JSONResponse:
    snapshot_id = add_telemetry_snapshot(
        session_id=snapshot.session_id,
        source=snapshot.source,
        timestamp_ms=snapshot.timestamp_ms,
        metrics=snapshot.metrics,
    )
    return JSONResponse(
        {
            "ok": True,
            "id": snapshot_id,
            "received": {
                "session_id": snapshot.session_id,
                "source": snapshot.source,
                "metric_count": len(snapshot.metrics),
            },
        }
    )


@app.get("/api/telemetry/recent")
async def api_telemetry_recent(session_id: str | None = None, limit: int = 100) -> JSONResponse:
    return JSONResponse({"items": list_recent_telemetry(session_id=session_id, limit=limit)})


@app.get("/api/telemetry/summary")
async def api_telemetry_summary(session_id: str | None = None, limit: int = 200) -> JSONResponse:
    return JSONResponse(telemetry_summary(session_id=session_id, limit=limit))


@app.get("/api/sessions")
async def api_sessions(limit: int = 20) -> JSONResponse:
    return JSONResponse({"sessions": list_sessions(limit=limit)})


@app.get("/api/sessions/{session_id}/messages")
async def api_session_messages(session_id: str, limit: int = 50) -> JSONResponse:
    return JSONResponse({"session_id": session_id, "messages": list_messages(session_id, limit=limit)})


@app.delete("/api/sessions/{session_id}")
async def api_clear_session(session_id: str) -> JSONResponse:
    return JSONResponse({"session_id": session_id, "deleted": clear_session(session_id)})


def capabilities() -> dict[str, Any]:
    return {
        "input": ["text", "audio-upload-stt", "audio-chunk-placeholder", "browser-stt"],
        "output": ["streaming-text", "browser-tts", "backend-mock-tts-wav", "websocket-audio-json-chunks", "websocket-audio-binary-frames", "avatar-commands"],
        "avatar": ["emotion-morphs", "viseme-timeline", "canvas-mvp", "glb-ready-contract"],
        "deployment": ["pwa", "tauri", "pyinstaller-sidecar-ready"],
    }


async def send_event(ws: WebSocket, event_type: str, payload: dict[str, Any]) -> None:
    await ws.send_json({"type": event_type, "ts": time.time(), **payload})


@app.websocket("/ws/kai")
async def kai_ws(ws: WebSocket) -> None:
    await ws.accept()
    session_id = ws.query_params.get("session_id") or str(uuid.uuid4())
    await send_event(
        ws,
        "session.ready",
        {
            "session_id": session_id,
            "message": "KAI backend connected",
            "capabilities": capabilities(),
        },
    )

    audio_transport = "json"

    try:
        while True:
            incoming = await ws.receive_json()
            msg_type = incoming.get("type")

            if msg_type == "session.audio_transport":
                requested = str(incoming.get("mode", "json")).lower()
                audio_transport = "binary" if requested == "binary" else "json"
                await send_event(ws, "session.audio_transport", {"session_id": session_id, "mode": audio_transport})

            elif msg_type == "user.text":
                text = str(incoming.get("text", "")).strip()
                if not text:
                    await send_event(ws, "error", {"message": "Text kosong."})
                    continue

                emotion = analyze_emotion(text)
                add_message(session_id, "user", text, emotion.name)
                await send_event(
                    ws,
                    "avatar.command",
                    {
                        "session_id": session_id,
                        "emotion": {"name": emotion.name, "intensity": emotion.intensity},
                        "morphs": emotion.morphs,
                        "viseme": {"name": "REST", "weight": 0},
                    },
                )
                await send_event(ws, "stt.final", {"session_id": session_id, "text": text})

                reply = await generate_reply(text)
                reply_emotion = analyze_emotion(reply)
                add_message(session_id, "assistant", reply, reply_emotion.name)
                timeline = generate_viseme_timeline(reply)

                await send_event(
                    ws,
                    "assistant.start",
                    {
                        "session_id": session_id,
                        "text": reply,
                        "emotion": {"name": reply_emotion.name, "intensity": reply_emotion.intensity},
                        "morphs": reply_emotion.morphs,
                        "visemes": timeline,
                    },
                )

                await send_event(
                    ws,
                    "voice.audio.start",
                    {
                        "session_id": session_id,
                        "provider": "kai-mock-tts",
                        "mode": "chunked-websocket-binary" if audio_transport == "binary" else "chunked-websocket-json",
                        "mime_type": "audio/wav",
                    },
                )

                elapsed_ms = 0
                for idx, chunk in enumerate(chunk_text(reply)):
                    await asyncio.sleep(0.12)
                    text_chunk = chunk + " "
                    await send_event(ws, "assistant.delta", {"session_id": session_id, "index": idx, "text": text_chunk})

                    # Simulated real-time audio chunk.
                    # JSON mode sends base64 in the event. Binary mode sends metadata first,
                    # followed by a WebSocket binary frame containing WAV bytes.
                    if audio_transport == "binary":
                        wav_bytes, duration_ms, visemes = synthesize_mock_wav(text_chunk, language="id-ID")
                        chunk_id = f"{session_id}:{idx}"
                        await send_event(
                            ws,
                            "voice.audio.chunk.meta",
                            {
                                "session_id": session_id,
                                "chunk_id": chunk_id,
                                "index": idx,
                                "text": text_chunk,
                                "provider": "kai-mock-tts",
                                "mime_type": "audio/wav",
                                "duration_ms": duration_ms,
                                "sample_rate": 22050,
                                "byte_length": len(wav_bytes),
                                "visemes": visemes,
                            },
                        )
                        await ws.send_bytes(wav_bytes)
                        audio_duration_ms = duration_ms
                        audio_visemes = visemes
                    else:
                        audio_packet = synthesize_mock_json(text_chunk, language="id-ID")
                        await send_event(
                            ws,
                            "voice.audio.chunk",
                            {
                                "session_id": session_id,
                                "index": idx,
                                "text": text_chunk,
                                "provider": audio_packet["provider"],
                                "mime_type": audio_packet["mime_type"],
                                "audio_base64": audio_packet["audio_base64"],
                                "duration_ms": audio_packet["duration_ms"],
                                "sample_rate": audio_packet["sample_rate"],
                                "visemes": audio_packet["visemes"],
                            },
                        )
                        audio_duration_ms = audio_packet["duration_ms"]
                        audio_visemes = audio_packet["visemes"]

                    await send_event(
                        ws,
                        "avatar.viseme.chunk",
                        {
                            "session_id": session_id,
                            "index": idx,
                            "duration_ms": audio_duration_ms,
                            "visemes": audio_visemes,
                        },
                    )

                    for item in timeline:
                        if elapsed_ms <= item["at_ms"] < elapsed_ms + 420:
                            await send_event(
                                ws,
                                "avatar.command",
                                {
                                    "session_id": session_id,
                                    "emotion": {"name": reply_emotion.name, "intensity": reply_emotion.intensity},
                                    "morphs": reply_emotion.morphs,
                                    "viseme": {"name": item["name"], "weight": item["weight"]},
                                },
                            )
                    elapsed_ms += 420

                await send_event(ws, "voice.audio.done", {"session_id": session_id})
                await send_event(ws, "assistant.done", {"session_id": session_id, "text": reply})
                await send_event(
                    ws,
                    "avatar.command",
                    {
                        "session_id": session_id,
                        "emotion": {"name": "neutral", "intensity": 0.3},
                        "morphs": {"smile": 0.18},
                        "viseme": {"name": "REST", "weight": 0},
                    },
                )

            elif msg_type == "user.audio.chunk":
                await send_event(ws, "stt.partial", {"session_id": session_id, "text": "[audio diterima — STT streaming belum diaktifkan di MVP]"})
            elif msg_type == "session.history":
                await send_event(ws, "session.history", {"session_id": session_id, "messages": list_messages(session_id)})
            elif msg_type == "ping":
                await send_event(ws, "pong", {"session_id": session_id})
            else:
                await send_event(ws, "error", {"session_id": session_id, "message": f"Unknown message type: {msg_type}"})

    except WebSocketDisconnect:
        return
