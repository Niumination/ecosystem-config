from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EmotionState:
    name: str
    intensity: float
    morphs: dict[str, float]


POSITIVE = {
    "terima kasih", "thanks", "thank you", "bagus", "keren", "hebat", "mantap",
    "love", "suka", "senang", "great", "awesome", "good", "nice"
}
NEGATIVE = {
    "sedih", "marah", "buruk", "jelek", "kecewa", "susah", "bingung", "error",
    "problem", "issue", "bad", "angry", "sad", "confused", "tidak jelas"
}
QUESTION = {"?", "apa", "bagaimana", "kenapa", "mengapa", "siapa", "kapan", "where", "what", "how", "why"}


def analyze_emotion(text: str) -> EmotionState:
    lowered = text.lower().strip()
    score = 0
    for word in POSITIVE:
        if word in lowered:
            score += 1
    for word in NEGATIVE:
        if word in lowered:
            score -= 1

    is_question = any(token in lowered for token in QUESTION)

    if score > 0:
        return EmotionState("happy", min(0.95, 0.45 + score * 0.18), {"smile": 0.72, "browUp": 0.12})
    if score < 0:
        if "bingung" in lowered or "confused" in lowered or "tidak jelas" in lowered:
            return EmotionState("confused", 0.72, {"confused": 0.72, "browUp": 0.35})
        return EmotionState("concerned", min(0.9, 0.5 + abs(score) * 0.15), {"frown": 0.42, "browDown": 0.2})
    if is_question:
        return EmotionState("focused", 0.58, {"browUp": 0.22, "smile": 0.12})
    return EmotionState("neutral", 0.38, {"smile": 0.18})
