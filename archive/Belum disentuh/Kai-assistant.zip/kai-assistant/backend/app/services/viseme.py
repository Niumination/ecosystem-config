from __future__ import annotations

import re

# Sederhana untuk MVP: mapping karakter/vokal ke viseme.
# Produksi: gunakan timestamp phoneme dari TTS/forced alignment.
VISEME_BY_CHAR = {
    "a": "AA",
    "i": "IH",
    "e": "E",
    "o": "OH",
    "u": "OU",
    "m": "MBP",
    "b": "MBP",
    "p": "MBP",
    "f": "FV",
    "v": "FV",
    "l": "L",
    "r": "R",
    "w": "WQ",
    "q": "WQ",
    "c": "CH",
    "j": "CH",
    "s": "CH",
    "t": "NDT",
    "d": "NDT",
    "n": "NDT",
}


def generate_viseme_timeline(text: str, start_ms: int = 0, step_ms: int = 90) -> list[dict]:
    compact = re.sub(r"\s+", " ", text.lower()).strip()
    timeline: list[dict] = []
    t = start_ms
    last = "REST"
    for char in compact:
        if char == " ":
            viseme = "REST"
        else:
            viseme = VISEME_BY_CHAR.get(char, last if last != "REST" else "AA")
        if not timeline or timeline[-1]["name"] != viseme:
            timeline.append({"at_ms": t, "name": viseme, "weight": 0.88 if viseme != "REST" else 0.0})
        t += step_ms
        last = viseme
    timeline.append({"at_ms": t + 120, "name": "REST", "weight": 0.0})
    return timeline
