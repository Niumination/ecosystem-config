from __future__ import annotations

import os
import httpx

SYSTEM_PERSONA = """
Kamu adalah KAI, Knowledgeable Artificial Intelligence. Persona: ramah, profesional,
cerdas secara teknis, mudah didekati. Jawab dalam bahasa pengguna. Singkat, jelas,
dan jika diminta teknis, berikan langkah konkret.
""".strip()


async def generate_reply(user_text: str) -> str:
    """Adapter LLM.

    MVP default memakai respons lokal deterministik agar langsung jalan.
    Jika OLLAMA_BASE_URL diset, fungsi mencoba model Ollama.
    """
    ollama_base = os.getenv("OLLAMA_BASE_URL")
    ollama_model = os.getenv("OLLAMA_MODEL", "llama3.1")
    if ollama_base:
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(
                    f"{ollama_base.rstrip('/')}/api/chat",
                    json={
                        "model": ollama_model,
                        "stream": False,
                        "messages": [
                            {"role": "system", "content": SYSTEM_PERSONA},
                            {"role": "user", "content": user_text},
                        ],
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                return data.get("message", {}).get("content", "Saya siap membantu.").strip()
        except Exception as exc:  # fallback aman untuk demo
            return f"Saya mengalami kendala menghubungi model lokal ({exc}). Untuk sementara, saya tetap bisa membantu dengan mode demo. Pertanyaan Anda: {user_text}"

    lowered = user_text.lower()
    if "arsitektur" in lowered or "architecture" in lowered:
        return (
            "Arsitektur KAI terdiri dari frontend avatar 3D, koneksi WebSocket real-time, "
            "backend FastAPI, modul STT, LLM orchestrator, emotion engine, TTS, dan viseme generator. "
            "Untuk tahap MVP, kita jalankan teks, emosi, dan lipsync simulatif terlebih dahulu."
        )
    if "deploy" in lowered or "tauri" in lowered or "linux" in lowered or "mac" in lowered:
        return (
            "Untuk deployment, build frontend sebagai PWA, bundle backend Python sebagai sidecar, "
            "lalu gunakan Tauri untuk menghasilkan .dmg di macOS dan AppImage atau .deb di Linux."
        )
    if "halo" in lowered or "hai" in lowered or "hello" in lowered:
        return "Halo, saya KAI. Saya siap membantu lewat teks, suara, dan avatar interaktif. Apa yang ingin Anda kerjakan hari ini?"
    return (
        "Baik, saya mengerti. Saya akan membantu secara bertahap: pertama memahami tujuan Anda, "
        "lalu memberi rekomendasi teknis yang praktis. Untuk input tadi, langkah terbaik adalah membuat prototype, "
        "mengukur latency, kemudian menghubungkan STT, LLM, TTS, dan animasi avatar."
    )


def chunk_text(text: str, max_len: int = 42) -> list[str]:
    words = text.split()
    chunks: list[str] = []
    cur: list[str] = []
    size = 0
    for word in words:
        if size + len(word) + 1 > max_len and cur:
            chunks.append(" ".join(cur))
            cur = [word]
            size = len(word)
        else:
            cur.append(word)
            size += len(word) + 1
    if cur:
        chunks.append(" ".join(cur))
    return chunks
