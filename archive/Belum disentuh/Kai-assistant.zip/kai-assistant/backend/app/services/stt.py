from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from typing import BinaryIO


async def transcribe_audio_upload(file_obj: BinaryIO, filename: str, content_type: str | None = None, language: str | None = None) -> dict:
    """Transcribe uploaded audio.

    If `KAI_STT_PROVIDER=faster-whisper` and faster_whisper is installed, this uses a
    local Whisper model. Otherwise it returns a deterministic placeholder response so
    the API contract can be tested without heavy dependencies.
    """
    provider = os.getenv("KAI_STT_PROVIDER", "mock")
    model_name = os.getenv("KAI_WHISPER_MODEL", "base")
    started = time.time()
    suffix = Path(filename or "audio.webm").suffix or ".webm"
    data = file_obj.read()

    if provider == "faster-whisper":
        try:
            from faster_whisper import WhisperModel  # type: ignore

            with tempfile.NamedTemporaryFile(suffix=suffix, delete=True) as tmp:
                tmp.write(data)
                tmp.flush()
                model = WhisperModel(model_name, device=os.getenv("KAI_WHISPER_DEVICE", "cpu"), compute_type=os.getenv("KAI_WHISPER_COMPUTE", "int8"))
                segments_iter, info = model.transcribe(tmp.name, language=language, vad_filter=True)
                segments = []
                full_text = []
                for seg in segments_iter:
                    segments.append({"start": seg.start, "end": seg.end, "text": seg.text})
                    full_text.append(seg.text)
                return {
                    "provider": f"faster-whisper:{model_name}",
                    "text": " ".join(full_text).strip(),
                    "language": getattr(info, "language", language),
                    "duration_ms": int((time.time() - started) * 1000),
                    "confidence": None,
                    "segments": segments,
                    "note": None,
                }
        except Exception as exc:
            return {
                "provider": "mock-after-faster-whisper-error",
                "text": "[STT lokal belum tersedia]",
                "language": language,
                "duration_ms": int((time.time() - started) * 1000),
                "confidence": 0.0,
                "segments": [],
                "note": f"faster-whisper failed or not installed: {exc}",
            }

    size_kb = len(data) / 1024
    return {
        "provider": "kai-mock-stt",
        "text": f"[audio diterima: {filename or 'blob'}, {size_kb:.1f} KiB, content-type={content_type or 'unknown'}]",
        "language": language,
        "duration_ms": int((time.time() - started) * 1000),
        "confidence": 0.0,
        "segments": [],
        "note": "Set KAI_STT_PROVIDER=faster-whisper and install optional dependencies for real local STT.",
    }
