from __future__ import annotations

import base64
import io
import math
import wave

from app.services.viseme import generate_viseme_timeline

SAMPLE_RATE = 22050


def _char_frequency(ch: str) -> float:
    if ch.lower() in "aiueo":
        return {"a": 180, "i": 260, "u": 210, "e": 240, "o": 200}.get(ch.lower(), 220)
    if ch == " ":
        return 0
    return 145 + (ord(ch) % 34) * 3.2


def synthesize_mock_wav(text: str, language: str = "id-ID") -> tuple[bytes, int, list[dict]]:
    """Generate deterministic speech-like WAV for pipeline testing.

    This is intentionally a mock TTS, not natural speech. It allows frontend/backend
    audio transport, timing, and viseme synchronization to be tested without API keys
    or heavy local models.
    """
    text = " ".join(text.strip().split())
    if not text:
        text = "KAI"

    samples: list[int] = []
    char_duration = 0.055 if language.startswith("id") else 0.06
    fade_samples = int(SAMPLE_RATE * 0.006)

    for idx, ch in enumerate(text[:900]):
        freq = _char_frequency(ch)
        n = max(1, int(SAMPLE_RATE * (char_duration if ch != " " else 0.035)))
        for i in range(n):
            if freq == 0:
                val = 0.0
            else:
                t = i / SAMPLE_RATE
                # Two harmonics + subtle amplitude motion for robot-assistant timbre.
                val = 0.26 * math.sin(2 * math.pi * freq * t) + 0.08 * math.sin(2 * math.pi * freq * 2.01 * t)
                val *= 0.82 + 0.18 * math.sin(2 * math.pi * 6.0 * (idx * char_duration + t))
            # prevent clicks
            if i < fade_samples:
                val *= i / fade_samples
            elif i > n - fade_samples:
                val *= max(0, (n - i) / fade_samples)
            samples.append(int(max(-1, min(1, val)) * 32767))

    # Tail silence
    samples.extend([0] * int(SAMPLE_RATE * 0.12))

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(SAMPLE_RATE)
        wav.writeframes(b"".join(int(s).to_bytes(2, "little", signed=True) for s in samples))

    duration_ms = int(len(samples) / SAMPLE_RATE * 1000)
    visemes = generate_viseme_timeline(text, step_ms=max(55, int(duration_ms / max(1, len(text)))))
    return buf.getvalue(), duration_ms, visemes


def synthesize_mock_json(text: str, language: str = "id-ID") -> dict:
    wav, duration_ms, visemes = synthesize_mock_wav(text, language=language)
    return {
        "provider": "kai-mock-tts",
        "mime_type": "audio/wav",
        "audio_base64": base64.b64encode(wav).decode("ascii"),
        "duration_ms": duration_ms,
        "sample_rate": SAMPLE_RATE,
        "visemes": visemes,
    }
