from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from app.config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS telemetry_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT,
  source TEXT NOT NULL,
  timestamp_ms REAL,
  metrics_json TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_telemetry_session_created ON telemetry_snapshots(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_created ON telemetry_snapshots(created_at);
"""


def _connect() -> sqlite3.Connection:
    path: Path = settings.sqlite_path
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_telemetry_db() -> None:
    with _connect() as conn:
        conn.executescript(SCHEMA)
        conn.commit()


def add_telemetry_snapshot(session_id: str | None, source: str, timestamp_ms: float | None, metrics: dict[str, Any]) -> int:
    with _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO telemetry_snapshots(session_id, source, timestamp_ms, metrics_json, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (session_id, source, timestamp_ms, json.dumps(metrics, separators=(",", ":")), time.time()),
        )
        conn.commit()
        return int(cur.lastrowid)


def list_recent_telemetry(session_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
    limit = max(1, min(limit, 500))
    if session_id:
        query = """
            SELECT id, session_id, source, timestamp_ms, metrics_json, created_at
            FROM telemetry_snapshots
            WHERE session_id = ?
            ORDER BY created_at DESC
            LIMIT ?
        """
        params: tuple[Any, ...] = (session_id, limit)
    else:
        query = """
            SELECT id, session_id, source, timestamp_ms, metrics_json, created_at
            FROM telemetry_snapshots
            ORDER BY created_at DESC
            LIMIT ?
        """
        params = (limit,)

    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()

    out: list[dict[str, Any]] = []
    for row in reversed(rows):
        item = dict(row)
        item["metrics"] = json.loads(item.pop("metrics_json") or "{}")
        out.append(item)
    return out


def telemetry_summary(session_id: str | None = None, limit: int = 200) -> dict[str, Any]:
    rows = list_recent_telemetry(session_id=session_id, limit=limit)
    if not rows:
        return {"count": 0, "session_id": session_id, "averages": {}, "latest": None}

    numeric: dict[str, list[float]] = {}
    for row in rows:
        for key, value in row.get("metrics", {}).items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                numeric.setdefault(key, []).append(float(value))

    averages = {key: round(sum(values) / len(values), 3) for key, values in numeric.items() if values}
    maxima = {key: round(max(values), 3) for key, values in numeric.items() if values}
    minima = {key: round(min(values), 3) for key, values in numeric.items() if values}

    return {
        "count": len(rows),
        "session_id": session_id,
        "started_at": rows[0]["created_at"],
        "last_at": rows[-1]["created_at"],
        "averages": averages,
        "max": maxima,
        "min": minima,
        "latest": rows[-1],
    }


def delete_old_telemetry(max_age_seconds: int = 7 * 24 * 3600) -> int:
    cutoff = time.time() - max_age_seconds
    with _connect() as conn:
        cur = conn.execute("DELETE FROM telemetry_snapshots WHERE created_at < ?", (cutoff,))
        conn.commit()
        return int(cur.rowcount or 0)
