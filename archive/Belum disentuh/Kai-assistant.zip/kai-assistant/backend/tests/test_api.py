from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health() -> None:
    res = client.get('/health')
    assert res.status_code == 200
    data = res.json()
    assert data['ok'] is True
    assert data['service'] == 'kai-backend'


def test_morph_targets() -> None:
    res = client.get('/api/avatar/morph-targets')
    assert res.status_code == 200
    data = res.json()
    assert 'smile' in data['expressions']
    assert 'AA' in data['visemes']
    assert 'MBP' in data['visemes']


def test_tts_synthesize_json() -> None:
    res = client.post('/api/tts/synthesize-json', json={'text': 'Halo KAI', 'language': 'id-ID'})
    assert res.status_code == 200
    data = res.json()
    assert data['provider'] == 'kai-mock-tts'
    assert data['mime_type'] == 'audio/wav'
    assert data['audio_base64']
    assert data['duration_ms'] > 0
    assert data['visemes']


def test_tts_synthesize_wav() -> None:
    res = client.post('/api/tts/synthesize', json={'text': 'Halo KAI', 'language': 'id-ID'})
    assert res.status_code == 200
    assert res.headers['content-type'].startswith('audio/wav')
    assert res.content[:4] == b'RIFF'


def test_telemetry_snapshot_recent_and_summary() -> None:
    res = client.post('/api/telemetry/snapshot', json={
        'session_id': 'test-session',
        'metrics': {'fps': 60, 'latencyMs': 120, 'networkJitterMs': 12}
    })
    assert res.status_code == 200
    data = res.json()
    assert data['ok'] is True
    assert data['id'] > 0
    assert data['received']['metric_count'] == 3

    recent = client.get('/api/telemetry/recent', params={'session_id': 'test-session', 'limit': 5})
    assert recent.status_code == 200
    items = recent.json()['items']
    assert items
    assert items[-1]['metrics']['fps'] == 60

    summary = client.get('/api/telemetry/summary', params={'session_id': 'test-session'})
    assert summary.status_code == 200
    summary_data = summary.json()
    assert summary_data['count'] >= 1
    assert 'fps' in summary_data['averages']


def test_websocket_emits_audio_chunk() -> None:
    with client.websocket_connect('/ws/kai') as ws:
        ready = ws.receive_json()
        assert ready['type'] == 'session.ready'
        ws.send_json({'type': 'user.text', 'text': 'Halo'})
        seen_audio = False
        seen_done = False
        for _ in range(40):
            event = ws.receive_json()
            if event['type'] == 'voice.audio.chunk':
                seen_audio = True
                assert event['audio_base64']
                assert event['mime_type'] == 'audio/wav'
                assert event['visemes']
            if event['type'] == 'assistant.done':
                seen_done = True
                break
        assert seen_audio
        assert seen_done


def test_websocket_emits_binary_audio_frame() -> None:
    with client.websocket_connect('/ws/kai') as ws:
        ready = ws.receive_json()
        assert ready['type'] == 'session.ready'
        ws.send_json({'type': 'session.audio_transport', 'mode': 'binary'})
        ack = ws.receive_json()
        assert ack['type'] == 'session.audio_transport'
        assert ack['mode'] == 'binary'
        ws.send_json({'type': 'user.text', 'text': 'Halo'})
        seen_binary = False
        seen_done = False
        for _ in range(60):
            event = ws.receive_json()
            if event['type'] == 'voice.audio.chunk.meta':
                assert event['mime_type'] == 'audio/wav'
                assert event['byte_length'] > 44
                assert event['visemes']
                frame = ws.receive_bytes()
                assert frame[:4] == b'RIFF'
                assert len(frame) == event['byte_length']
                seen_binary = True
            if event['type'] == 'assistant.done':
                seen_done = True
                break
        assert seen_binary
        assert seen_done
