from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.services.memory import init_db  # noqa: E402
from app.services.telemetry import init_telemetry_db  # noqa: E402

init_db()
init_telemetry_db()
