# KAI Audio Crossfade & Viseme Smoothing

KAI sekarang memiliki dua peningkatan untuk membuat output suara/avatar terasa lebih natural:

1. **Audio gain envelope / micro-crossfade** pada setiap chunk.
2. **Viseme smoothing** pada renderer avatar.

## 1. Audio gain envelope

Lokasi kode:

```text
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
```

Setiap chunk audio yang dijadwalkan dengan WebAudio sekarang melalui `GainNode`:

```text
AudioBufferSourceNode
  → GainNode
  → AudioContext.destination
```

Gain envelope:

```ts
gain.gain.setValueAtTime(0.0001, startAt)
gain.gain.exponentialRampToValueAtTime(1.0, startAt + fade)
gain.gain.setValueAtTime(1.0, startAt + duration - fade)
gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration)
```

Durasi fade saat ini:

```ts
fade = min(18 ms, max(4 ms, duration / 4))
```

Tujuan:

- mengurangi klik pada awal/akhir chunk,
- membuat transisi chunk lebih halus,
- menyiapkan pipeline untuk crossfade/adaptive jitter buffer lanjutan.

## 2. Viseme smoothing di GLB renderer

Lokasi kode:

```text
frontend-r3f/src/components/KaiAvatar.tsx
```

Pada model GLB:

- viseme nonaktif release dengan lerp lebih pelan,
- viseme aktif attack lebih cepat,
- ekspresi wajah tetap memakai smoothing standar.

Konsep:

```ts
release viseme → lerp 0.16
active viseme  → lerp 0.48
expression     → lerp 0.18–0.20
```

Ini mengurangi efek mulut patah/chattering saat viseme berubah cepat.

## 3. Fallback avatar smoothing

Fallback geometry avatar juga memiliki smoothing internal:

```ts
smoothMouth = lerp(smoothMouth, targetMouth, attack/release)
smoothSmile = lerp(smoothSmile, targetSmile, 0.16)
```

Attack lebih cepat daripada release agar mulut tetap responsif tetapi tidak berkedip kasar.

## Mode yang terdampak

Peningkatan ini terutama terasa pada:

```text
TTS mode → stream WS JSON
TTS mode → stream WS binary
```

Namun smoothing viseme di `KaiAvatar` juga membantu semua mode yang mengubah `AvatarCommand.viseme`.

## Target berikutnya

- Crossfade overlap antar chunk, bukan hanya gain envelope per chunk.
- Adaptive jitter buffer berdasarkan arrival time.
- Viseme coarticulation: bentuk mulut dipengaruhi viseme sebelum/sesudah.
- Dukungan multi-viseme blend, bukan satu viseme aktif saja.
