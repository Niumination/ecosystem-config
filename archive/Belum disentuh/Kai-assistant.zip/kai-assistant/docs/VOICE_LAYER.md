# KAI Voice Layer

KAI sekarang memiliki voice layer awal di frontend React Three Fiber.

## Lokasi kode

```text
kai-assistant/frontend-r3f/src/hooks/useBrowserVoice.ts
kai-assistant/frontend-r3f/src/components/VoiceControls.tsx
```

## Fitur

- Push-to-talk STT memakai browser `SpeechRecognition` / `webkitSpeechRecognition` jika tersedia.
- Auto-speak TTS memakai browser `speechSynthesis`.
- Pilihan bahasa:
  - `id-ID`
  - `en-US`
  - `ja-JP`
  - `ko-KR`
- Toggle auto speak.
- Stop voice.
- Status STT/TTS ready/unavailable.

## Cara pakai

Jalankan:

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Di bagian bawah stage avatar:

1. Klik `🎙 Push to talk`.
2. Bicara ke browser.
3. Hasil STT dikirim ke backend melalui `user.text`.
4. KAI menjawab.
5. Jika `Auto speak` aktif, jawaban akan dibacakan dengan TTS browser.

## Catatan dukungan browser

- Chrome/Edge biasanya mendukung `webkitSpeechRecognition`.
- Firefox/Safari dapat memiliki dukungan terbatas untuk STT browser.
- `speechSynthesis` lebih luas didukung, tetapi kualitas suara tergantung OS/browser.

## Arah produksi

Browser voice layer adalah fallback cepat. Untuk kualitas produksi, backend perlu menambahkan:

- STT streaming: `faster-whisper`, Whisper API, Deepgram, AssemblyAI, Azure, dsb.
- TTS streaming: StyleTTS 2, ElevenLabs, Azure Neural Voice, OpenAI TTS, dsb.
- Phoneme timestamps dari TTS untuk viseme yang lebih akurat.
- WebAudio scheduling agar audio dan morph target sinkron.

Target produksi:

```text
mic PCM/Opus stream
  → WebSocket/WebRTC
  → backend STT streaming
  → LLM
  → TTS streaming with phoneme timing
  → audio chunks + viseme timeline
  → frontend WebAudio + morph target animation
```
