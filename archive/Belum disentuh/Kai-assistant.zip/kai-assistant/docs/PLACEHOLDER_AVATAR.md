# KAI Placeholder Avatar GLB

Project sekarang menyertakan asset teknis placeholder:

```text
kai-assistant/frontend-r3f/public/models/kai-avatar.glb
```

Asset ini **bukan final art**, tetapi sudah berupa GLB valid yang dapat dimuat oleh Three.js/R3F dan memiliki morph targets sesuai kontrak KAI.

## Tujuan

Placeholder ini dibuat untuk menguji pipeline end-to-end:

```text
FastAPI avatar.command
  → WebSocket
  → React state
  → React Three Fiber
  → mesh.morphTargetInfluences
  → ekspresi/lipsync berubah di model GLB
```

## Generate ulang

```bash
cd kai-assistant
./scripts/generate_avatar_placeholder.sh
```

Atau manual:

```bash
python3 tools/generate_kai_placeholder_glb.py
python3 tools/validate_kai_avatar.py frontend-r3f/public/models/kai-avatar.glb
```

## Validasi model custom

Untuk memeriksa model dari Blender/artist:

```bash
cd kai-assistant
./scripts/validate_avatar.sh frontend-r3f/public/models/kai-avatar.glb
```

Atau model lain:

```bash
./scripts/validate_avatar.sh frontend-r3f/public/models/kai-avatar-final.glb
```

Validator membaca `extras.targetNames` dari mesh GLB/GLTF. Pastikan exporter menyimpan nama morph target. Jika exporter tidak menyimpan nama target, tambahkan mapping frontend atau sesuaikan export pipeline.

## Morph targets yang ada di placeholder

Expressions:

- `smile`
- `frown`
- `angry`
- `confused`
- `blink_L`
- `blink_R`
- `browUp`
- `browDown`
- `surprised`

Visemes:

- `AA`
- `E`
- `IH`
- `OH`
- `OU`
- `FV`
- `L`
- `MBP`
- `WQ`
- `CH`
- `TH`
- `NDT`
- `R`

`REST` dan `neutral` tidak perlu berupa morph target aktif karena keduanya adalah kondisi semua weight = 0.

## Cara melihat di browser

Jalankan:

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Kirim pesan seperti:

```text
halo KAI, kamu keren
```

atau:

```text
jelaskan arsitektur avatar 3D
```

Avatar GLB akan menerima emotion dan viseme command dari backend.
