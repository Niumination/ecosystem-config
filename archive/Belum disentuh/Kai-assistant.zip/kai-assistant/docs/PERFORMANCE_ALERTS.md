# KAI Performance Alerts

Runtime panel KAI sekarang memiliki visual performance alerts.

## Lokasi kode

```text
frontend-r3f/src/components/PerformanceAlerts.tsx
frontend-r3f/src/components/RuntimePanel.tsx
```

## Alert yang dipantau

- FPS rendah
- Latency tinggi
- Audio buffer rendah
- Network jitter tinggi
- Underrun estimate meningkat
- Frame time tinggi
- Long frames banyak
- Adaptive jitter target terlalu tinggi

## Level

Setiap alert memiliki level:

```text
ok
warn
bad
```

Panel utama menampilkan status terburuk:

```text
Healthy
Watch
Needs Attention
```

## Threshold awal

| Metric | Warn | Bad |
|---|---:|---:|
| FPS | <45 | <24 |
| Latency | >900 ms | >1800 ms |
| Audio buffer | <130 ms | <70 ms |
| Network jitter | >55 ms | >120 ms |
| Underrun estimate | >2 | >8 |
| Frame time | >28 ms | >50 ms |
| Long frames | >5 | >20 |
| Jitter target | >420 ms | - |

## Cara mencoba

Jalankan:

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Lihat panel kanan Runtime → Performance Alerts.

## Target berikutnya

- Alert configuration via `/api/config`.
- Kirim alert events ke backend telemetry.
- Highlight alert langsung di avatar stage HUD.
- Tambahkan rekomendasi otomatis berdasarkan kombinasi alert.
