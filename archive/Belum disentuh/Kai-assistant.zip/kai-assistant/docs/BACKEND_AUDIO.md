# KAI Backend Audio API

Backend sekarang memiliki endpoint audio awal untuk STT/TTS.

## Endpoint TTS

### `POST /api/tts/synthesize`

Menghasilkan audio WAV.

Request:

```json
{
  "text": "Halo, saya KAI.",
  "voice": "kai-mock-voice",
  "language": "id-ID",
  "format": "wav"
}
```

Response:

```text
audio/wav
```

Header tambahan:

```text
X-KAI-TTS-Provider: kai-mock-tts
X-KAI-Duration-Ms: <duration>
```

### `POST /api/tts/synthesize-json`

Menghasilkan audio WAV base64 + viseme timeline.

Request sama seperti di atas.

Response:

```json
{
  "provider": "kai-mock-tts",
  "mime_type": "audio/wav",
  "audio_base64": "...",
  "duration_ms": 1234,
  "sample_rate": 22050,
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88}
  ]
}
```

Catatan: `kai-mock-tts` bukan suara natural. Ia hanya generator WAV deterministik untuk menguji pipeline audio, latency, dan sinkronisasi viseme tanpa API key.

## Endpoint STT

### `POST /api/stt/transcribe`

Multipart upload.

Field:

- `file`: audio file, misalnya `.webm`, `.wav`, `.mp3`
- `language`: opsional, misalnya `id`, `en`, `ja`

Contoh:

```bash
curl -X POST http://localhost:8000/api/stt/transcribe \
  -F "language=id" \
  -F "file=@sample.wav"
```

Default provider adalah mock dan akan mengembalikan metadata file.

## Mengaktifkan faster-whisper

Install dependency opsional:

```bash
cd kai-assistant/backend
source .venv/bin/activate
pip install -r requirements-optional-audio.txt
```

Jalankan backend dengan env:

```bash
export KAI_STT_PROVIDER=faster-whisper
export KAI_WHISPER_MODEL=base
export KAI_WHISPER_DEVICE=cpu
export KAI_WHISPER_COMPUTE=int8
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Untuk GPU, sesuaikan environment dan dependency CUDA sesuai mesin.

## Integrasi frontend R3F

Frontend R3F sekarang memiliki pilihan TTS mode:

- `browser`: memakai `speechSynthesis`
- `backend WAV`: memanggil `/api/tts/synthesize-json`, memainkan WAV base64, lalu menjadwalkan viseme timeline untuk morph target avatar

Buka:

```text
http://localhost:5173?model=default
```

Lalu pilih `TTS mode → backend WAV` pada panel voice controls.

## Arah produksi

Untuk produksi, ganti `kai-mock-tts` dengan provider sungguhan:

- StyleTTS 2 lokal,
- Piper,
- Coqui XTTS,
- ElevenLabs,
- Azure Neural Voice,
- OpenAI TTS.

Target response produksi sebaiknya streaming:

```text
assistant text delta
+ audio chunk
+ phoneme/viseme timestamp
```

agar audio dan lipsync benar-benar sinkron real-time.
