# KAI Clock-Based Viseme Renderer

KAI sekarang memakai viseme renderer berbasis clock audio untuk mode streaming.

Sebelumnya viseme dijadwalkan langsung dengan `setTimeout` per item. Sekarang frontend menyimpan timeline viseme per audio chunk dan membaca viseme aktif berdasarkan `AudioContext.currentTime` pada loop `requestAnimationFrame`.

## Mode yang memakai fitur ini

```text
TTS mode → stream WS JSON
TTS mode → stream WS binary
```

## Lokasi kode

```text
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
```

## Alur teknis

```text
voice.audio.chunk / voice.audio.binary.chunk
  → enqueue
  → decodeAudioData
  → tentukan startAt berdasarkan AudioContext.currentTime + jitter buffer
  → source.start(startAt)
  → simpan ScheduledVisemeTrack { startAt, endAt, visemes[] }
  → requestAnimationFrame loop membaca AudioContext.currentTime
  → pilih viseme terakhir dengan viseme.at <= currentTime
  → callback onViseme(viseme)
  → AvatarCommand.viseme update
  → GLB morph target bergerak
```

## Jitter buffer

Default jitter buffer awal:

```ts
jitterBufferMs = 180
```

Tujuannya memberi sedikit waktu bagi frontend untuk menerima/decode chunk berikutnya sebelum audio mulai, sehingga risiko underrun/gap berkurang.

## Scheduled track

Setiap chunk audio menghasilkan track:

```ts
type ScheduledVisemeTrack = {
  chunkId: string
  startAt: number
  endAt: number
  visemes: Array<{
    at: number
    name: string
    weight: number
  }>
}
```

`at` adalah waktu absolut dalam satuan detik pada clock `AudioContext`.

## Keunggulan dibanding setTimeout langsung

- Viseme mengikuti clock audio, bukan wall-clock biasa.
- Jika audio start tertunda karena buffer, viseme tetap selaras.
- Timeline bisa dibaca ulang setiap frame.
- Lebih siap untuk WebAudio/WebCodecs/AudioWorklet produksi.

## Runtime metrics

Runtime panel menampilkan:

```text
TTS provider: websocket-binary/webaudio-clock queued:0
Audio buffer: <ms>
```

`Audio buffer` adalah perkiraan jarak antara `nextStartTime` dan `AudioContext.currentTime`.

## Batasan saat ini

- Audio masih WAV per chunk.
- Belum ada crossfade antar chunk.
- Belum ada adaptive jitter buffer berdasarkan latency jaringan.
- Belum ada time-stretching jika buffer terlalu rendah.

## Target berikutnya

- Adaptive jitter buffer.
- Crossfade 5–15 ms antar chunk.
- PCM/Opus frame streaming.
- AudioWorklet untuk scheduling level rendah.
- Viseme interpolation/smoothing agar transisi mulut lebih natural.
