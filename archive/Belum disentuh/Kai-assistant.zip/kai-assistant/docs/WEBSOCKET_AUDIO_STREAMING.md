# KAI WebSocket Audio Streaming Simulation

KAI sekarang mendukung simulasi streaming audio lewat WebSocket JSON events.

Ini belum streaming produksi biner, tetapi sudah menguji pipeline real-time:

```text
assistant.delta
voice.audio.chunk
avatar.viseme.chunk
```

## Backend events

### `voice.audio.start`

Dikirim sebelum audio chunk pertama.

```json
{
  "type": "voice.audio.start",
  "session_id": "...",
  "provider": "kai-mock-tts",
  "mode": "chunked-websocket-json",
  "mime_type": "audio/wav"
}
```

### `voice.audio.chunk`

Dikirim per potongan teks jawaban.

```json
{
  "type": "voice.audio.chunk",
  "session_id": "...",
  "index": 0,
  "text": "Halo, saya KAI ",
  "provider": "kai-mock-tts",
  "mime_type": "audio/wav",
  "audio_base64": "...",
  "duration_ms": 720,
  "sample_rate": 22050,
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88},
    {"at_ms": 90, "name": "L", "weight": 0.88}
  ]
}
```

### `avatar.viseme.chunk`

Metadata viseme-only event untuk renderer yang ingin memisahkan audio dan animasi.

```json
{
  "type": "avatar.viseme.chunk",
  "session_id": "...",
  "index": 0,
  "duration_ms": 720,
  "visemes": []
}
```

### `voice.audio.done`

Dikirim setelah semua chunk audio selesai dikirim.

```json
{
  "type": "voice.audio.done",
  "session_id": "..."
}
```

## Frontend R3F

Frontend memiliki mode baru:

```text
TTS mode → stream WS
```

Lokasi kode:

```text
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
frontend-r3f/src/App.tsx
```

Alur frontend:

1. Menerima `voice.audio.chunk` dari `useKaiSocket`.
2. Queue audio chunk berdasarkan `session_id:index`.
3. Decode base64 WAV menjadi Blob.
4. Play chunk berurutan.
5. Saat chunk mulai, jadwalkan viseme berdasarkan `at_ms`.
6. Update `AvatarCommand.viseme`.
7. `KaiAvatar` menerapkan morph target.

## Cara mencoba

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Di Voice Controls:

1. Aktifkan `Auto speak`.
2. Pilih `TTS mode → stream WS`.
3. Kirim pesan.
4. Audio chunk akan dimainkan berurutan, dan viseme bergerak per chunk.

## Batasan saat ini

- Audio dikirim sebagai base64 JSON, bukan binary frame.
- Tiap chunk adalah WAV kecil terpisah; transisi audio bisa terdengar tidak natural.
- Scheduler memakai `setTimeout`, bukan WebAudio clock.

## Target produksi

Untuk produksi, ganti dengan:

- WebSocket binary audio frames, atau
- WebRTC audio data channel/media stream, atau
- HTTP chunked transfer/SSE hybrid,
- WebAudio `AudioBufferSourceNode` scheduling,
- phoneme timestamps dari provider TTS.

Target event produksi:

```text
voice.audio.start
voice.audio.binary_frame
avatar.viseme.frame
voice.audio.done
```
