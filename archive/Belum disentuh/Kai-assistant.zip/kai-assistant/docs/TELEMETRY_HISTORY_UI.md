# KAI Telemetry History UI

Frontend R3F sekarang memiliki panel histori telemetry dengan sparkline mini.

## Lokasi kode

```text
frontend-r3f/src/hooks/useTelemetryHistory.ts
frontend-r3f/src/components/TelemetryHistory.tsx
frontend-r3f/src/components/RuntimePanel.tsx
```

## Data source

Panel mengambil data dari backend:

```text
GET /api/telemetry/recent?session_id=<id>&limit=80
GET /api/telemetry/summary?session_id=<id>&limit=80
```

Data di-refresh otomatis setiap 6 detik dan bisa di-refresh manual melalui tombol `Refresh`.

## Grafik mini

Panel menampilkan sparkline untuk metrik:

- `FPS`
- `Latency`
- `Jitter`
- `Buffer`

Setiap kartu menampilkan:

- nilai terbaru,
- rata-rata,
- maksimum,
- sparkline histori.

## Cara mencoba

Jalankan:

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Biarkan aplikasi berjalan minimal 5–10 detik agar telemetry reporter mengirim beberapa snapshot. Panel kanan Runtime akan menampilkan histori.

## Catatan

Jika belum ada data, panel akan menampilkan `not enough data`. Snapshot dikirim setiap 5 detik oleh:

```text
frontend-r3f/src/hooks/useTelemetryReporter.ts
```

## Target berikutnya

- Grafik lebih lengkap dengan tooltip.
- Export CSV telemetry.
- Filter metric dan session.
- Alert visual jika FPS rendah atau jitter tinggi.
