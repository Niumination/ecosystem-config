# KAI Adaptive Jitter Buffer

KAI sekarang memiliki **adaptive jitter buffer** untuk mode streaming audio WebSocket.

Fitur ini membuat target buffer audio menyesuaikan otomatis berdasarkan variasi waktu kedatangan chunk dari jaringan.

## Mode yang memakai adaptive buffer

```text
TTS mode → stream WS JSON
TTS mode → stream WS binary
```

## Lokasi kode

```text
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
```

## Cara kerja

Setiap kali audio chunk masuk, frontend mencatat waktu kedatangan:

```ts
arrival = performance.now()
interval = arrival - previousArrival
```

Lalu dihitung:

- smoothed inter-arrival interval,
- absolute deviation,
- network jitter estimate,
- adaptive target buffer.

Rumus konseptual:

```ts
smoothedInterval = EMA(interval)
networkJitter = EMA(abs(interval - smoothedInterval))
targetBuffer = clamp(baseBuffer + networkJitter * 2.4, minBuffer, maxBuffer)
```

Buffer naik lebih cepat daripada turun:

```ts
adapt = target > current ? 0.28 : 0.045
current += adapt * (target - current)
```

Tujuannya:

- cepat merespons jaringan tidak stabil,
- lambat menurunkan buffer agar tidak mudah underrun,
- menjaga latency tetap relatif rendah saat jaringan stabil.

## Default parameter

```ts
base jitterBufferMs = 180
minJitterBufferMs = 110
maxJitterBufferMs = 520
```

Nilai ini bisa diubah saat memanggil hook:

```ts
useStreamingAudioQueue({
  jitterBufferMs: 180,
  minJitterBufferMs: 110,
  maxJitterBufferMs: 520,
  onViseme: setStreamViseme
})
```

## Runtime metrics

Runtime panel menampilkan:

```text
Audio buffer: <ms>
Jitter target: <ms>
Network jitter: <ms>
```

Penjelasan:

- `Audio buffer`: estimasi durasi audio yang sudah dijadwalkan ke depan.
- `Jitter target`: target buffer adaptif saat ini.
- `Network jitter`: estimasi deviasi kedatangan chunk.

## Kenapa penting?

Streaming audio real-time sering mengalami variasi kedatangan chunk karena:

- network jitter,
- proses TTS tidak konstan,
- thread main browser sibuk,
- decode audio memakan waktu berbeda.

Adaptive jitter buffer membantu mengurangi gap audio tanpa selalu memakai buffer besar.

## Batasan saat ini

- Adaptasi masih berbasis interval kedatangan chunk, bukan pengukuran underrun aktual.
- Belum ada time-stretching jika buffer terlalu rendah.
- Belum ada crossfade overlap antar chunk.

## Target berikutnya

- Deteksi underrun/gap aktual dari `AudioContext.currentTime` vs `nextStartTime`.
- Adaptive chunk prefetch.
- Time-stretch ringan untuk mengejar latency.
- Statistik jitter per session dikirim ke backend untuk observability.
