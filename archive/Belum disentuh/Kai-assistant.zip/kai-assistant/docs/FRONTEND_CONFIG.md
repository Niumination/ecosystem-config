# Frontend Configuration

Frontend MVP tidak memerlukan build step. File utama: `frontend/index.html`.

## Backend URL

Default frontend mencoba konek ke:

```text
ws://localhost:8000/ws/kai
```

Untuk mengganti backend tanpa edit kode, buka URL dengan query:

```text
http://localhost:4173?backend=127.0.0.1:8000
```

Nilai session disimpan otomatis di `localStorage`:

- `kai_session_id`
- `kai_backend`

Untuk reset session, hapus localStorage browser atau buka DevTools Console:

```js
localStorage.removeItem('kai_session_id')
```

## Mode Offline Demo

Jika WebSocket gagal tersambung, frontend tetap menjalankan:

- chat demo,
- avatar canvas,
- emotion mock,
- lipsync mock,
- browser TTS.

## Upgrade ke Three.js/R3F

Langkah migrasi yang disarankan:

1. Buat app Vite React TypeScript.
2. Tambahkan `three`, `@react-three/fiber`, `@react-three/drei`.
3. Pindahkan WebSocket/event handler dari `index.html` ke hook `useKaiSocket()`.
4. Buat komponen `KaiAvatar.tsx` yang menerima:

```ts
type AvatarCommand = {
  emotion: { name: string; intensity: number }
  morphs: Record<string, number>
  viseme: { name: string; weight: number }
}
```

5. Mapping command ke `mesh.morphTargetInfluences` berdasarkan `morphTargetDictionary`.
