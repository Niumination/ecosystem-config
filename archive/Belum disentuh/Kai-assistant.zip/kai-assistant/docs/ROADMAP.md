# KAI Roadmap Implementasi

## Sprint 1 — MVP Runnable, selesai

- FastAPI backend.
- WebSocket protocol.
- Frontend PWA.
- Avatar canvas stylized.
- Emotion + viseme simulatif.
- Browser STT/TTS.
- Tauri skeleton.

## Sprint 2 — Avatar 3D Asli

- Migrasi frontend ke Vite + React + TypeScript.
- Integrasi Three.js / React Three Fiber.
- Loader GLB/VRM.
- Morph target binding.
- Animation mixer untuk idle, thinking, speaking, listening.
- Eye tracking cursor ringan.

## Sprint 3 — Audio Real-Time

- STT streaming dengan faster-whisper atau provider API.
- Voice activity detection.
- TTS streaming.
- Audio buffer scheduling via WebAudio.
- Viseme alignment dari phoneme timestamps.

## Sprint 4 — LLM Orchestration

- Provider abstraction: Ollama, OpenAI, Mistral.
- Tool calling.
- Long-term memory dengan consent.
- Persona guardrails.
- Context summarization.

## Sprint 5 — Desktop Production

- PyInstaller sidecar final.
- Spawn sidecar otomatis dari Tauri.
- Health check + restart sidecar.
- macOS signing/notarization.
- Linux AppImage/.deb/.rpm QA.
- Auto updater.

## Sprint 6 — Security & Privacy

- Auth/session tokens.
- Secure settings storage.
- Mic permission UX.
- Local-only mode.
- Data export/delete.
