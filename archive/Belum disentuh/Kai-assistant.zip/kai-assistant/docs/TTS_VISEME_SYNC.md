# KAI Backend TTS + Viseme Sync

Frontend R3F sekarang dapat menyinkronkan audio backend WAV dengan viseme timeline dari backend.

## Alur

```text
assistant.start event dari WebSocket
  → frontend melihat Auto Speak aktif
  → jika TTS mode = backend WAV
  → POST /api/tts/synthesize-json
  → backend mengembalikan audio_base64 + visemes[]
  → frontend membuat Blob audio/wav
  → audio.play()
  → saat audio mulai, viseme scheduler dimulai
  → setiap viseme mengubah AvatarCommand.viseme
  → KaiAvatar mengubah morphTargetInfluences pada GLB
```

## Endpoint yang dipakai

```text
POST http://localhost:8000/api/tts/synthesize-json
```

Response penting:

```json
{
  "provider": "kai-mock-tts",
  "mime_type": "audio/wav",
  "audio_base64": "...",
  "duration_ms": 1234,
  "sample_rate": 22050,
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88},
    {"at_ms": 90, "name": "L", "weight": 0.88},
    {"at_ms": 180, "name": "OH", "weight": 0.88}
  ]
}
```

## Lokasi kode frontend

```text
frontend-r3f/src/hooks/useBackendTTS.ts
frontend-r3f/src/App.tsx
frontend-r3f/src/components/KaiAvatar.tsx
```

`useBackendTTS` bertanggung jawab untuk:

- memanggil endpoint TTS JSON,
- decode base64 menjadi Blob WAV,
- memainkan audio,
- menjadwalkan viseme berdasarkan `at_ms`,
- mengirim `{ name, weight }` ke App melalui callback `onViseme`,
- reset ke `REST` saat audio selesai atau dihentikan.

`App.tsx` membuat `effectiveAvatarCommand`:

```ts
const effectiveAvatarCommand = {
  ...kai.avatarCommand,
  viseme: backendViseme
}
```

hanya saat mode TTS adalah `backend`.

## Cara mencoba

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173?model=default
```

Di Voice Controls:

1. Aktifkan `Auto speak`.
2. Pilih `TTS mode → backend WAV`.
3. Kirim pesan ke KAI.
4. Lihat `Runtime → Viseme` berubah mengikuti audio.

## Catatan Akurasi

Saat ini viseme berasal dari generator mock berbasis karakter, bukan phoneme alignment sungguhan. Ini cukup untuk validasi pipeline, namun untuk produksi perlu:

- TTS yang menyediakan phoneme timestamp, atau
- forced alignment setelah audio dibuat, atau
- viseme prediction dari teks + durasi audio.

## Target Produksi

Idealnya backend mengirim audio dan viseme secara streaming:

```text
assistant.delta
voice.audio.chunk
avatar.viseme.chunk
```

Frontend kemudian memakai WebAudio clock sebagai sumber waktu utama, bukan `setTimeout`, untuk sinkronisasi presisi tinggi.
