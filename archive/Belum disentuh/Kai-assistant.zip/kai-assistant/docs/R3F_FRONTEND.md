# KAI React Three Fiber Frontend

Folder:

```text
kai-assistant/frontend-r3f
```

Frontend ini adalah jalur produksi untuk avatar 3D asli. Berbeda dari `frontend/index.html` yang merupakan MVP canvas tanpa dependency, frontend R3F memakai:

- Vite
- React
- TypeScript
- Three.js
- React Three Fiber
- Drei `useGLTF`

## Jalankan

```bash
cd kai-assistant
./scripts/run_backend.sh
```

Terminal lain:

```bash
cd kai-assistant
./scripts/run_frontend_r3f.sh
```

Buka:

```text
http://localhost:5173
```

## Build

```bash
cd kai-assistant/frontend-r3f
npm install
npm run build
```

Build sudah divalidasi sukses pada project ini.

## Mode Avatar

### Fallback Geometry Avatar

Default, tanpa model:

```text
http://localhost:5173
```

Mode ini tetap memakai mesh 3D asli di Three.js, tetapi bukan asset karakter final.

### GLB Default

Project sudah menyertakan placeholder teknis di:

```text
kai-assistant/frontend-r3f/public/models/kai-avatar.glb
```

Asset ini dapat diganti dengan model final dari Blender/artist selama mengikuti kontrak morph target.

Buka:

```text
http://localhost:5173?model=default
```

### GLB Custom

```text
http://localhost:5173?model=/models/kai-avatar-v2.glb
```

### GLB Custom + Morph Mapping

Jika nama morph target tidak cocok dengan kontrak KAI:

```text
http://localhost:5173?model=/models/kai-avatar-v2.glb&morphMap=/config/morph-map.example.json
```

Contoh mapping:

```text
kai-assistant/frontend-r3f/public/config/morph-map.example.json
```

## File Penting

```text
src/hooks/useKaiSocket.ts          # WebSocket integration
src/components/KaiAvatar.tsx       # GLB/VRM morph target binding
src/components/ChatPanel.tsx       # Chat UI
src/components/RuntimePanel.tsx    # Runtime debug panel
src/types/kai.ts                   # Protocol types
```

## Cara Morph Target Dipakai

Backend mengirim event `avatar.command`:

```json
{
  "type": "avatar.command",
  "emotion": {"name": "happy", "intensity": 0.72},
  "morphs": {"smile": 0.65, "browUp": 0.18},
  "viseme": {"name": "AA", "weight": 0.91}
}
```

Frontend melakukan:

```ts
mesh.morphTargetInfluences[index] = value
```

berdasarkan:

```ts
mesh.morphTargetDictionary[name]
```

Jika `morphMap` tersedia, nama KAI diterjemahkan ke nama model terlebih dahulu.

## Catatan Performance

Build saat ini menghasilkan bundle sekitar 1 MB minified karena Three.js/R3F. Untuk produksi skala besar, lakukan:

- code splitting,
- lazy load GLB viewer,
- Draco/KTX2 compression untuk asset,
- manual chunks di Vite/Rollup.
