# KAI WebSocket Binary Audio Frames

Selain mode JSON/base64, KAI sekarang mendukung mode simulasi **WebSocket binary audio frames**.

Mode ini lebih dekat ke arsitektur produksi karena audio tidak dikirim sebagai base64 JSON, melainkan sebagai frame biner setelah metadata JSON.

## Mengaktifkan mode binary

Client mengirim:

```json
{
  "type": "session.audio_transport",
  "mode": "binary"
}
```

Backend membalas:

```json
{
  "type": "session.audio_transport",
  "session_id": "...",
  "mode": "binary"
}
```

Untuk kembali ke JSON/base64:

```json
{
  "type": "session.audio_transport",
  "mode": "json"
}
```

## Event sequence

Untuk setiap chunk audio, backend mengirim:

1. JSON metadata event `voice.audio.chunk.meta`
2. Binary WebSocket frame berisi WAV bytes
3. JSON `avatar.viseme.chunk`

```text
voice.audio.chunk.meta  JSON
<binary WAV frame>      bytes
avatar.viseme.chunk     JSON
```

## Metadata event

```json
{
  "type": "voice.audio.chunk.meta",
  "session_id": "...",
  "chunk_id": "session:index",
  "index": 0,
  "text": "Halo, saya KAI ",
  "provider": "kai-mock-tts",
  "mime_type": "audio/wav",
  "duration_ms": 720,
  "sample_rate": 22050,
  "byte_length": 31902,
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88}
  ]
}
```

Frame berikutnya adalah binary WAV dengan panjang `byte_length`.

## Frontend R3F

Mode UI:

```text
TTS mode → stream WS binary
```

Lokasi kode:

```text
frontend-r3f/src/hooks/useKaiSocket.ts
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
frontend-r3f/src/App.tsx
```

Alur frontend:

1. `useKaiSocket` menerima `voice.audio.chunk.meta` dan menyimpannya sebagai pending metadata.
2. Message WebSocket berikutnya berupa `Blob` binary.
3. Hook membuat event internal `voice.audio.binary.chunk`.
4. `App.tsx` memasukkan Blob ke `useStreamingAudioQueue`.
5. Queue memainkan Blob audio berurutan.
6. Viseme dari metadata dijadwalkan saat audio chunk mulai.
7. `KaiAvatar` menggerakkan morph target GLB.

## Kenapa binary lebih baik dari base64?

- Tidak ada overhead base64 sekitar 33%.
- Lebih cocok untuk chunk audio kecil dan sering.
- Memisahkan metadata JSON dari payload audio.
- Lebih dekat ke desain produksi.

## Batasan saat ini

- Audio masih WAV kecil per chunk, bukan stream PCM/Opus kontinu.
- Scheduler viseme masih memakai `setTimeout`, bukan WebAudio clock.
- Transisi antar chunk bisa terdengar tidak mulus.

## Target produksi berikutnya

- Gunakan Opus/PCM frame, bukan WAV per chunk.
- Decode dan schedule dengan WebAudio `AudioBufferSourceNode`.
- Pakai clock audio sebagai sumber sinkronisasi viseme.
- Pertimbangkan WebRTC untuk audio realtime dua arah.
