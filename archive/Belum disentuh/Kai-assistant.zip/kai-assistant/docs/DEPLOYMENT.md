# Deployment KAI

## 1. Web/PWA

```bash
cd kai-assistant
./scripts/run_frontend.sh
```

Untuk hosting produksi, unggah isi folder `frontend/` ke static hosting/CDN. Backend harus tersedia via HTTPS/WSS.

Checklist:

- `manifest.webmanifest` tersedia.
- `sw.js` terdaftar.
- Backend memakai TLS: `wss://api.example.com/ws/kai`.
- Atur URL backend di frontend jika tidak memakai `localhost`.

## 2. Backend Server

### Local

```bash
cd kai-assistant
./scripts/run_backend.sh
```

### Docker Compose

```bash
cd kai-assistant
docker compose up --build
```

Backend:

```text
http://localhost:8000/health
```

Frontend:

```text
http://localhost:4173
```

## 3. Python Sidecar untuk Tauri

Build binary backend:

```bash
cd kai-assistant
./scripts/build_sidecar.sh
```

Output:

```text
kai-assistant/desktop/bin/kai-backend
kai-assistant/desktop/bin/kai-backend-<target-triple>
```

Tauri memakai nama base di `externalBin` (`../bin/kai-backend`) dan mencari binary dengan suffix target-triple saat packaging. File `src-tauri/src/main.rs` sudah mencoba menjalankan sidecar `kai-backend` pada startup aplikasi.

## 4. Native macOS/Linux dengan Tauri

### Build desktop MVP canvas

```bash
cd kai-assistant
./scripts/build_desktop.sh
```

Atau manual:

```bash
cd kai-assistant/desktop
npm install
npm run build
```

### Build desktop React Three Fiber

Build frontend R3F dan package memakai config alternatif:

```bash
cd kai-assistant
./scripts/build_sidecar.sh
cd desktop
npm install
npm run build:r3f
```

Config R3F:

```text
kai-assistant/desktop/src-tauri/tauri.r3f.conf.json
```

Target bundle:

- macOS: `.dmg`
- Linux: `.AppImage`, `.deb`, `.rpm`

## 5. macOS Signing & Notarization

Untuk distribusi publik macOS, tambahkan environment:

```bash
export APPLE_ID="email@example.com"
export APPLE_PASSWORD="app-specific-password"
export APPLE_TEAM_ID="TEAMID"
export TAURI_SIGNING_PRIVATE_KEY="..."
export TAURI_SIGNING_PRIVATE_KEY_PASSWORD="..."
```

Lalu jalankan build di mesin macOS.

## 6. Linux Notes

Pastikan dependency runtime WebKitGTK/Tauri tersedia pada target distro. Untuk AppImage, uji di Ubuntu LTS dan Fedora terbaru. Untuk `.deb`, uji instalasi bersih:

```bash
sudo apt install ./KAI_0.2.0_amd64.deb
```

## 7. Production Hardening

- Batasi CORS sesuai domain.
- Tambahkan auth/JWT pada WebSocket.
- Enkripsi memory/session jika menyimpan data sensitif.
- Tambahkan opt-in telemetry.
- Tambahkan updater Tauri.
- Pisahkan provider secret dari bundle desktop.
