# KAI Persistent Telemetry Storage

KAI sekarang menyimpan telemetry snapshot ke SQLite.

## Database

Telemetry memakai database yang sama dengan memory percakapan:

```text
backend/data/kai_memory.sqlite3
```

Tabel:

```sql
telemetry_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT,
  source TEXT NOT NULL,
  timestamp_ms REAL,
  metrics_json TEXT NOT NULL,
  created_at REAL NOT NULL
)
```

## Endpoint

### `POST /api/telemetry/snapshot`

Menyimpan snapshot.

```json
{
  "session_id": "abc",
  "source": "kai-frontend-r3f",
  "timestamp_ms": 123456.7,
  "metrics": {
    "fps": 60,
    "latencyMs": 120,
    "bufferedMs": 260,
    "networkJitterMs": 12
  }
}
```

Response:

```json
{
  "ok": true,
  "id": 42,
  "received": {
    "session_id": "abc",
    "source": "kai-frontend-r3f",
    "metric_count": 4
  }
}
```

### `GET /api/telemetry/recent`

Mengambil snapshot terbaru.

Query:

- `session_id`: opsional
- `limit`: default 100, maksimum 500

Contoh:

```bash
curl "http://localhost:8000/api/telemetry/recent?session_id=abc&limit=20"
```

Response:

```json
{
  "items": [
    {
      "id": 42,
      "session_id": "abc",
      "source": "kai-frontend-r3f",
      "timestamp_ms": 123456.7,
      "created_at": 1845123.5,
      "metrics": {
        "fps": 60
      }
    }
  ]
}
```

### `GET /api/telemetry/summary`

Menghasilkan summary numerik dari snapshot terbaru.

Query:

- `session_id`: opsional
- `limit`: default 200

Response:

```json
{
  "count": 10,
  "session_id": "abc",
  "started_at": 1845000.0,
  "last_at": 1845123.5,
  "averages": {
    "fps": 58.4,
    "latencyMs": 132.1
  },
  "max": {
    "networkJitterMs": 42
  },
  "min": {
    "fps": 52
  },
  "latest": {}
}
```

## Service layer

Lokasi:

```text
backend/app/services/telemetry.py
```

Fungsi utama:

- `init_telemetry_db()`
- `add_telemetry_snapshot()`
- `list_recent_telemetry()`
- `telemetry_summary()`
- `delete_old_telemetry()`

## Target berikutnya

- Tambahkan UI grafik telemetry di frontend.
- Tambahkan retention policy otomatis.
- Export metrics ke Prometheus.
- Simpan aggregate per menit untuk long-running sessions.
