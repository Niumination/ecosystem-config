# KAI Real-Time Protocol v0.2

Transport utama adalah WebSocket JSON untuk control/event. Produksi dapat menambahkan binary audio frame pada koneksi yang sama atau channel WebRTC terpisah.

## URL

```text
ws://localhost:8000/ws/kai
ws://localhost:8000/ws/kai?session_id=<existing-session>
```

## Client → Server Events

### `user.text`

```json
{
  "type": "user.text",
  "text": "Jelaskan arsitektur KAI"
}
```

### `user.audio.chunk`

Placeholder MVP. Produksi: kirim metadata JSON atau binary audio chunk.

```json
{
  "type": "user.audio.chunk",
  "format": "pcm16",
  "sample_rate": 16000,
  "seq": 42,
  "data_base64": "..."
}
```

### `session.history`

```json
{
  "type": "session.history"
}
```

### `ping`

```json
{
  "type": "ping"
}
```

## Server → Client Events

### `session.ready`

```json
{
  "type": "session.ready",
  "session_id": "uuid",
  "message": "KAI backend connected",
  "capabilities": {}
}
```

### `stt.final`

```json
{
  "type": "stt.final",
  "session_id": "uuid",
  "text": "Jelaskan arsitektur KAI"
}
```

### `assistant.start`

Dikirim saat backend sudah punya full response dan metadata animasi awal.

```json
{
  "type": "assistant.start",
  "session_id": "uuid",
  "text": "Arsitektur KAI terdiri dari...",
  "emotion": {"name": "focused", "intensity": 0.58},
  "morphs": {"browUp": 0.22, "smile": 0.12},
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88},
    {"at_ms": 180, "name": "R", "weight": 0.88}
  ]
}
```

### `assistant.delta`

```json
{
  "type": "assistant.delta",
  "session_id": "uuid",
  "index": 0,
  "text": "Arsitektur KAI terdiri dari "
}
```

### `avatar.command`

```json
{
  "type": "avatar.command",
  "session_id": "uuid",
  "emotion": {"name": "happy", "intensity": 0.72},
  "morphs": {"smile": 0.65, "browUp": 0.18},
  "viseme": {"name": "AA", "weight": 0.91}
}
```

### `voice.audio.start`

```json
{
  "type": "voice.audio.start",
  "session_id": "uuid",
  "provider": "kai-mock-tts",
  "mode": "chunked-websocket-json",
  "mime_type": "audio/wav"
}
```

### `voice.audio.chunk`

Simulasi audio streaming via JSON base64. Produksi sebaiknya memakai binary frame atau WebRTC.

```json
{
  "type": "voice.audio.chunk",
  "session_id": "uuid",
  "index": 0,
  "text": "Halo, saya KAI ",
  "provider": "kai-mock-tts",
  "mime_type": "audio/wav",
  "audio_base64": "...",
  "duration_ms": 720,
  "sample_rate": 22050,
  "visemes": [
    {"at_ms": 0, "name": "AA", "weight": 0.88}
  ]
}
```

### `avatar.viseme.chunk`

```json
{
  "type": "avatar.viseme.chunk",
  "session_id": "uuid",
  "index": 0,
  "duration_ms": 720,
  "visemes": []
}
```

### `voice.audio.chunk.meta` + binary frame

Jika client mengirim `session.audio_transport` dengan `mode=binary`, backend mengirim metadata JSON lalu frame biner WAV.

```json
{
  "type": "voice.audio.chunk.meta",
  "session_id": "uuid",
  "chunk_id": "uuid:0",
  "index": 0,
  "mime_type": "audio/wav",
  "duration_ms": 720,
  "sample_rate": 22050,
  "byte_length": 31902,
  "visemes": []
}
```

Message WebSocket berikutnya adalah binary frame dengan panjang `byte_length`.

### `voice.audio.done`

```json
{
  "type": "voice.audio.done",
  "session_id": "uuid"
}
```

### `assistant.done`

```json
{
  "type": "assistant.done",
  "session_id": "uuid",
  "text": "full response"
}
```

## Kontrak Avatar GLB/VRM

Frontend produksi harus mencari morph target berikut:

### Expressions

- `neutral`
- `smile`
- `frown`
- `angry`
- `confused`
- `blink_L`
- `blink_R`
- `browUp`
- `browDown`
- `surprised`

### Visemes

- `REST`
- `AA`
- `E`
- `IH`
- `OH`
- `OU`
- `FV`
- `L`
- `MBP`
- `WQ`
- `CH`
- `TH`
- `NDT`
- `R`

Jika asset memakai nama ARKit/VRM berbeda, buat mapping layer di frontend.
