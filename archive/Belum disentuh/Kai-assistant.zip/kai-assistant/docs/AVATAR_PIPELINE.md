# KAI Avatar 3D Pipeline

Dokumen ini menjelaskan cara membuat asset avatar 3D produksi untuk frontend React Three Fiber.

## 1. Target Visual

- Gaya: stylized AAA game art.
- Bentuk: androgini/netral gender, ramah, ekspresif.
- Rambut: biru tua dengan aksen cyan.
- Pakaian: tactical technical productivity jacket, LED accents, cargo pants, gloves.
- Material: PBR stylized, cloth normal, jacket roughness/metalness, emissive LED.

## 2. Format File

Prioritas:

1. `.glb`
2. `.gltf`
3. VRM 1.0 jika memakai ekosistem avatar humanoid.

Lokasi model default frontend R3F:

```text
kai-assistant/frontend-r3f/public/models/kai-avatar.glb
```

## 3. Morph Target Contract

Kontrak formal tersedia di:

```text
kai-assistant/assets/avatar-contract/kai_morph_contract.json
```

Minimal morph target yang disarankan:

### Expressions

- `smile`
- `frown`
- `confused`
- `blink_L`
- `blink_R`
- `browUp`
- `browDown`

### Visemes

- `AA`
- `E`
- `IH`
- `OH`
- `OU`
- `FV`
- `L`
- `MBP`
- `WQ`
- `CH`
- `NDT`
- `R`

Opsional:

- `angry`
- `surprised`
- `TH`

## 4. Blender Export Checklist

1. Model memakai scale realistik: tinggi karakter sekitar 1.7–1.8 unit.
2. Apply transforms sebelum export:

```text
Ctrl+A → Rotation & Scale
```

3. Pastikan normals benar.
4. Pastikan morph shape keys ada pada mesh wajah.
5. Nama shape keys harus cocok dengan kontrak KAI atau sediakan mapping.
6. Export:

```text
File → Export → glTF 2.0
Format: GLB
Include: Selected Objects
Transform: +Y Up jika diperlukan oleh pipeline
Geometry: Apply Modifiers OFF jika shape keys perlu dipertahankan
Animation: ON jika idle animation disertakan
Materials: Export PBR materials
```

## 5. Test di Frontend R3F

Install dependency:

```bash
cd kai-assistant/frontend-r3f
npm install
npm run dev
```

Fallback avatar:

```text
http://localhost:5173
```

Model default:

```text
http://localhost:5173?model=default
```

Model custom:

```text
http://localhost:5173?model=/models/kai-avatar-v2.glb
```

Model custom dengan mapping nama morph:

```text
http://localhost:5173?model=/models/kai-avatar-v2.glb&morphMap=/config/morph-map.example.json
```

## 6. Cara Frontend Menggerakkan Morph

Backend mengirim event:

```json
{
  "type": "avatar.command",
  "emotion": {"name": "happy", "intensity": 0.72},
  "morphs": {"smile": 0.65, "browUp": 0.18},
  "viseme": {"name": "AA", "weight": 0.91}
}
```

Frontend mencari nama morph di `mesh.morphTargetDictionary` dan mengubah `mesh.morphTargetInfluences[index]`.

## 7. Jika Nama Morph Berbeda

Gunakan mapping seperti:

```text
kai-assistant/assets/avatar-contract/morph_name_mapping.example.json
```

Contoh:

```json
{
  "smile": "mouthSmile",
  "AA": "viseme_aa"
}
```

Mapping layer dapat ditambahkan di `frontend-r3f/src/components/KaiAvatar.tsx`.

## 8. Performance Budget

Target desktop:

- 60 FPS.
- 30k–80k triangles untuk avatar utama.
- Texture maksimal 2K per material utama.
- Morph target mesh wajah dipisah dari body jika memungkinkan.
- Gunakan Draco/KTX2 jika ukuran asset besar.

Target web low-end:

- 30 FPS stabil.
- LOD atau texture 1K.
- Kurangi post-processing.
