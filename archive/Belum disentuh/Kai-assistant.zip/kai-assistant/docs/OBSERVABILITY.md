# KAI Observability Dashboard

KAI sekarang memiliki observability runtime untuk memantau performa frontend/avatar/audio streaming.

## Metrik frontend

Runtime panel menampilkan:

- `FPS`
- `Frame time`
- `Long frames`
- `JS heap` jika browser mendukung `performance.memory`
- `Latency`
- `Audio buffer`
- `Jitter target`
- `Network jitter`
- `Audio chunks`
- `Underrun estimate`

Lokasi kode:

```text
frontend-r3f/src/hooks/usePerformanceMetrics.ts
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
frontend-r3f/src/components/RuntimePanel.tsx
```

## Metrik audio streaming

`useStreamingAudioQueue` mengekspos:

```ts
{
  queued,
  scheduled,
  bufferedMs,
  adaptiveJitterBufferMs,
  networkJitterMs,
  receivedChunks,
  underrunEstimate,
  engine
}
```

## Telemetry backend endpoint

Endpoint:

```text
POST /api/telemetry/snapshot
```

Request:

```json
{
  "session_id": "...",
  "source": "kai-frontend-r3f",
  "timestamp_ms": 123456.7,
  "metrics": {
    "fps": 60,
    "latencyMs": 120,
    "networkJitterMs": 14,
    "bufferedMs": 260
  }
}
```

Response:

```json
{
  "ok": true,
  "received": {
    "session_id": "...",
    "source": "kai-frontend-r3f",
    "metric_count": 4
  }
}
```

## Frontend telemetry reporter

Lokasi:

```text
frontend-r3f/src/hooks/useTelemetryReporter.ts
```

Reporter mengirim snapshot setiap 5 detik. Backend sekarang menyimpan snapshot ke SQLite dan menyediakan endpoint histori/summary.

## Target produksi

- Simpan aggregate telemetry ke SQLite/PostgreSQL.
- Expose Prometheus metrics endpoint.
- Tambahkan alert jika FPS rendah, jitter tinggi, atau underrun meningkat.
- Tambahkan dashboard historis per session.
- Tambahkan privacy toggle/opt-in untuk telemetry.
