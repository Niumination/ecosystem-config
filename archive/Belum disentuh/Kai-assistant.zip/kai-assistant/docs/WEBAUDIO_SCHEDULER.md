# KAI WebAudio Scheduler

Streaming audio queue frontend R3F sekarang memakai **WebAudio `AudioContext`**.

Sebelumnya mode streaming memakai `HTMLAudioElement` per chunk. Itu mudah, tetapi transisi antar chunk kurang presisi. Sekarang audio chunk didecode menjadi `AudioBuffer` dan dijadwalkan dengan clock audio.

## Lokasi kode

```text
frontend-r3f/src/hooks/useStreamingAudioQueue.ts
```

Hook ini dipakai untuk mode:

```text
TTS mode → stream WS JSON
TTS mode → stream WS binary
```

## Alur

```text
voice.audio.chunk / voice.audio.binary.chunk
  → enqueue chunk
  → convert base64/blob to ArrayBuffer
  → AudioContext.decodeAudioData()
  → AudioBufferSourceNode
  → source.start(startAt)
  → viseme setTimeout dihitung dari AudioContext.currentTime
  → AvatarCommand.viseme update
  → GLB morph target bergerak
```

## Kenapa WebAudio lebih baik?

- Audio chunks bisa dijadwalkan berurutan dengan gap kecil.
- Timing memakai `AudioContext.currentTime`, lebih stabil daripada event playback HTML audio biasa.
- Binary frame mode dapat langsung decode Blob/ArrayBuffer.
- Lebih dekat ke implementasi produksi untuk PCM/Opus streaming.

## API hook

```ts
const streamAudio = useStreamingAudioQueue({
  onViseme: setStreamViseme
})

streamAudio.enqueue({
  id: 'session:0',
  mime_type: 'audio/wav',
  audio_blob: blob,
  visemes: [{ at_ms: 0, name: 'AA', weight: 0.88 }]
})
```

Return state:

```ts
{
  playing: boolean,
  queued: number,
  scheduled: number,
  engine: 'webaudio',
  error?: string
}
```

## Batasan saat ini

- Audio masih WAV per chunk.
- Viseme masih dijadwalkan dengan `setTimeout`, tetapi delay dihitung terhadap `AudioContext.currentTime`.
- Untuk produksi optimal, viseme sebaiknya dirender di animation loop berdasarkan audio clock, bukan timeout.

## Target berikutnya

- AudioWorklet atau WebCodecs untuk frame PCM/Opus.
- Viseme clock berbasis `AudioContext.currentTime` sudah tersedia melalui requestAnimationFrame loop di `useStreamingAudioQueue`.
- Crossfade kecil antar chunk untuk mengurangi klik/transisi.
- Jitter buffer untuk network latency.
