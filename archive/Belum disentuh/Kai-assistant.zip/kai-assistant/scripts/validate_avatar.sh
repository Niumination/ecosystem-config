#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODEL="${1:-$ROOT/frontend-r3f/public/models/kai-avatar.glb}"
python3 "$ROOT/tools/validate_kai_avatar.py" "$MODEL"
