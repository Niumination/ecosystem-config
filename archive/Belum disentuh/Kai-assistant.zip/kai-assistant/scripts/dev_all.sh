#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
trap 'kill 0' EXIT
"$ROOT/scripts/run_backend.sh" &
sleep 2
"$ROOT/scripts/run_frontend.sh" &
echo "KAI dev running:"
echo "  Frontend: http://localhost:4173"
echo "  Backend : http://localhost:8000/health"
wait
