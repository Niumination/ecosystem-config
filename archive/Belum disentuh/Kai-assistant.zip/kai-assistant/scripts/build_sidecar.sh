#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/backend"
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt pyinstaller
pyinstaller kai_backend.spec --clean --noconfirm
mkdir -p "$ROOT/desktop/bin"
cp dist/kai-backend "$ROOT/desktop/bin/kai-backend"
chmod +x "$ROOT/desktop/bin/kai-backend"
# Tauri sidecar packaging expects a target-triple suffixed binary next to the base name.
if command -v rustc >/dev/null 2>&1; then
  TARGET_TRIPLE="$(rustc -Vv | awk '/host:/ {print $2}')"
else
  TARGET_TRIPLE="$(uname -m)-unknown-linux-gnu"
fi
cp dist/kai-backend "$ROOT/desktop/bin/kai-backend-$TARGET_TRIPLE"
chmod +x "$ROOT/desktop/bin/kai-backend-$TARGET_TRIPLE"
echo "Sidecar built:"
echo "  $ROOT/desktop/bin/kai-backend"
echo "  $ROOT/desktop/bin/kai-backend-$TARGET_TRIPLE"
