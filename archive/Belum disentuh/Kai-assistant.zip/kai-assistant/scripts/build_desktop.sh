#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ ! -x "$ROOT/desktop/bin/kai-backend" ]; then
  echo "Sidecar not found. Building Python sidecar first..."
  "$ROOT/scripts/build_sidecar.sh"
fi
cd "$ROOT/desktop"
npm install
npm run build
