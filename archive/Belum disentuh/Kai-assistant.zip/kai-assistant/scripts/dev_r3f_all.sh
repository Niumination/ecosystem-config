#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
trap 'kill 0' EXIT
"$ROOT/scripts/run_backend.sh" &
sleep 2
"$ROOT/scripts/run_frontend_r3f.sh" &
echo "KAI R3F dev running:"
echo "  Frontend R3F: http://localhost:5173"
echo "  Backend     : http://localhost:8000/health"
wait
