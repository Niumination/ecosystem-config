#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tools/generate_kai_placeholder_glb.py"
python3 "$ROOT/tools/validate_kai_avatar.py" "$ROOT/frontend-r3f/public/models/kai-avatar.glb"
