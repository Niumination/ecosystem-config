use std::sync::Mutex;

use tauri::Manager;
use tauri_plugin_shell::process::CommandChild;
use tauri_plugin_shell::ShellExt;

struct BackendSidecar(Mutex<Option<CommandChild>>);

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .manage(BackendSidecar(Mutex::new(None)))
        .setup(|app| {
            // Start the Python FastAPI backend sidecar when packaged.
            // The sidecar is produced by scripts/build_sidecar.sh and configured in tauri.conf.json:
            //   externalBin: ["../bin/kai-backend"]
            match app.shell().sidecar("kai-backend") {
                Ok(command) => match command.spawn() {
                    Ok((_rx, child)) => {
                        if let Some(state) = app.try_state::<BackendSidecar>() {
                            *state.0.lock().expect("backend sidecar mutex poisoned") = Some(child);
                        }
                        println!("KAI backend sidecar started.");
                    }
                    Err(err) => {
                        eprintln!("Failed to spawn KAI backend sidecar: {err}");
                        eprintln!("Development fallback: run ../../scripts/run_backend.sh manually.");
                    }
                },
                Err(err) => {
                    eprintln!("KAI backend sidecar unavailable: {err}");
                    eprintln!("Development fallback: run ../../scripts/run_backend.sh manually.");
                }
            }
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::Destroyed = event {
                if window.label() == "main" {
                    if let Some(state) = window.try_state::<BackendSidecar>() {
                        if let Some(child) = state.0.lock().expect("backend sidecar mutex poisoned").take() {
                            let _ = child.kill();
                            println!("KAI backend sidecar stopped.");
                        }
                    }
                }
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running KAI desktop app");
}
