# KAI — Interactive AI Avatar Assistant

Prototype lanjutan untuk **KAI (Knowledgeable Artificial Intelligence)**: asisten virtual AI dengan avatar interaktif, chat real-time, emotion state, lipsync/viseme simulatif, PWA, dan skeleton Tauri untuk macOS/Linux.

## Isi Project

```text
kai-assistant/
├─ backend/                 # FastAPI + WebSocket backend
│  ├─ app/main.py
│  └─ app/services/         # LLM adapter, sentiment, viseme
├─ frontend/                # PWA MVP tanpa dependency eksternal
│  ├─ index.html            # UI + avatar canvas interaktif
│  ├─ manifest.webmanifest
│  └─ sw.js
├─ frontend-r3f/            # Frontend produksi Vite + React + Three.js/R3F
│  ├─ src/components/KaiAvatar.tsx
│  ├─ src/hooks/useKaiSocket.ts
│  └─ public/models/
├─ assets/avatar-contract/  # Kontrak morph target GLB/VRM
├─ desktop/                 # Skeleton Tauri v2
│  └─ src-tauri/
└─ scripts/
   ├─ run_backend.sh
   └─ run_frontend.sh
```

## Jalankan Prototype Web MVP Canvas

Terminal 1:

```bash
cd kai-assistant
./scripts/run_backend.sh
```

Terminal 2:

```bash
cd kai-assistant
./scripts/run_frontend.sh
```

Buka:

```text
http://localhost:4173
```

Jika backend belum berjalan, frontend tetap bekerja dalam **offline demo mode**.

## Jalankan Frontend Produksi React Three Fiber

Terminal 1:

```bash
cd kai-assistant
./scripts/run_backend.sh
```

Terminal 2:

```bash
cd kai-assistant
./scripts/run_frontend_r3f.sh
```

Atau sekaligus:

```bash
cd kai-assistant
./scripts/dev_r3f_all.sh
```

Buka:

```text
http://localhost:5173
```

Dengan model GLB default:

```text
http://localhost:5173?model=default
```

Project sudah menyediakan placeholder GLB teknis di:

```text
kai-assistant/frontend-r3f/public/models/kai-avatar.glb
```

Generate ulang / validasi:

```bash
./scripts/generate_avatar_placeholder.sh
./scripts/validate_avatar.sh
```

Kontrak morph target ada di:

```text
kai-assistant/assets/avatar-contract/kai_morph_contract.json
```

## Endpoint Backend

- Health check: `GET http://localhost:8000/health`
- Config: `GET http://localhost:8000/api/config`
- Morph targets: `GET http://localhost:8000/api/avatar/morph-targets`
- Voices: `GET http://localhost:8000/api/tts/voices`
- TTS WAV: `POST http://localhost:8000/api/tts/synthesize`
- TTS JSON/base64: `POST http://localhost:8000/api/tts/synthesize-json`
- STT upload: `POST http://localhost:8000/api/stt/transcribe`
- Telemetry snapshot: `POST http://localhost:8000/api/telemetry/snapshot`
- Telemetry recent: `GET http://localhost:8000/api/telemetry/recent`
- Telemetry summary: `GET http://localhost:8000/api/telemetry/summary`
- Sessions: `GET http://localhost:8000/api/sessions`
- Session messages: `GET http://localhost:8000/api/sessions/{session_id}/messages`
- WebSocket: `ws://localhost:8000/ws/kai`

Contoh event client:

```json
{
  "type": "user.text",
  "text": "Jelaskan arsitektur KAI"
}
```

Contoh event avatar dari backend:

```json
{
  "type": "avatar.command",
  "emotion": {"name": "focused", "intensity": 0.58},
  "morphs": {"browUp": 0.22, "smile": 0.12},
  "viseme": {"name": "AA", "weight": 0.88}
}
```

## Menjalankan Test Backend

```bash
cd kai-assistant/backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
```

Saat terakhir dijalankan, hasilnya:

```text
7 passed
```

## Menghubungkan Ollama / Llama Lokal

Install dan jalankan Ollama, lalu:

```bash
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=llama3.1
./scripts/run_backend.sh
```

Jika Ollama tidak tersedia, backend otomatis memakai respons mock.

## Dokumentasi Tambahan

```text
kai-assistant/docs/PROTOCOL.md
kai-assistant/docs/DEPLOYMENT.md
kai-assistant/docs/ROADMAP.md
kai-assistant/docs/FRONTEND_CONFIG.md
kai-assistant/docs/R3F_FRONTEND.md
kai-assistant/docs/AVATAR_PIPELINE.md
kai-assistant/docs/PLACEHOLDER_AVATAR.md
kai-assistant/docs/VOICE_LAYER.md
kai-assistant/docs/BACKEND_AUDIO.md
kai-assistant/docs/TTS_VISEME_SYNC.md
kai-assistant/docs/WEBSOCKET_AUDIO_STREAMING.md
kai-assistant/docs/WEBSOCKET_BINARY_AUDIO.md
kai-assistant/docs/WEBAUDIO_SCHEDULER.md
kai-assistant/docs/CLOCK_BASED_VISEME.md
kai-assistant/docs/AUDIO_CROSSFADE_VISEME_SMOOTHING.md
kai-assistant/docs/ADAPTIVE_JITTER_BUFFER.md
kai-assistant/docs/OBSERVABILITY.md
kai-assistant/docs/PERSISTENT_TELEMETRY.md
kai-assistant/docs/TELEMETRY_HISTORY_UI.md
kai-assistant/docs/PERFORMANCE_ALERTS.md
```

## Native Desktop dengan Tauri

> Membutuhkan Node.js, Rust, PyInstaller, dan Tauri prerequisites OS.

Build sidecar Python lalu native bundle:

```bash
cd kai-assistant
./scripts/build_desktop.sh
```

Atau manual:

```bash
cd kai-assistant
./scripts/build_sidecar.sh
cd desktop
npm install
npm run build
```

Target bundle dikonfigurasi untuk:

- macOS: `.dmg`
- Linux: `.AppImage`, `.deb`, `.rpm`

Catatan: PyInstaller sidecar sudah disiapkan sebagai `externalBin`, dan lifecycle Tauri sudah memiliki hook startup untuk mencoba menjalankan `kai-backend` secara otomatis. Saat development, backend tetap bisa dijalankan manual dengan `./scripts/run_backend.sh`.

## Fitur MVP Saat Ini

- UI chat modern
- Avatar stylized pseudo-3D berbasis canvas
- Frontend produksi React Three Fiber dengan fallback avatar 3D
- Loader GLB/VRM-ready via `useGLTF`
- Placeholder `kai-avatar.glb` dengan morph targets sesuai kontrak
- Validator GLB/GLTF untuk morph target contract
- Kontrak morph target avatar GLB/VRM
- Emotion state: neutral, happy, focused, concerned, confused
- Lipsync/viseme simulatif
- Voice controls di frontend R3F
- Browser TTS via `speechSynthesis`
- Backend mock TTS WAV endpoint untuk pipeline testing
- Simulasi WebSocket audio chunk streaming dengan viseme per chunk
- Mode WebSocket binary audio frames untuk payload WAV tanpa base64
- Browser STT push-to-talk via `SpeechRecognition` jika didukung
- STT upload endpoint dengan adapter opsional `faster-whisper`
- FastAPI WebSocket streaming text event
- Memory percakapan berbasis SQLite
- REST API untuk config, voices, sessions, dan morph targets
- PWA manifest dan service worker
- Tauri packaging skeleton
- PyInstaller spec untuk backend sidecar
- Docker Compose untuk web/backend local deployment

## Next Step Produksi

1. Sediakan asset avatar `.glb`/VRM final sesuai kontrak morph target.
2. Tambahkan mapping morph jika nama shape key dari artist berbeda.
3. Aktifkan STT streaming: `faster-whisper` atau provider API.
4. Aktifkan TTS streaming: StyleTTS 2 / ElevenLabs / Azure.
5. Buat viseme timeline dari phoneme timestamps TTS.
6. Bundle backend Python sebagai sidecar Tauri.
7. Signing/notarization macOS dan packaging Linux final.
