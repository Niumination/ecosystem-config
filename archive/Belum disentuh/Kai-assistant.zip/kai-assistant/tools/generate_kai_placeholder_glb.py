#!/usr/bin/env python3
"""Generate a lightweight placeholder KAI avatar GLB with morph targets.

This is not the final art asset. It is a technical contract asset that proves:
- Three.js/R3F can load a KAI GLB.
- The face mesh contains morph target names expected by the KAI protocol.
- avatar.command events can drive expression and viseme morphs.

No third-party Python dependency is required.
"""
from __future__ import annotations

import json
import math
import struct
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "frontend-r3f" / "public" / "models" / "kai-avatar.glb"
CONTRACT_NAMES = [
    "smile",
    "frown",
    "angry",
    "confused",
    "blink_L",
    "blink_R",
    "browUp",
    "browDown",
    "surprised",
    "AA",
    "E",
    "IH",
    "OH",
    "OU",
    "FV",
    "L",
    "MBP",
    "WQ",
    "CH",
    "TH",
    "NDT",
    "R",
]


def align4(data: bytes, pad: bytes = b"\x00") -> bytes:
    return data + pad * ((4 - len(data) % 4) % 4)


class Bin:
    def __init__(self) -> None:
        self.data = bytearray()
        self.buffer_views: list[dict] = []
        self.accessors: list[dict] = []

    def add_view(self, raw: bytes, target: int | None = None) -> int:
        offset = len(self.data)
        self.data += raw
        while len(self.data) % 4:
            self.data += b"\x00"
        view = {"buffer": 0, "byteOffset": offset, "byteLength": len(raw)}
        if target is not None:
            view["target"] = target
        self.buffer_views.append(view)
        return len(self.buffer_views) - 1

    def add_accessor_f32(self, values: list[float], type_: str, target: int | None = None) -> int:
        raw = struct.pack("<" + "f" * len(values), *values)
        view = self.add_view(raw, target)
        comps = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[type_]
        accessor = {
            "bufferView": view,
            "byteOffset": 0,
            "componentType": 5126,
            "count": len(values) // comps,
            "type": type_,
        }
        if type_ == "VEC3" and values:
            triples = list(zip(values[0::3], values[1::3], values[2::3]))
            accessor["min"] = [min(v[i] for v in triples) for i in range(3)]
            accessor["max"] = [max(v[i] for v in triples) for i in range(3)]
        self.accessors.append(accessor)
        return len(self.accessors) - 1

    def add_accessor_u16(self, values: list[int], target: int | None = None) -> int:
        raw = struct.pack("<" + "H" * len(values), *values)
        view = self.add_view(raw, target)
        self.accessors.append(
            {
                "bufferView": view,
                "byteOffset": 0,
                "componentType": 5123,
                "count": len(values),
                "type": "SCALAR",
                "min": [min(values) if values else 0],
                "max": [max(values) if values else 0],
            }
        )
        return len(self.accessors) - 1


def sphere_mesh(rx: float, ry: float, rz: float, rows: int = 18, cols: int = 28) -> tuple[list[tuple[float, float, float]], list[int]]:
    vertices: list[tuple[float, float, float]] = []
    for r in range(rows + 1):
        theta = math.pi * r / rows
        y = math.cos(theta) * ry
        ring = math.sin(theta)
        for c in range(cols):
            phi = 2 * math.pi * c / cols
            x = math.cos(phi) * ring * rx
            z = math.sin(phi) * ring * rz
            vertices.append((x, y, z))
    indices: list[int] = []
    for r in range(rows):
        for c in range(cols):
            a = r * cols + c
            b = r * cols + (c + 1) % cols
            d = (r + 1) * cols + c
            e = (r + 1) * cols + (c + 1) % cols
            indices += [a, d, b, b, d, e]
    return vertices, indices


def cube_mesh(w: float, h: float, d: float) -> tuple[list[tuple[float, float, float]], list[int]]:
    x, y, z = w / 2, h / 2, d / 2
    v = [
        (-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z),
        (x, -y, -z), (-x, -y, -z), (-x, y, -z), (x, y, -z),
        (-x, -y, -z), (-x, -y, z), (-x, y, z), (-x, y, -z),
        (x, -y, z), (x, -y, -z), (x, y, -z), (x, y, z),
        (-x, y, z), (x, y, z), (x, y, -z), (-x, y, -z),
        (-x, -y, -z), (x, -y, -z), (x, -y, z), (-x, -y, z),
    ]
    i = []
    for f in range(6):
        o = f * 4
        i += [o, o + 1, o + 2, o, o + 2, o + 3]
    return v, i


def flatten_vec3(vertices: Iterable[tuple[float, float, float]]) -> list[float]:
    out: list[float] = []
    for x, y, z in vertices:
        out.extend([x, y, z])
    return out


def normals_for(vertices: list[tuple[float, float, float]]) -> list[float]:
    out: list[float] = []
    for x, y, z in vertices:
        length = math.sqrt(x * x + y * y + z * z) or 1
        out.extend([x / length, y / length, z / length])
    return out


def face_delta(name: str, vertices: list[tuple[float, float, float]]) -> list[float]:
    """Generate simple position deltas for visible morph testing."""
    deltas: list[float] = []
    for x, y, z in vertices:
        dx = dy = dz = 0.0
        front = max(0.0, z)
        mouth = max(0.0, 1.0 - abs(y + 0.32) / 0.22) * max(0.0, 1.0 - abs(x) / 0.42) * front
        eyes = max(0.0, 1.0 - abs(y - 0.18) / 0.18) * max(0.0, 1.0 - (abs(abs(x) - 0.24) / 0.20)) * front
        brows = max(0.0, 1.0 - abs(y - 0.38) / 0.16) * max(0.0, 1.0 - (abs(abs(x) - 0.24) / 0.24)) * front
        cheeks = max(0.0, 1.0 - abs(y + 0.05) / 0.35) * max(0.0, 1.0 - abs(abs(x) - 0.36) / 0.25) * front

        if name == "smile":
            dy += mouth * (0.10 + 0.06 * abs(x))
            dz += cheeks * 0.04
        elif name == "frown":
            dy -= mouth * 0.09
        elif name == "angry":
            dy -= brows * 0.09
            dz += brows * 0.025
        elif name == "confused":
            dy += brows * (0.10 if x < 0 else -0.03)
            dx += mouth * 0.025
        elif name == "blink_L" and x < 0:
            dy -= eyes * 0.12
        elif name == "blink_R" and x > 0:
            dy -= eyes * 0.12
        elif name == "browUp":
            dy += brows * 0.10
        elif name == "browDown":
            dy -= brows * 0.08
        elif name == "surprised":
            dy += brows * 0.13
            dy -= mouth * 0.08
            dz += mouth * 0.08
        elif name in {"AA", "OH", "OU"}:
            dy -= mouth * {"AA": 0.16, "OH": 0.12, "OU": 0.09}[name]
            dz += mouth * {"AA": 0.04, "OH": 0.10, "OU": 0.13}[name]
        elif name in {"E", "IH"}:
            dx += math.copysign(mouth * 0.08, x or 1)
            dy -= mouth * 0.045
        elif name in {"FV", "MBP"}:
            dy += mouth * 0.03
            dz -= mouth * 0.04
        elif name in {"L", "NDT", "R", "TH"}:
            dy -= mouth * 0.06
            dx += math.sin(x * 8) * mouth * 0.025
        elif name in {"WQ", "CH"}:
            dx -= math.copysign(mouth * 0.05, x or 1)
            dz += mouth * 0.08

        deltas.extend([dx, dy, dz])
    return deltas


def add_mesh(bin_: Bin, vertices: list[tuple[float, float, float]], indices: list[int], material: int, morph_names: list[str] | None = None) -> dict:
    pos = bin_.add_accessor_f32(flatten_vec3(vertices), "VEC3", target=34962)
    nor = bin_.add_accessor_f32(normals_for(vertices), "VEC3", target=34962)
    idx = bin_.add_accessor_u16(indices, target=34963)
    primitive: dict = {"attributes": {"POSITION": pos, "NORMAL": nor}, "indices": idx, "material": material}
    if morph_names:
        primitive["targets"] = []
        for name in morph_names:
            acc = bin_.add_accessor_f32(face_delta(name, vertices), "VEC3", target=34962)
            primitive["targets"].append({"POSITION": acc})
    return {"primitives": [primitive]}


def build() -> None:
    bin_ = Bin()
    materials = [
        {"name": "KAI_skin", "pbrMetallicRoughness": {"baseColorFactor": [0.78, 0.48, 0.40, 1], "roughnessFactor": 0.62, "metallicFactor": 0.02}},
        {"name": "KAI_hair_navy", "pbrMetallicRoughness": {"baseColorFactor": [0.02, 0.09, 0.22, 1], "roughnessFactor": 0.35, "metallicFactor": 0.05}},
        {"name": "KAI_jacket", "pbrMetallicRoughness": {"baseColorFactor": [0.04, 0.09, 0.18, 1], "roughnessFactor": 0.42, "metallicFactor": 0.16}},
        {"name": "KAI_cyan_emissive", "pbrMetallicRoughness": {"baseColorFactor": [0.0, 0.8, 1.0, 1], "roughnessFactor": 0.25, "metallicFactor": 0.2}, "emissiveFactor": [0.0, 0.9, 1.0]},
        {"name": "KAI_violet_emissive", "pbrMetallicRoughness": {"baseColorFactor": [0.45, 0.32, 1.0, 1], "roughnessFactor": 0.25, "metallicFactor": 0.2}, "emissiveFactor": [0.35, 0.22, 1.0]},
    ]

    meshes: list[dict] = []
    nodes: list[dict] = []

    face_v, face_i = sphere_mesh(0.55, 0.72, 0.47)
    face_mesh = add_mesh(bin_, face_v, face_i, 0, CONTRACT_NAMES)
    face_mesh["name"] = "KAI_Face_morph_contract"
    face_mesh["extras"] = {"targetNames": CONTRACT_NAMES}
    face_mesh["weights"] = [0.0] * len(CONTRACT_NAMES)
    meshes.append(face_mesh)
    nodes.append({"name": "KAI_Face", "mesh": 0, "translation": [0, 0.82, 0]})

    hair_v, hair_i = sphere_mesh(0.62, 0.34, 0.50, rows=10, cols=24)
    meshes.append(add_mesh(bin_, hair_v, hair_i, 1))
    nodes.append({"name": "KAI_Hair", "mesh": 1, "translation": [0, 1.30, -0.04], "scale": [1.0, 0.78, 1.0]})

    body_v, body_i = sphere_mesh(0.72, 0.96, 0.36, rows=14, cols=24)
    meshes.append(add_mesh(bin_, body_v, body_i, 2))
    nodes.append({"name": "KAI_Technical_Jacket", "mesh": 2, "translation": [0, -0.38, 0], "scale": [1.0, 1.0, 0.85]})

    strip_v, strip_i = cube_mesh(0.045, 1.05, 0.035)
    meshes.append(add_mesh(bin_, strip_v, strip_i, 3))
    nodes.append({"name": "KAI_LED_Cyan_Left", "mesh": 3, "translation": [-0.34, -0.36, 0.34], "rotation": [0, 0, -0.15, 0.988]})

    meshes.append(add_mesh(bin_, strip_v, strip_i, 4))
    nodes.append({"name": "KAI_LED_Violet_Right", "mesh": 4, "translation": [0.34, -0.36, 0.34], "rotation": [0, 0, 0.15, 0.988]})

    gltf = {
        "asset": {"version": "2.0", "generator": "KAI placeholder GLB generator v0.4"},
        "scene": 0,
        "scenes": [{"name": "KAI Placeholder Scene", "nodes": list(range(len(nodes)))}],
        "nodes": nodes,
        "meshes": meshes,
        "materials": materials,
        "buffers": [{"byteLength": len(bin_.data)}],
        "bufferViews": bin_.buffer_views,
        "accessors": bin_.accessors,
        "extensionsUsed": [],
        "extras": {
            "kai": {
                "purpose": "technical placeholder avatar",
                "morphTargetContract": CONTRACT_NAMES,
                "note": "Replace with final stylized AAA character art before production release.",
            }
        },
    }

    json_bytes = align4(json.dumps(gltf, separators=(",", ":")).encode("utf-8"), b" ")
    bin_bytes = align4(bytes(bin_.data), b"\x00")
    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_bytes)
    glb = bytearray()
    glb += struct.pack("<4sII", b"glTF", 2, total_len)
    glb += struct.pack("<I4s", len(json_bytes), b"JSON")
    glb += json_bytes
    glb += struct.pack("<I4s", len(bin_bytes), b"BIN\x00")
    glb += bin_bytes
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(glb)
    print(f"Wrote {OUT} ({OUT.stat().st_size / 1024:.1f} KiB)")


if __name__ == "__main__":
    build()
