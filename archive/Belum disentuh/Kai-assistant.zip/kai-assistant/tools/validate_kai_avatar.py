#!/usr/bin/env python3
"""Validate KAI avatar GLB/GLTF morph target contract.

Usage:
  python tools/validate_kai_avatar.py frontend-r3f/public/models/kai-avatar.glb
"""
from __future__ import annotations

import json
import struct
import sys
from pathlib import Path

REQUIRED = {
    "smile",
    "frown",
    "confused",
    "blink_L",
    "blink_R",
    "browUp",
    "browDown",
    "AA",
    "E",
    "IH",
    "OH",
    "OU",
    "FV",
    "L",
    "MBP",
    "WQ",
    "CH",
    "NDT",
    "R",
}
OPTIONAL = {"angry", "surprised", "TH", "REST", "neutral"}


def load_gltf(path: Path) -> dict:
    raw = path.read_bytes()
    if path.suffix.lower() == ".gltf":
        return json.loads(raw.decode("utf-8"))
    if raw[:4] != b"glTF":
        raise ValueError("Not a GLB file: missing glTF magic")
    magic, version, total_len = struct.unpack_from("<4sII", raw, 0)
    if version != 2:
        raise ValueError(f"Unsupported GLB version: {version}")
    offset = 12
    while offset < total_len:
        chunk_len, chunk_type = struct.unpack_from("<I4s", raw, offset)
        offset += 8
        chunk = raw[offset : offset + chunk_len]
        offset += chunk_len
        if chunk_type == b"JSON":
            return json.loads(chunk.rstrip(b" \x00").decode("utf-8"))
    raise ValueError("GLB JSON chunk not found")


def collect_target_names(gltf: dict) -> set[str]:
    names: set[str] = set()
    for mesh in gltf.get("meshes", []):
        extras = mesh.get("extras") or {}
        for name in extras.get("targetNames", []):
            names.add(str(name))
        # Some exporters put targetNames at primitive extras level.
        for prim in mesh.get("primitives", []):
            pextras = prim.get("extras") or {}
            for name in pextras.get("targetNames", []):
                names.add(str(name))
    return names


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__.strip())
        return 2
    path = Path(argv[1])
    if not path.exists():
        print(f"ERROR: file not found: {path}")
        return 2
    gltf = load_gltf(path)
    names = collect_target_names(gltf)
    missing = sorted(REQUIRED - names)
    optional_missing = sorted(OPTIONAL - names)
    print(f"Avatar: {path}")
    print(f"Found morph targets ({len(names)}): {', '.join(sorted(names)) or '-'}")
    if missing:
        print("ERROR: missing required KAI morph targets:")
        for name in missing:
            print(f"  - {name}")
        return 1
    if optional_missing:
        print("Optional targets not present:")
        for name in optional_missing:
            print(f"  - {name}")
    print("OK: KAI avatar morph contract satisfied.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
