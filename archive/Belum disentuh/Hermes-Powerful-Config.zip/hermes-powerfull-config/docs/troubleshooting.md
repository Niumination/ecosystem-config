# 📖 TROUBLESHOOTING GUIDE

## Quick Fix Index

| Problem | Quick Fix |
|---------|-----------|
| Hermes not starting | `hermes --version` then `curl -fsSL .../install.sh \| bash` |
| MCP server error | `node --version` + `uv pip install -e ".[mcp]"` |
| OpenCode not connecting | `opencode --version` + `opencode /connect` |
| API key not working | Check `.env` file + `echo $VAR_NAME` |
| Model not responding | Check API key validity + rate limits |
| File permission error | `chmod +x` script + check ownership |
| GitHub MCP failing | Verify `GITHUB_TOKEN` in `.env` |
| Supabase connection error | Check `SUPABASE_URL` + `SUPABASE_KEY` |

---

## Hermes Agent Issues

### Issue: Hermes command not found
```bash
# Check if Hermes is installed
hermes --version

# If not installed, reinstall
curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash

# Source bashrc
source ~/.bashrc

# Verify installation
hermes --version
```

### Issue: Hermes starts but models not loading
```bash
# Check API keys are set
echo $OPENROUTER_API_KEY
echo $GROQ_API_KEY

# If empty, set them
export OPENROUTER_API_KEY=your-key
export GROQ_API_KEY=your-key

# Test connection
curl -s https://openrouter.ai/api/v1/models \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" | head

# Use fallback model
hermes model set groq/llama-3.1-8b-instant
```

### Issue: Memory system not working
```bash
# Check memory files exist
ls -la ~/.hermes/memories/

# Enable memory
hermes config set memory.enabled true

# Rebuild memory index
hermes memory rebuild

# Check session FTS5
sqlite3 ~/.hermes/sessions/*.db "SELECT name FROM sqlite_master WHERE type='table'"
```

---

## OpenCode Zen Issues

### Issue: OpenCode not installed
```bash
# Install via npm
npm install -g opencode-ai

# Verify
opencode --version

# Start with config
opencode --config opencode-zen-config.json
```

### Issue: OpenCode Zen models not available
```bash
# Connect to Zen provider
opencode /connect
# Select: OpenCode Zen
# Paste API key from https://opencode.ai/zen

# List available models
opencode /models

# Test specific model
opencode -m opencode/big-pickle "Hello"
```

### Issue: Token limit exceeded
```
Solution:
1. Use smaller model (llama-3.1-8b-instant via Groq)
2. Clear conversation history
3. Increase context by breaking into smaller chunks
4. Use compression mode
```

---

## MCP Servers Issues

### Issue: MCP server not connecting
```bash
# Verify Node.js is installed
node --version
# Should be v18 or higher

# Install MCP support in Hermes
cd ~/.hermes/hermes-agent
uv pip install -e ".[mcp]"

# List installed MCP servers
hermes mcp list

# Test specific MCP
hermes mcp test filesystem
```

### Issue: GitHub MCP authentication failed
```bash
# Verify GITHUB_TOKEN is set
echo $GITHUB_TOKEN

# Check token permissions
# Go to: https://github.com/settings/tokens
# Verify scopes: repo, workflow, read:user

# Regenerate token if needed
# Settings > Developer settings > Personal access tokens > Fine-grained tokens
```

### Issue: Playwright MCP not working
```bash
# Install Playwright
npm install -g playwright
npx playwright install

# Verify Chrome/Chromium is installed
npx playwright install chromium

# Test browser
opencode "open browser and go to google.com"
```

---

## Model Provider Issues

### OpenRouter
```bash
# Test OpenRouter connection
curl -s https://openrouter.ai/api/v1/models \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" | head -c 500

# Check rate limits
# Free tier: 20 req/min, 1000 req/day

# If rate limited, wait and retry
# Or use fallback: groq/llama-3.1-8b-instant
```

### Groq
```bash
# Test Groq connection
curl -s https://api.groq.com/openai/v1/models \
  -H "Authorization: Bearer $GROQ_API_KEY" | head -c 500

# Check usage at: https://console.groq.com/
# Free tier: 14,400 req/day
# Reset at midnight PST
```

### Google AI Studio
```bash
# Test Google connection
curl -s "https://generativelanguage.googleapis.com/v1/models?key=$GOOGLE_API_KEY" \
  | head -c 500

# Check quota at: https://aistudio.google.com/
# Free tier: 1M tokens/min, 1500 req/day
```

### DeepSeek
```bash
# Test DeepSeek connection
curl -s https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY" | head -c 500

# Check usage at: https://platform.deepseek.com/
# Free tier: 500K tokens/day
```

---

## Database Issues

### Supabase Connection Failed
```bash
# Verify SUPABASE_URL format
echo $SUPABASE_URL
# Should be: https://xxxxx.supabase.co

# Verify SUPABASE_KEY
echo $SUPABASE_ANON_KEY | cut -c1-20

# Test connection via CLI
npx supabase status

# Check project status at: https://supabase.com/dashboard
```

### PostgreSQL Connection
```bash
# Test direct PostgreSQL connection
psql $SUPABASE_DB_URL -c "SELECT version();"

# Check connection string format
# postgresql://postgres:password@host:port/database

# Verify SSL
PGSSLMODE=require psql $SUPABASE_DB_URL -c "SELECT 1"
```

---

## Skill Issues

### Skill not loading
```bash
# List available skills
hermes skills list

# Check skill directory
ls -la ~/.hermes/skills/

# Manual activate skill
/hermes activate surat-resmi

# Reload skills
hermes skills reload
```

### Skill execution error
```bash
# Check skill file syntax
cat ~/.hermes/skills/pemerintahan/surat-resmi/SKILL.md | head -50

# Verify Markdown format
python3 -c "import markdown; print('OK')" 2>/dev/null || echo "Install: pip install markdown"

# Test skill manually
hermes execute skill:surat-resmi --help
```

---

## System Issues

### Permission Denied
```bash
# Fix script permissions
chmod +x ~/.hermes/setup/hermes-setup.sh
chmod +x ~/.hermes/setup/install-mcp-servers.sh

# Fix directory permissions
chmod 755 ~/.hermes
chmod 700 ~/.hermes/.env

# Fix file ownership
chown -R $(whoami) ~/.hermes
```

### Disk Space Low
```bash
# Check disk usage
df -h ~

# Clean cache
rm -rf ~/.hermes/sessions/*
rm -rf ~/.cache/*
rm -rf /tmp/hermes-*

# Clean npm cache
npm cache clean --force

# Clean Docker (if using)
docker system prune -a
```

### Memory Usage High
```bash
# Check memory
top -o rsize | head -20

# Check Hermes memory
ps aux | grep hermes

# Clear session history
rm ~/.hermes/sessions/*.db
hermes memory rebuild
```

---

## Network Issues

### Connection Timeout
```bash
# Test internet connectivity
curl -I https://openrouter.ai

# Test specific provider
curl -I https://api.groq.com
curl -I https://api.deepseek.com

# Check DNS
nslookup openrouter.ai
```

### Proxy/Firewall Blocking
```bash
# Set proxy if needed
export HTTP_PROXY=http://proxy:port
export HTTPS_PROXY=http://proxy:port

# Or disable proxy for specific hosts
export NO_PROXY=localhost,127.0.0.1,openrouter.ai,groq.com
```

---

## Recovery Procedures

### Complete Reset
```bash
# Backup current config
cp -r ~/.hermes ~/.hermes-backup-$(date +%Y%m%d)

# Remove Hermes
rm -rf ~/.hermes

# Reinstall
curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash

# Restore from backup
cp -r ~/.hermes-backup-YYYYMMDD/* ~/.hermes/

# Copy .env
cp ~/.hermes-backup-YYYYMMDD/.env ~/.hermes/.env
```

### Emergency Recovery
```bash
# If stuck at boot:
# 1. Press Ctrl+C to cancel
# 2. Reset NVRAM: sudo nvram -c
# 3. Kill stuck process: pkill -f hermes

# If API rate limited:
# 1. Wait 1 minute
# 2. Use fallback provider
# 3. Switch to local model (Ollama)
```

---

## Getting Help

### Check Documentation
1. `README.md` - Main documentation
2. `AUDIT.md` - Known issues and fixes
3. `skills/*/SKILL.md` - Specific skill docs

### Generate Debug Report
```bash
# Generate debug info
hermes debug --full > debug-report.txt

# Include in issue report:
# - Hermes version
# - OS and version
# - Error messages
# - Steps to reproduce
```

### Community Support
- GitHub Issues: https://github.com/niumination/hermes-powerfull-config/issues
- Hermes GitHub: https://github.com/nousresearch/hermes-agent/issues
- Discord: Join Hermes Discord

---

**Last Updated: 20 Juni 2026**