# 👤 USER PROFILE - Niumination
## Updated: 19 Juni 2026

---

## Identitas

| Field | Value |
|-------|-------|
| **Nama** | Niumination |
| **Username GitHub** | niumination |
| **GitHub URL** | https://github.com/niumination |
| **Website** | https://niumination.github.io/niu-dash |

---

## Karir & Jabatan

| Field | Value |
|-------|-------|
| **Jabatan** | Pranata Komputer Terampil |
| **Golongan** | II/D |
| **Instansi** | Dinas Komunikasi dan Informatika |
| **Kabupaten/Kota** | Aceh Tengah |
| **Provinsi** | Aceh, Indonesia |

---

## Hardware Setup

```
┌─────────────────────────────────────────────────┐
│  ThinkPad X13 Yoga Gen 1                        │
├─────────────────────────────────────────────────┤
│  CPU: Intel Core i5 (10th Gen)                  │
│  RAM: 16GB DDR4                                 │
│  Storage: 512GB NVMe SSD                        │
│  Display: 13.3" FHD Touchscreen                │
│  OS: macOS (Hackintosh) + Windows + Linux      │
│  Portable Setup: Hermes-USB-Portable            │
└─────────────────────────────────────────────────┘
```

---

## Tools & Technologies

### Primary Tools
- **AI Assistant:** Hermes Agent ( Nous Research )
- **Code Editor:** VS Code, Cursor
- **Version Control:** Git, GitHub
- **Terminal:** iTerm2, zsh, tmux

### Development Stack
- **Frontend:** React, Next.js, TailwindCSS, Three.js
- **Backend:** Node.js, Express, Python (FastAPI)
- **Database:** PostgreSQL, MongoDB, Supabase
- **DevOps:** Docker, Nginx, Linux Server

### AI & Automation
- **Local LLM:** Ollama (Qwen3.5 27B, Qwen3 8B)
- **Cloud LLM:** OpenRouter, Groq, Google AI Studio, DeepSeek
- **MCP Servers:** 20+ servers integrated

---

## Proyek Portfolio

### Public Projects
1. **niu-dash** - Interactive Dashboard
   - URL: https://niumination.github.io/niu-dash
   - Tech: HTML, CSS, JavaScript, Chart.js
   
2. **Hermes Powerfull Config** - Custom Hermes Configuration
   - Features: Free LLM, 20+ MCP, Government Admin Skills
   
3. **Portal Layanan Digital** - In Development
   - Target: Government service portal

---

## Preferensi Kerja

### Communication Style
- **Formal:** Untuk dokumen pemerintahan
- **Technical:** Untuk development tasks
- **Indonesian:** Default untuk semua konteks

### Work Approach
1. Start with understanding requirements fully
2. Provide structured solution with steps
3. Include examples and templates
4. Verify output before completion
5. Document the process

### Response Format
- **Surat/Laporan:** Format resmi dengan header yang benar
- **Kode:** Clean code dengan dokumentasi
- **Penjelasan:** Step-by-step dengan contoh

---

## Special Requirements

### pemerintahan
- Format surat resmi sesuai Standar
- Reference regulasi yang relevan
- Ikuti SOP yang berlaku

### Development
- Follow best practices
- Security-first approach
- Comprehensive testing

### Automation
- Minimize manual work
- Document automation workflows
- Monitor and optimize

---

## Goals & Objectives

### Short-term
- [ ] Selesaikan Portal Layanan Digital
- [ ] Implementasi 20 Indikator PEMDI
- [ ] Setup automated reporting system

### Medium-term
- [ ] Pengembangan Sistem Informasi terintegrasi
- [ ] Implementasi security measures
- [ ] Training dan development internal

### Long-term
- [ ] Contribute to open source projects
- [ ] Build comprehensive automation framework
- [ ] Achieve expertise in government digital transformation

---

## Catatan

**Kebutuhan Utama:**
1. Efisiensi administrasi perkantoran
2. Pengembangan sistem automatisasi
3. Keamanan data dan sistem
4. Kepatuhan terhadap regulasi

**Budget Constraint:**
- all configuration must be FREE (zero cost)
- Maximize free tiers dari berbagai providers
- Use local models jika memungkinkan

---

**Last updated: 19 Juni 2026**  
**Hermes Version: v0.16.0+**