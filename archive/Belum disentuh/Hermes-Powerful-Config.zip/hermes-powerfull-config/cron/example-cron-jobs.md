# CRON JOBS UNTUK HERMES AGENT

## Daftar Cron Jobs Otomatis

### 1. Laporan Harian Otomatis
```yaml
# .hermes/cron/daily-report.yaml
name: "Generate Laporan Harian"
description: "Membuat laporan harian kegiatan Diskominfo"
schedule: "0 7 * * *"  # Setiap hari 07:00
enabled: true

actions:
  - type: query_supabase
    query: >
      SELECT * FROM kegiatan 
      WHERE tanggal = CURRENT_DATE - 1
      ORDER BY created_at DESC;
  
  - type: generate_with_llm
    model: "openrouter/奥特曼/fast"  # DeepSeek
    prompt: >
      Buat laporan harian dalam format resmi pemerintah Indonesia.
      Tanggal: kemarin
      
      Data kegiatan:
      {{ activities }}
      
      Format laporan:
      1. Ringkasan Eksekutif
      2. Detail Kegiatan
      3. Capaian Kinerja
      4. Kendala
      5. Rencana Tindak Lanjut

  - type: save_to_file
    path: "reports/laporan-harian-{{ date }}.md"
  
  - type: send_notification
    channel: "telegram"
    message: "📊 Laporan harian telah dibuat: {{ filename }}"
```

### 2. Backup Database Otomatis
```yaml
# .hermes/cron/auto-backup.yaml
name: "Backup Database Supabase"
description: "Backup database PostgreSQL ke local storage dan cloud"
schedule: "0 2 * * *"  # Setiap hari 02:00 (dini hari)
enabled: true

actions:
  - type: postgres_dump
    connection: "${SUPABASE_DB_URL}"
    output: "backups/db-{{ date }}.sql"
    options:
      compress: true
      exclude_tables: ["logs", "sessions"]
  
  - type: encrypt_file
    algorithm: "aes-256-gcm"
    password_env: "BACKUP_ENCRYPT_KEY"
    input: "backups/db-{{ date }}.sql"
    output: "backups/db-{{ date }}.enc"
  
  - type: upload_to_cloud
    provider: "r2"  # Cloudflare R2 (S3-compatible, free tier)
    bucket: "hermes-backups"
    path: "db-backup-{{ date }}.enc"
  
  - type: cleanup_old_backups
    directory: "backups"
    retention_days: 30
  
  - type: log_action
    message: "Backup completed: {{ filename }}"
```

### 3. Monitoring Kesehatan Website
```yaml
# .hermes/cron/health-check.yaml
name: "Website Health Check"
description: "Memeriksa kesehatan semua website yang dikelola"
schedule: "*/15 * * * *"  # Setiap 15 menit
enabled: true

actions:
  - type: http_check
    url: "https://acehtengahkab.go.id"
    timeout: 10
    expected_status: 200
  
  - type: http_check
    url: "https://dashboard.acehtengahkab.go.id"
    timeout: 10
    expected_status: 200
  
  - type: http_check
    url: "https://opendata.acehtengahkab.go.id"
    timeout: 10
    expected_status: 200

  - type: conditional
    condition: "any_failed"
    then:
      - type: send_alert
        channel: "telegram"
        severity: "high"
        message: "⚠️ Health check failed!\n\nFailed URLs:\n{{ failed_urls }}"
      - type: create_incident
        title: "Website Down: {{ failed_url }}"
        priority: "high"
  
  - type: log_health_metrics
    data: "{{ results }}"
```

### 4. Notifikasi PEMDI Reminder
```yaml
# .hermes/cron/pemdi-reminder.yaml
name: "PEMDI Indicator Reminder"
description: "Reminder quarterly untuk assessment indikator PEMDI"
schedule: "0 8 1 */3 *"  # Tanggal 1 setiap 3 bulan, jam 08:00
enabled: true

actions:
  - type: query_database
    table: "pemdi_evaluasi"
    filters:
      periode: "{{ current_quarter }}"
  
  - type: generate_reminder
    template: >
      📋 *Reminder Penilaian PEMDI*
      
      Periode: {{ current_quarter }}
      Indikator selesai: {{ completed }} / {{ total }}
      
      Indikator yang belum dinilai:
      {{ pending_indicators }}
      
      Batas penilaian: {{ deadline }}
      
      Klik untuk mengisi: {{ assessment_link }}

  - type: send_notification
    channel: "email"
    to: ["kadin@example.com", "sekdin@example.com"]
    subject: "Reminder Penilaian PEMDI Triwulan"
  
  - type: send_notification
    channel: "telegram"
    group_id: "${TELEGRAM_GROUP_ID}"
    message: "{{ reminder_message }}"
```

### 5. Auto Sync Data dari Portal Nasional
```yaml
# .hermes/cron/sync-national-portal.yaml
name: "Sync Data dari Portal Nasional"
description: "Sinkronisasi data dari berbagai portal nasional"
schedule: "0 6 * * *"  # Setiap hari 06:00
enabled: true

actions:
  - type: fetch_api
    url: "https://api.kemenpan.go.id/spbe/indicators"
    headers:
      Authorization: "Bearer ${KEMENPAN_API_KEY}"
    save_to: "data/kemenpan-indicators.json"
  
  - type: fetch_api
    url: "https://data.go.id/api/v1/aceh-tengah"
    headers:
      Authorization: "Bearer ${DATA_GOV_ID_KEY}"
    save_to: "data/opendata.json"
  
  - type: fetch_api
    url: "https://api.bps.go.id/1305/statistics"
    save_to: "data/statistik-bps.json"
  
  - type: compare_data
    new_file: "data/latest.json"
    old_file: "data/previous.json"
  
  - type: conditional
    condition: "has_changes"
    then:
      - type: update_database
        table: "statistik"
        data: "{{ changes }}"
      - type: notify_changes
        message: "Data updated: {{ summary }}"
```

### 6. Weekly Summary Report
```yaml
# .hermes/cron/weekly-summary.yaml
name: "Weekly Summary Report"
description: "Generate ringkasan mingguan untuk manajemen"
schedule: "0 17 * * 5"  # Setiap Jumat 17:00
enabled: true

actions:
  - type: query_database
    query: >
      SELECT 
        DATE_TRUNC('week', created_at) as week,
        COUNT(*) as total_tickets,
        COUNT(*) FILTER (WHERE status = 'completed') as resolved,
        AVG(EXTRACT(EPOCH FROM (completed_at - created_at))/3600) as avg_resolution_hours
      FROM permohonan
      WHERE created_at >= CURRENT_DATE - INTERVAL '4 weeks'
      GROUP BY DATE_TRUNC('week', created_at)
      ORDER BY week DESC;

  - type: generate_chart
    type: "bar"
    data: "{{ weekly_stats }}"
    output: "reports/weekly-chart.png"
  
  - type: generate_report
    template: >
      📈 *Laporan Mingguan Diskominfo Aceh Tengah*
      
      Minggu: {{ week_start }} - {{ week_end }}
      
      **Statistik Layanan:**
      - Total permohonan: {{ total }}
      - Selesai: {{ resolved }} ({{ percentage }}%)
      - Rata-rata waktu solusi: {{ avg_hours }} jam
      
      **Top 5 Layanan:**
      {{ top_services }}
      
      **Progress PEMDI:**
      {{ pemdi_progress }}
      
      **Project Aktif:**
      {{ active_projects }}

  - type: send_notification
    channel: "email"
    to: ["atasan@example.com"]
    subject: "Laporan Mingguan Diskominfo"
    attachments:
      - "reports/weekly-chart.png"
      - "reports/weekly-summary-{{ date }}.pdf"
```

### 7. Security Scan Scheduler
```yaml
# .hermes/cron/security-scan.yaml
name: "Weekly Security Scan"
description: "Jalankan security scan untuk sistem"
schedule: "0 3 * * 0"  # Setiap Minggu 03:00
enabled: true

actions:
  - type: run_nmap_scan
    targets:
      - "192.168.1.0/24"
    options: "-sV -O --script vuln"
    output: "security/nmap-{{ date }}.xml"
  
  - type: run_zap_scan
    target: "https://acehtengahkab.go.id"
    spider: true
    active_scan: true
    report: "security/zap-report-{{ date }}.html"
  
  - type: parse_vulnerability_report
    input: "security/nmap-{{ date }}.xml"
  
  - type: conditional
    condition: "critical_vulns_found"
    then:
      - type: create_ticket
        title: "Critical Security Vulnerability Found"
        description: "{{ vulnerability_details }}"
        priority: "critical"
        assignee: "security-team"
      - type: send_alert
        channel: "telegram"
        severity: "critical"
        message: "🔴 *CRITICAL SECURITY ALERT*\n\n{{ vulnerability_summary }}"
  
  - type: generate_security_report
    output: "security/weekly-security-report-{{ date }}.pdf"
  
  - type: upload_to_secure_storage
    path: "security/weekly-security-report-{{ date }}.pdf"
```

### 8. Auto Clean Up Old Files
```yaml
# .hermes/cron/auto-cleanup.yaml
name: "Auto Cleanup Old Files"
description: "Bersihkan file temporary dan lama"
schedule: "0 1 * * *"  # Setiap hari 01:00
enabled: true

actions:
  - type: cleanup_temp
    directories:
      - "/tmp/hermes-*"
      - "/home/user/hermes/sessions/*"
    older_than_days: 7
  
  - type: cleanup_logs
    directory: "/home/user/hermes/logs"
    older_than_days: 30
    keep_patterns:
      - "*error*.log"
  
  - type: compress_old_reports
    directory: "/home/user/hermes/reports"
    older_than_days: 90
    output_format: "tar.gz"
  
  - type: cleanup_downloads
    directory: "/home/user/Downloads"
    older_than_days: 30
    exclude_patterns:
      - "*.dmg"
      - "important-*"
```

## Konfigurasi Activation

```bash
# Aktifkan cron jobs
hermes cron enable daily-report
hermes cron enable auto-backup
hermes cron enable health-check

# List semua cron jobs
hermes cron list

# Manual run (untuk testing)
hermes cron run daily-report --dry-run

# Logs
hermes cron logs --job daily-report --lines 50
```

## Environment Variables untuk Cron

```bash
# ~/.hermes/.env cron section
# Add these for cron jobs

# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-service-role-key
SUPABASE_DB_URL=postgresql://postgres:password@db.xxx.supabase.co:5432/postgres

# Telegram
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# Cloudflare R2 (S3-compatible backup)
R2_ACCOUNT_ID=your-account-id
R2_ACCESS_KEY_ID=your-key
R2_SECRET_ACCESS_KEY=your-secret
R2_BUCKET=hermes-backups

# Encryption
BACKUP_ENCRYPT_KEY=your-32-char-encryption-key

# API Keys
KEMENPAN_API_KEY=your-api-key
DATA_GOV_ID_KEY=your-api-key
```