# 📚 SKILLS INDEX - Hermes Powerfull Configuration

## Overview

Skill library ini menyediakan kemampuan untuk semua kebutuhan kerja sebagai Pranata Komputer di Diskominfo Kabupaten Aceh Tengah.

**Total Skills:** 13 (12 active + 1 coming soon)
**Total Lines:** ~10,000+

---

## 📁 pemerintahan/

Skills untuk administrasi pemerintahan Indonesia.

| Skill | File | Lines | Description |
|-------|------|-------|-------------|
| **surat-resmi** | `surat-resmi/SKILL.md` | 280 | Format surat Undangan, Nota Dinas, Surat Edaran, Memorandum, Surat Tugas |
| **laporan-dinas** | `laporan-dinas/SKILL.md` | 212 | LKIP, LAKIP, laporan bulanan/tahunan, evaluasi kinerja |
| **peraturan** | `peraturan/SKILL.md` | 178 | Perda, Perbup, Kepbup, Perdes |
| **pemdi-indikator** | `pemdi-indikator/SKILL.md` | 675 | 20 Indikator PEMDI (PermenPANRB No. 8 Tahun 2026) |

---

## 📁 teknologi/

Skills untuk development dan teknis.

| Skill | File | Lines | Description | Status |
|-------|------|-------|-------------|--------|
| **web-development** | `web-development/SKILL.md` | 2999 | Fullstack Next.js + Supabase + DevOps | ✅ |
| **ui-ux-design** | `ui-ux-design/SKILL.md` | 2173 | Design System, shadcn/ui, Atomic Design | ✅ |
| **keamanan-siber** | `keamanan-siber/SKILL.md` | 324 | Cyber defense, hardening, incident response | ✅ |
| **sistem-automation** | `sistem-automation/SKILL.md` | 441 | n8n workflows, cron jobs, chatbot | ✅ |
| **database-management** | `database-management/SKILL.md` | 460 | PostgreSQL, query optimization, backup | ✅ |
| **mcp-servers** | `mcp-servers/SKILL.md` | ~400 | MCP configuration, Indonesian gov APIs | ✅ |
| **hackintosh** | `hackintosh/SKILL.md` | 🔜 | Hackintosh setup, tweaking, optimization | 🔴 TODO |

---

## 📁 productivity/

Skills untuk produktivitas kerja.

| Skill | File | Lines | Description |
|-------|------|-------|-------------|
| **task-management** | `task-management/SKILL.md` | 439 | Project management, Pomodoro, Taskwarrior |

---

## 🎯 Quick Reference

### Admin Government Tasks
```
Need: Surat resmi → Use surat-resmi skill
Need: Laporan kerja → Use laporan-dinas skill
Need: Peraturan → Use peraturan skill
Need: PEMDI evaluation → Use pemdi-indikator skill
```

### Technical Tasks
```
Need: Web portal → Use web-development skill
Need: UI/Design → Use ui-ux-design skill
Need: Database → Use database-management skill
Need: Automation → Use sistem-automation skill
Need: Security → Use keamanan-siber skill
Need: MCP setup → Use mcp-servers skill
```

---

## 📖 How to Use

### Via Hermes Agent
```bash
# Activate skill
/hermes activate surat-resmi

# Or just ask
"Buat surat undangan untuk rapat SPBE besok jam 9 pagi"
```

### Via OpenCode Zen
```bash
# Ask directly
opencode "Create government letter template using surat-resmi skill"
```

---

## 🔄 Skill Update History

| Date | Skill | Changes |
|------|-------|---------|
| 20 Juni 2026 | mcp-servers | Added Indonesian Government APIs reference |
| 20 Juni 2026 | ui-ux-design | New - Design System complete |
| 20 Juni 2026 | web-development | Enhanced with DevOps section |
| 19 Juni 2026 | pemdi-indikator | Initial - 20 indicators complete |
| 19 Juni 2026 | All | Initial setup |

---

## 🚀 Contributing New Skills

### Skill Structure
```
skills/
├── category/
│   ├── SKILL.md           # Main skill file
│   ├── references/        # Additional references
│   └── examples/          # Code examples
```

### SKILL.md Template
```markdown
# SKILL: [Nama Skill]

## Metadata
- name: ckm:[skill-name]
- version: 1.0.0
- author: Niumination

## Description
[What this skill does]

## When to Use
[When to activate this skill]

## Quick Start
[Basic usage]

## Detailed Guide
[Complete documentation]

## Examples
[Practical examples]

## References
[Links and resources]
```

---

**Last Updated: 20 Juni 2026**  
**Total Skills: 13**  
**Maintained by: Niumination**