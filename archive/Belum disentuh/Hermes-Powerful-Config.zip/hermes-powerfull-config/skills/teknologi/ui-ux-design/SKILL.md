# SKILL: UI/UX Design Pro Max

## Metadata
```
name: ckm:ui-ux-design-pro-max
description: Create beautiful, accessible user interfaces combining shadcn/ui components, Tailwind CSS utility-first styling, and canvas-based visual design systems. Use when building user interfaces, implementing design systems, creating responsive layouts, adding accessible components (dialogs, dropdowns, forms, tables), customizing themes and colors, implementing dark mode, generating visual designs and posters, or establishing consistent styling patterns across applications.
argument-hint: [component or layout]
license: MIT
```

---

## DAFTAR ISI
1. [Quick Start - Setup Shadcn/ui + Tailwind](#1-quick-start)
2. [Component Library Guide](#2-component-library-guide)
3. [Design System - Atomic Design](#3-design-system---atomic-design)
4. [Typography System](#4-typography-system)
5. [Color System & Theming](#5-color-system--theming)
6. [Responsive Design Patterns](#6-responsive-design-patterns)
7. [Animation & Motion](#7-animation--motion)
8. [Accessibility (WCAG 2.1 AA)](#8-accessibility-wcag-21-aa)
9. [Government-Specific UI Patterns](#9-government-specific-ui-patterns)
10. [Block & Template Libraries](#10-block--template-libraries)
11. [Visual Design - Canvas & SVG](#11-visual-design---canvas--svg)
12. [Best Practices Checklist](#12-best-practices-checklist)

---

# 1. QUICK START

## Setup Shadcn/ui + Tailwind CSS

```bash
# Initialize shadcn/ui project
npx shadcn@latest init

# CLI prompts:
# - Framework: Next.js / Vite / Remix / Astro
# - TypeScript: Yes
# - CSS: Tailwind CSS
# - Base color: Slate / Neutral / Zinc / Stone / Gray
# - CSS variables: Yes
# - Custom prefix: No
# - Variables: Yes
# - Tailwind version: v4 (latest)
# - Import alias: @/*

# Add essential components
npx shadcn@latest add button card dialog input label select textarea
npx shadcn@latest add table dropdown-menu tabs badge avatar
npx shadcn@latest add form checkbox radio-group switch slider
npx shadcn@latest add sheet popover tooltip command alert
npx shadcn@latest add calendar date-picker chart toast pagination

# Run dev server
npm run dev
```

## Alternative: Tailwind-Only (tanpa shadcn)

```bash
# Vite project
npm install -D tailwindcss @tailwindcss/vite

# vite.config.ts
import tailwindcss from '@tailwindcss/vite'
export default { plugins: [tailwindcss()] }

# src/index.css
@import "tailwindcss";

# Untuk plain HTML/CSS projects
# Download Tailwind CDN atau install via npm
```

## Setup untuk Government Portal

```bash
# Full government-ready setup
npx shadcn@latest init --defaults

# Add all government UI components
npx shadcn@latest add button card input textarea select
npx shadcn@latest add dialog sheet popover
npx shadcn@latest add table data-table
npx shadcn@latest add form hook-form zod
npx shadcn@latest add tabs badge alert
npx shadcn@latest add navigation-menu sidebar
npx shadcn@latest add chart calendar
npx shadcn@latest add command palette

# Install additional dependencies
npm install date-fns lucide-react class-variance-authority clsx tailwind-merge
npm install @radix-ui/react-slot @radix-ui/react-dialog @radix-ui/react-dropdown-menu
npm install @radix-ui/react-tabs @radix-ui/react-checkbox @radix-ui/react-select
npm install recharts framer-motion
```

---

# 2. COMPONENT LIBRARY GUIDE

## Core Components dengan Variants

### Button Component
```tsx
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// Variants
<Button variant="default">Primary</Button>
<Button variant="destructive">Danger</Button>
<Button variant="outline">Outline</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="ghost">Ghost</Button>
<Button variant="link">Link</Button>

// Sizes
<Button size="default">Default</Button>
<Button size="sm">Small</Button>
<Button size="lg">Large</Button>
<Button size="icon">Icon</Button>

// With loading state
<Button disabled>
  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
  Loading...
</Button>

// As child (external link)
<Button asChild>
  <Link href="/layanan">Lihat Layanan</Link>
</Button>
```

### Card Component (Government Style)
```tsx
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

// Stat Card
<Card className="hover:shadow-lg transition-shadow">
  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
    <CardTitle className="text-sm font-medium">Total Permohonan</CardTitle>
    <FileText className="h-4 w-4 text-muted-foreground" />
  </CardHeader>
  <CardContent>
    <div className="text-2xl font-bold">1,234</div>
    <p className="text-xs text-muted-foreground">+12% dari bulan lalu</p>
  </CardContent>
</Card>

// Service Card
<Card className="group cursor-pointer hover:border-primary transition-all">
  <CardHeader>
    <div className="flex items-center gap-2">
      <div className="p-2 bg-primary/10 rounded-lg">
        <FileText className="h-6 w-6 text-primary" />
      </div>
      <CardTitle className="group-hover:text-primary transition-colors">
        Pencatatan Sipil
      </CardTitle>
    </div>
    <CardDescription>
      Akta Kelahiran, Kematian, Perpindahan
    </CardDescription>
  </CardHeader>
  <CardContent>
    <div className="flex items-center gap-4 text-sm text-muted-foreground">
      <span className="flex items-center gap-1">
        <Clock className="h-4 w-4" />
        14 Hari
      </span>
      <Badge variant="outline">Gratis</Badge>
    </div>
  </CardContent>
  <CardFooter>
    <Button className="w-full" variant="outline" asChild>
      <Link href="/layanan/pencatatan-sipil">Ajukan</Link>
    </Button>
  </CardFooter>
</Card>

// Dashboard Card dengan Chart
<Card>
  <CardHeader>
    <CardTitle>Statistik Layanan</CardTitle>
    <CardDescription>Periode: Juni 2025</CardDescription>
  </CardHeader>
  <CardContent>
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data}>
        <XAxis dataKey="name" />
        <YAxis />
        <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  </CardContent>
  <CardFooter className="border-t pt-4">
    <div className="flex items-center text-sm text-muted-foreground">
      <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
      <span>+23% dari periode sebelumnya</span>
    </div>
  </CardFooter>
</Card>
```

### Input & Form Components
```tsx
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"

// Form schema
const formSchema = z.object({
  nik: z.string().length(16, "NIK harus 16 digit"),
  nama: z.string().min(3, "Nama minimal 3 karakter"),
  email: z.string().email("Email tidak valid"),
  telepon: z.string().regex(/^(\+62|62|0)[2-9]\d{7,11}$/, "Nomor tidak valid"),
  layanan: z.string().min(1, "Pilih layanan"),
  deskripsi: z.string().min(20, "Minimal 20 karakter"),
})

// Form component
const PermohonanForm = () => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nik: "",
      nama: "",
      email: "",
    }
  })

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        
        {/* NIK Input */}
        <FormField
          control={form.control}
          name="nik"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nomor Induk Kependudukan (NIK)</FormLabel>
              <FormControl>
                <Input placeholder="16 digit NIK" maxLength={16} {...field} />
              </FormControl>
              <FormDescription>
                Masukkan 16 digit NIK sesuai KTP
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Nama Lengkap */}
        <FormField
          control={form.control}
          name="nama"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nama Lengkap</FormLabel>
              <FormControl>
                <Input placeholder="Nama sesuai KTP" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Email */}
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" placeholder="email@contoh.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Select dengan Search */}
        <FormField
          control={form.control}
          name="layanan"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Jenis Layanan</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih layanan" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="akta-kelahiran">Akta Kelahiran</SelectItem>
                  <SelectItem value="akta-kematian">Akta Kematian</SelectItem>
                  <SelectItem value="kartu-keluarga">Kartu Keluarga</SelectItem>
                  <SelectItem value="ktp">KTP Elektronik</SelectItem>
                  <SelectItem value="surat-pindah">Surat Pindah</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Textarea */}
        <FormField
          control={form.control}
          name="deskripsi"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Deskripsi Permohonan</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Jelaskan keperluan permohonan Anda secara detail..." 
                  className="min-h-[120px]"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full">Kirim Permohonan</Button>
      </form>
    </Form>
  )
}
```

### Data Table dengan Fitur Lengkap
```tsx
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getPaginationRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  ColumnFiltersState,
  SortingState,
  VisibilityState,
} from "@tanstack/react-table"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown, MoreHorizontal, ChevronLeft, ChevronRight, ArrowUpDown, Eye, Edit, Trash2 } from "lucide-react"

// Columns definition
const columns: ColumnDef<Permohonan>[] = [
  {
    accessorKey: "nomor_registrasi",
    header: ({ column }) => (
      <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
        No. Registrasi
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
  },
  {
    accessorKey: "nama_lengkap",
    header: "Nama Pemohon",
  },
  {
    accessorKey: "layanan",
    header: "Layanan",
    cell: ({ row }) => (
      <Badge variant="secondary">{row.original.layanan}</Badge>
    ),
  },
  {
    accessorKey: "tanggal",
    header: "Tanggal",
    cell: ({ row }) => format(new Date(row.original.tanggal), "dd MMM yyyy"),
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status
      const variants: Record<string, string> = {
        draft: "outline",
        submitted: "secondary",
        verification: "secondary",
        review: "secondary",
        approved: "default",
        rejected: "destructive",
        completed: "default",
      }
      return <Badge variant={variants[status] || "outline"}>{status}</Badge>
    },
  },
  {
    id: "actions",
    cell: ({ row }) => (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-8 w-8 p-0">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>
            <Eye className="mr-2 h-4 w-4" />
            Lihat Detail
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-red-600">
            <Trash2 className="mr-2 h-4 w-4" />
            Hapus
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    ),
  },
]

// DataTable component
const DataTable = ({ data }: { data: Permohonan[] }) => {
  const [sorting, setSorting] = useState<SortingState>([])
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({})

  const table = useReactTable({
    data,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    state: { sorting, columnFilters, columnVisibility },
  })

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex items-center justify-between">
        <Input
          placeholder="Cari permohonan..."
          value={(table.getColumn("nama_lengkap")?.getFilterValue() as string) ?? ""}
          onChange={(event) =>
            table.getColumn("nama_lengkap")?.setFilterValue(event.target.value)
          }
          className="max-w-sm"
        />
        
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="ml-auto">
                Kolom <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {table
                .getAllColumns()
                .filter((column) => column.getCanHide())
                .map((column) => (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) => column.toggleVisibility(!!value)}
                  >
                    {column.id}
                  </DropdownMenuCheckboxItem>
                ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(header.column.columnDef.header, header.getContext())}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  Tidak ada data
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Menampilkan {table.getRowModel().rows.length} dari {data.length} data
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm">
            Halaman {table.getState().pagination.pageIndex + 1} dari {table.getPageCount()}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
```

### Navigation Components
```tsx
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, User, LogOut, Settings, Bell } from "lucide-react"

// Desktop Navigation
const navigation = [
  { name: "Beranda", href: "/" },
  { name: "Layanan", href: "/layanan" },
  { name: "Data", href: "/data" },
  { name: "Desa", href: "/desa" },
  { name: "Tentang", href: "/tentang" },
]

export function Header() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 mr-8">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">G</span>
          </div>
          <span className="font-bold text-lg hidden md:inline">
            Diskominfo Aceh Tengah
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6 flex-1">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                pathname === item.href
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        {/* Right Section */}
        <div className="flex items-center gap-4 ml-auto">
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full" />
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <User className="h-4 w-4" />
                <span className="hidden md:inline">Masuk</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">John Doe</p>
                <p className="text-xs text-muted-foreground">john@email.com</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/dashboard">
                  <User className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  Pengaturan
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">
                <LogOut className="mr-2 h-4 w-4" />
                Keluar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <nav className="flex flex-col space-y-2">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "px-3 py-2 rounded-md text-sm font-medium transition-colors",
                      pathname === item.href
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-accent"
                    )}
                  >
                    {item.name}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

// Sidebar Component (Dashboard)
export function Sidebar() {
  const pathname = usePathname()
  
  const sidebarNav = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Permohonan",
      href: "/dashboard/permohonan",
      icon: FileText,
      badge: "12",
    },
    {
      title: "Layanan",
      href: "/dashboard/layanan",
      icon: Grid3X3,
    },
    {
      title: "Laporan",
      href: "/dashboard/laporan",
      icon: BarChart3,
    },
    {
      title: "PEMDI",
      href: "/dashboard/pemdi",
      icon: Target,
      badge: "3",
    },
    {
      title: "Pengguna",
      href: "/dashboard/users",
      icon: Users,
    },
    {
      title: "Pengaturan",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  return (
    <nav className="flex flex-col space-y-1 px-3 py-4">
      {sidebarNav.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
            pathname === item.href
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          )}
        >
          <item.icon className="h-4 w-4" />
          {item.title}
          {item.badge && (
            <Badge variant="secondary" className="ml-auto">{item.badge}</Badge>
          )}
        </Link>
      ))}
    </nav>
  )
}
```

---

# 3. DESIGN SYSTEM - ATOMIC DESIGN

## Hierarki Komponen

```
┌─────────────────────────────────────────────────────────┐
│                    ATOMIC DESIGN                         │
├─────────────────────────────────────────────────────────┤
│  ATOMS (Primitif)                                       │
│  ├── Button, Input, Label, Icon, Badge                  │
│  ├── Typography: H1-H6, P, Small, Code                  │
│  └── Spacing: Gap, Padding, Margin utilities            │
├─────────────────────────────────────────────────────────┤
│  MOLECULES (Composite Simple)                           │
│  ├── FormField: Label + Input + Error                   │
│  ├── SearchBar: Input + Button + Icon                   │
│  ├── Card: Header + Content + Footer                    │
│  └── AvatarGroup: Multiple Avatar + Count               │
├─────────────────────────────────────────────────────────┤
│  ORGANISMS (Composite Complex)                          │
│  ├── NavigationBar: Logo + Nav + Actions                │
│  ├── DataTable: Header + Body + Pagination              │
│  ├── Modal: Dialog + Form + Actions                     │
│  └── DashboardStats: Multiple StatCards                 │
├─────────────────────────────────────────────────────────┤
│  TEMPLATES (Layout)                                     │
│  ├── PublicLayout: Header + Content + Footer            │
│  ├── DashboardLayout: Sidebar + Header + Content        │
│  └── AuthLayout: CenterCard + Background                │
├─────────────────────────────────────────────────────────┤
│  PAGES (Instance)                                       │
│  ├── Homepage: PublicLayout + HeroSection + ...         │
│  ├── DashboardPage: DashboardLayout + Stats + Tables    │
│  └── FormPage: PublicLayout + FormComponent + ...       │
└─────────────────────────────────────────────────────────┘
```

## Component Architecture Template

```tsx
// src/components/ui/text.tsx - Typography Component

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"
import { Slot } from "@radix-ui/react-slot"

const textVariants = cva("text-foreground", {
  variants: {
    variant: {
      h1: "scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl",
      h2: "scroll-m-20 text-3xl font-semibold tracking-tight first:mt-0",
      h3: "scroll-m-20 text-2xl font-semibold tracking-tight",
      h4: "scroll-m-20 text-xl font-semibold tracking-tight",
      p: "leading-7 [&:not(:first-child)]:mt-6",
      lead: "text-xl text-muted-foreground",
      large: "text-lg font-semibold",
      small: "text-sm font-medium leading-none",
      muted: "text-sm text-muted-foreground",
      code: "font-mono text-sm bg-muted px-1 py-0.5 rounded",
    },
    defaultVariants: {
      variant: "p",
    },
  },
})

const variantElementMap: Record<NonNullable<VariantProps<typeof textVariants>["variant"]>, string> = {
  h1: "h1",
  h2: "h2",
  h3: "h3",
  h4: "h4",
  p: "p",
  lead: "p",
  large: "div",
  small: "small",
  muted: "p",
  code: "code",
}

interface TextProps extends React.HTMLAttributes<HTMLElement>, VariantProps<typeof textVariants> {
  asChild?: boolean
  as?: keyof typeof variantElementMap
}

const Text = React.forwardRef<HTMLElement, TextProps>(
  ({ className, variant, as, asChild, ...props }, ref) => {
    const Comp = asChild ? Slot : as ?? (variant ? variantElementMap[variant] : "p")
    return <Comp className={cn(textVariants({ variant, className }))} ref={ref} {...props} />
  }
)
Text.displayName = "Text"

export { Text, textVariants }
```

## Compound Component Pattern

```tsx
// src/components/ui/card-group.tsx - Compound Component

import * as React from "react"
import { cn } from "@/lib/utils"

interface CardGroupContextValue {
  columns?: 1 | 2 | 3 | 4
  gap?: "sm" | "md" | "lg"
}

const CardGroupContext = React.createContext<CardGroupContextValue>({})

// Card Group Container
const CardGroup = ({ className, columns = 3, gap = "md", ...props }: React.HTMLAttributes<HTMLDivElement> & CardGroupContextValue) => {
  const gapClass = { sm: "gap-2", md: "gap-4", lg: "gap-6" }[gap]
  const gridClass = { 1: "grid-cols-1", 2: "grid-cols-1 md:grid-cols-2", 3: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3", 4: "grid-cols-1 md:grid-cols-2 lg:grid-cols-4" }[columns]
  
  return (
    <CardGroupContext.Provider value={{ columns, gap }}>
      <div className={cn("grid", gridClass, gapClass, className)} {...props} />
    </CardGroupContext.Provider>
  )
}

// Card Item
const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("rounded-lg border bg-card text-card-foreground shadow-sm", className)} {...props} />
  )
)
Card.displayName = "Card"

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  )
)
CardHeader.displayName = "CardHeader"

const CardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3 ref={ref} className={cn("text-2xl font-semibold leading-none tracking-tight", className)} {...props} />
  )
)
CardTitle.displayName = "CardTitle"

const CardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p ref={ref} className={cn("text-sm text-muted-foreground", className)} {...props} />
  )
)
CardDescription.displayName = "CardDescription"

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
  )
)
CardContent.displayName = "CardContent"

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex items-center p-6 pt-0", className)} {...props} />
  )
)
CardFooter.displayName = "CardFooter"

// Usage
const StatsGrid = ({ stats }: { stats: StatItem[] }) => (
  <CardGroup columns={4} gap="md">
    {stats.map((stat) => (
      <Card key={stat.title}>
        <CardHeader>
          <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stat.value}</div>
          <p className="text-xs text-muted-foreground">{stat.change}</p>
        </CardContent>
      </Card>
    ))}
  </CardGroup>
)

export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter, CardGroup }
```

---

# 4. TYPOGRAPHY SYSTEM

## Font System

```css
/* tailwind.config.ts - Typography Configuration */

module.exports = {
  theme: {
    fontFamily: {
      sans: ['Inter', 'system-ui', 'sans-serif'],
      serif: ['Playfair Display', 'Georgia', 'serif'],
      mono: ['JetBrains Mono', 'Menlo', 'monospace'],
    },
    fontSize: {
      'xs': ['0.75rem', { lineHeight: '1rem' }],
      'sm': ['0.875rem', { lineHeight: '1.25rem' }],
      'base': ['1rem', { lineHeight: '1.5rem' }],
      'lg': ['1.125rem', { lineHeight: '1.75rem' }],
      'xl': ['1.25rem', { lineHeight: '1.75rem' }],
      '2xl': ['1.5rem', { lineHeight: '2rem' }],
      '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
      '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
      '5xl': ['3rem', { lineHeight: '1' }],
      '6xl': ['3.75rem', { lineHeight: '1' }],
    },
    letterSpacing: {
      tighter: '-0.05em',
      tight: '-0.025em',
      normal: '0em',
      wide: '0.025em',
      wider: '0.05em',
    },
  },
}
```

## Typography Scale (Government)

```tsx
// components/typography.tsx

export const Typography = () => (
  <div className="space-y-8 p-8">
    {/* Headings */}
    <section>
      <h1 className="text-5xl font-extrabold tracking-tight mb-4">Heading 1 - 5xl</h1>
      <h2 className="text-4xl font-bold tracking-tight mb-4">Heading 2 - 4xl</h2>
      <h3 className="text-3xl font-semibold tracking-tight mb-4">Heading 3 - 3xl</h3>
      <h4 className="text-2xl font-semibold tracking-tight mb-4">Heading 4 - 2xl</h4>
      <h5 className="text-xl font-semibold mb-4">Heading 5 - xl</h5>
      <h6 className="text-lg font-medium">Heading 6 - lg</h6>
    </section>

    {/* Paragraph */}
    <section className="space-y-4">
      <p className="text-base leading-7">
        Paragraf normal - Base size dengan line-height 1.75 untuk readability optimal.
        Cocok untuk konten website pemerintahan.
      </p>
      <p className="text-lg leading-8">
        Paragraf besar - Menggunakan size lg untuk introduction text atau highlight.
      </p>
      <p className="text-sm leading-5 text-muted-foreground">
        Caption/Helper text - Ukuran kecil untuk informasi tambahan.
      </p>
    </section>

    {/* Lists */}
    <section>
      <h3 className="text-xl font-semibold mb-4">Unordered List</h3>
      <ul className="space-y-2 list-disc list-inside">
        <li>Persyaratan pertama</li>
        <li>Persyaratan kedua dengan detail tambahan</li>
        <li>Persyaratan ketiga</li>
      </ul>
    </section>

    <section>
      <h3 className="text-xl font-semibold mb-4">Ordered List</h3>
      <ol className="space-y-2 list-decimal list-inside">
        <li>Langkah pertama</li>
        <li>Langkah kedua</li>
        <li>Langkah ketiga</li>
      </ol>
    </section>

    {/* Code */}
    <section>
      <h3 className="text-xl font-semibold mb-4">Code Block</h3>
      <code className="block bg-muted p-4 rounded-lg font-mono text-sm overflow-x-auto">
        {`const example = "code";`}
      </code>
    </section>

    {/* Links */}
    <section>
      <a href="#" className="text-primary hover:underline">Link Primary</a>
      <span className="mx-2">|</span>
      <a href="#" className="text-muted-foreground hover:text-foreground">Link Muted</a>
    </section>
  </div>
)
```

---

# 5. COLOR SYSTEM & THEMING

## CSS Variables untuk Dark Mode

```css
/* src/app/globals.css - Color System */

@layer base {
  :root {
    /* Primary - Brand Color */
    --primary: 221.2 83.2% 53.3%;
    --primary-foreground: 210 40% 98%;
    
    /* Secondary */
    --secondary: 210 40% 96.1%;
    --secondary-foreground: 222.2 47.4% 11.2%;
    
    /* Muted */
    --muted: 210 40% 96.1%;
    --muted-foreground: 215.4 16.3% 46.9%;
    
    /* Accent */
    --accent: 210 40% 96.1%;
    --accent-foreground: 222.2 47.4% 11.2%;
    
    /* Destructive */
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    
    /* Background & Foreground */
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    
    /* Card */
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    
    /* Popover */
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    
    /* Border & Input */
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 221.2 83.2% 53.3%;
    
    /* Radius */
    --radius: 0.5rem;
    
    /* Sidebar (Dashboard) */
    --sidebar-background: 0 0% 98%;
    --sidebar-foreground: 240 5.3% 26.1%;
    --sidebar-primary: 221.2 83.2% 53.3%;
    --sidebar-primary-foreground: 210 40% 98%;
    --sidebar-accent: 240 4.8% 95.9%;
    --sidebar-accent-foreground: 240 5.9% 10%;
    --sidebar-border: 220 13% 91%;
    --sidebar-ring: 217.2 91.2% 59.8%;
  }

  .dark {
    /* Dark Mode Colors */
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 48%;
    
    /* Sidebar Dark */
    --sidebar-background: 222.2 84% 4.9%;
    --sidebar-foreground: 210 40% 98%;
    --sidebar-primary: 224.3 76.3% 48%;
    --sidebar-primary-foreground: 222.2 47.4% 11.2%;
    --sidebar-accent: 217.2 32.6% 17.5%;
    --sidebar-accent-foreground: 210 40% 98%;
    --sidebar-border: 217.2 32.6% 17.5%;
    --sidebar-ring: 224.3 76.3% 48%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
    font-feature-settings: "rlig" 1, "calt" 1;
  }
}
```

## Color Utility Classes

```tsx
// Usage Examples

// Text Colors
<span className="text-primary">Primary Text</span>
<span className="text-primary/50">Primary with 50% opacity</span>
<span className="text-muted-foreground">Muted text</span>
<span className="text-destructive">Error text</span>
<span className="text-success">Success text (custom)</span>

// Background Colors
<div className="bg-primary">Primary Background</div>
<div className="bg-primary/10">Primary 10% opacity</div>
<div className="bg-muted">Muted Background</div>
<div className="bg-destructive/20">Destructive 20% opacity</div>

// Border Colors
<div className="border-border">Default Border</div>
<div className="border-primary">Primary Border</div>
<div className="border-destructive">Destructive Border</div>

// Gradients
<div className="bg-gradient-to-r from-primary to-secondary">
  Primary to Secondary Gradient
</div>

// Ring (Focus states)
<input className="ring-2 ring-ring ring-offset-2" />
```

---

# 6. RESPONSIVE DESIGN PATTERNS

## Breakpoint Utilities

```tsx
// Responsive Design Patterns

// Mobile First Approach
// Default (mobile) → sm (640px) → md (768px) → lg (1024px) → xl (1280px) → 2xl (1536px)

// Grid Layout
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
  {/* 1 col mobile, 2 cols tablet, 3 cols desktop, 4 cols large */}
</div>

// Stacked on mobile, side-by-side on desktop
<div className="flex flex-col md:flex-row gap-4">
  <div className="w-full md:w-1/3">Sidebar</div>
  <div className="w-full md:w-2/3">Content</div>
</div>

// Typography Responsive
<h1 className="text-3xl md:text-4xl lg:text-5xl font-bold">
  Responsive Heading
</h1>

// Spacing Responsive
<div className="p-4 md:p-6 lg:p-8">
  {/* 1rem mobile, 1.5rem tablet, 2rem desktop */}
</div>

// Visibility
<div className="hidden md:block">Show on tablet and up</div>
<div className="block md:hidden">Hide on tablet and up</div>

// Container
<div className="container mx-auto px-4 md:px-6 lg:px-8">
  {/* Max-width container with responsive padding */}
</div>
```

## Government Dashboard Responsive

```tsx
// Responsive Dashboard Layout

const DashboardLayout = ({ children }: { children: React.ReactNode }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar - Hidden on mobile */}
      <aside className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-64 lg:flex-col">
        <Sidebar />
      </aside>

      {/* Main Content */}
      <div className="lg:pl-64">
        {/* Mobile Header */}
        <header className="sticky top-0 z-40 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6 lg:hidden">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="font-semibold">Dashboard</div>
        </header>

        {/* Page Content */}
        <main className="p-4 md:p-6 lg:p-8">
          {/* Stats Grid - Responsive */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard title="Total" value="1,234" icon={FileText} />
            <StatCard title="Pending" value="56" icon={Clock} />
            <StatCard title="Selesai" value="1,178" icon={CheckCircle} />
            <StatCard title="Ditolak" value="12" icon={XCircle} />
          </div>

          {/* Two Column Layout - Stacked on mobile */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content - 2/3 on desktop */}
            <div className="lg:col-span-2 space-y-6">
              <DataTable data={permohonan} />
            </div>

            {/* Sidebar - 1/3 on desktop */}
            <div className="space-y-6">
              <QuickActions />
              <RecentActivity />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
```

## Card Grid Responsive

```tsx
// Service Cards Grid
const ServiceGrid = ({ services }: { services: Service[] }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
    {services.map((service) => (
      <Card key={service.id} className="group hover:shadow-lg transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${service.color}`}>
              <service.icon className="h-5 w-5" />
            </div>
            <CardTitle className="text-lg group-hover:text-primary transition-colors">
              {service.name}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-4 w-4" />
              {service.duration} hari
            </span>
            <Badge variant={service.free ? "default" : "secondary"}>
              {service.free ? "Gratis" : `Rp ${service.price.toLocaleString()}`}
            </Badge>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" variant="outline" asChild>
            <Link href={`/layanan/${service.slug}`}>
              Ajukan <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardFooter>
      </Card>
    ))}
  </div>
)
```

---

# 7. ANIMATION & MOTION

## Framer Motion Integration

```bash
npm install framer-motion
```

### Page Transitions

```tsx
// components/page-transition.tsx
import { motion, AnimatePresence } from "framer-motion"

const pageVariants = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: 20 },
}

const PageTransition = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    variants={pageVariants}
    initial="initial"
    animate="animate"
    exit="exit"
    transition={{ duration: 0.3, ease: "easeInOut" }}
  >
    {children}
  </motion.div>
)

// Layout transition
const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
}

// Usage in page
const DashboardPage = () => (
  <motion.div
    variants={containerVariants}
    initial="hidden"
    animate="show"
    className="space-y-6"
  >
    <motion.div variants={itemVariants}>
      <h1 className="text-3xl font-bold">Dashboard</h1>
    </motion.div>
    <motion.div variants={itemVariants} className="grid grid-cols-4 gap-4">
      <StatCard />
      <StatCard />
      <StatCard />
      <StatCard />
    </motion.div>
  </motion.div>
)
```

### Card Hover Animation

```tsx
// components/animated-card.tsx
import { motion } from "framer-motion"

const AnimatedCard = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <motion.div
    whileHover={{ y: -4, boxShadow: "0 10px 40px -10px rgba(0,0,0,0.1)" }}
    transition={{ duration: 0.2 }}
    className={cn("rounded-xl border bg-card p-6", className)}
  >
    {children}
  </motion.div>
)

// Service Card with hover effect
const ServiceCard = ({ service }: { service: Service }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    whileHover={{ scale: 1.02 }}
    className="rounded-xl border bg-card overflow-hidden"
  >
    <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/5" />
    <div className="p-6">
      <h3 className="font-semibold mb-2">{service.name}</h3>
      <p className="text-sm text-muted-foreground">{service.description}</p>
    </div>
  </motion.div>
)
```

### Staggered List Animation

```tsx
const AnimatedList = ({ items }: { items: Item[] }) => {
  const listVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    show: { opacity: 1, x: 0 }
  }

  return (
    <motion.ul
      variants={listVariants}
      initial="hidden"
      animate="show"
      className="space-y-2"
    >
      {items.map((item) => (
        <motion.li key={item.id} variants={itemVariants}>
          <ListItem item={item} />
        </motion.li>
      ))}
    </motion.ul>
  )
}
```

## CSS Animation (Tanpa Framer Motion)

```css
/* Animasi dengan CSS saja */

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes slideIn {
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* Utility Classes */
.animate-fade-in {
  animation: fadeIn 0.3s ease-out forwards;
}

.animate-slide-in {
  animation: slideIn 0.3s ease-out forwards;
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

.animate-spin {
  animation: spin 1s linear infinite;
}

/* Delay utilities */
.delay-100 { animation-delay: 100ms; }
.delay-200 { animation-delay: 200ms; }
.delay-300 { animation-delay: 300ms; }
```

---

# 8. ACCESSIBILITY (WCAG 2.1 AA)

## Checklist Aksesibilitas

### Color Contrast (Minimum)
```css
/* Normal text: 4.5:1 contrast ratio */
/* Large text (18pt+): 3:1 contrast ratio */
/* UI components: 3:1 contrast ratio */

/* Contoh class Tailwind untuk contrast */
.text-foreground        /* ~19:1 on white */
.text-muted-foreground  /* ~4.5:1 on white - OK */
.text-primary           /* ~5:1 on white - OK */
```

### Keyboard Navigation

```tsx
// Skip to main content
const SkipLink = () => (
  <a
    href="#main-content"
    className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-primary focus:text-primary-foreground"
  >
    Skip to main content
  </a>
)

// Focus visible ring
<button className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
  Button with focus ring
</button>

// Keyboard trap (Modal)
const Modal = () => {
  const modalRef = useRef<HTMLDivElement>(null)
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeModal()
      if (e.key === "Tab") {
        // Trap focus within modal
        const focusable = modalRef.current?.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        )
        if (focusable?.length) {
          const first = focusable[0] as HTMLElement
          const last = focusable[focusable.length - 1] as HTMLElement
          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault()
            last.focus()
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault()
            first.focus()
          }
        }
      }
    }
    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [])

  return <div ref={modalRef} role="dialog" aria-modal="true">...</div>
}
```

### ARIA Attributes

```tsx
// Button with loading state
<Button 
  aria-busy="true" 
  aria-disabled={isLoading}
>
  {isLoading ? (
    <>
      <span className="sr-only">Loading</span>
      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
    </>
  ) : "Submit"}
</Button>

// Alert with role
<div role="alert" aria-live="polite" className="p-4 rounded-lg bg-destructive/10">
  <p className="text-sm text-destructive font-medium">{message}</p>
</div>

// Form with aria-describedby
<FormField
  name="email"
  render={({ field }) => (
    <FormItem>
      <FormLabel htmlFor="email">Email</FormLabel>
      <FormControl>
        <Input 
          id="email" 
          aria-describedby="email-error" 
          {...field} 
        />
      </FormControl>
      <FormMessage id="email-error" />
    </FormItem>
  )}
/>

// Table with proper headers
<table role="table" aria-label="Daftar Permohonan">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>John Doe</td>
      <td><Badge>Pending</Badge></td>
    </tr>
  </tbody>
</table>
```

---

# 9. GOVERNMENT-SPECIFIC UI PATTERNS

## Official Letter Template (Kop Surat)

```tsx
// components/government-letter.tsx

interface GovernmentLetterProps {
  logo?: string
  institutionName: string
  institutionAddress: string
  phone: string
  email: string
  website: string
  letterNumber: string
  letterDate: string
  subject: string
  recipient: {
    name: string
    position: string
    address: string
  }
  body: React.ReactNode
  attachments?: string[]
  cc?: string[]
}

export const GovernmentLetter = ({
  logo,
  institutionName,
  institutionAddress,
  phone,
  email,
  website,
  letterNumber,
  letterDate,
  subject,
  recipient,
  body,
  attachments,
  cc,
}: GovernmentLetterProps) => (
  <div className="max-w-3xl mx-auto bg-white p-8 print:p-0">
    {/* Kop Surat */}
    <div className="text-center border-b-2 border-black pb-4 mb-6">
      <div className="flex items-center justify-center gap-4 mb-2">
        {logo && <img src={logo} alt="Logo" className="h-16 w-16" />}
        <div>
          <h1 className="text-xl font-bold uppercase">{institutionName}</h1>
          <p className="text-sm">{institutionAddress}</p>
        </div>
      </div>
      <div className="text-xs space-y-1">
        <p>Telp: {phone} | Email: {email}</p>
        <p>Website: {website}</p>
      </div>
    </div>

    {/* Nomor & Tanggal */}
    <div className="mb-6">
      <p>Nomor &nbsp;&nbsp;&nbsp;: {letterNumber}</p>
      <p>Lampiran : {attachments?.length || '-'} Berkas</p>
      <p>Perihal &nbsp;: {subject}</p>
    </div>

    {/* Kepada */}
    <div className="mb-6">
      <p>Kepada Yth.</p>
      <p className="font-bold">{recipient.name}</p>
      <p>{recipient.position}</p>
      <p className="whitespace-pre-line">{recipient.address}</p>
    </div>

    {/* Body */}
    <div className="space-y-4 text-justify">
      {body}
    </div>

    {/* Tanda Tangan */}
    <div className="mt-12 flex justify-end">
      <div className="text-center">
        <p>{letterDate.split(',')[0]}</p>
        <p className="mt-16">{recipient.position}</p>
        <p className="mt-16 font-bold underline">{recipient.name}</p>
      </div>
    </div>

    {/* Tembusan */}
    {cc && cc.length > 0 && (
      <div className="mt-8">
        <p className="text-sm">Tembusan:</p>
        <ol className="text-sm list-decimal list-inside">
          {cc.map((c, i) => <li key={i}>{c}</li>)}
        </ol>
      </div>
    )}
  </div>
)
```

## Status Badge System (Government)

```tsx
// components/status-badge.tsx

const STATUS_CONFIG = {
  // Permohonan Status
  draft: { label: "Draft", variant: "outline", icon: FileText, color: "muted" },
  submitted: { label: "Menunggu Verifikasi", variant: "secondary", icon: Clock, color: "yellow" },
  verification: { label: "Sedang Diverifikasi", variant: "secondary", icon: Search, color: "blue" },
  review: { label: "Dalam Review", variant: "secondary", icon: Eye, color: "purple" },
  approved: { label: "Disetujui", variant: "default", icon: Check, color: "green" },
  rejected: { label: "Ditolak", variant: "destructive", icon: X, color: "red" },
  revision: { label: "Perlu Revisi", variant: "warning", icon: AlertTriangle, color: "orange" },
  completed: { label: "Selesai", variant: "default", icon: CheckCircle, color: "green" },
  cancelled: { label: "Dibatalkan", variant: "outline", icon: Ban, color: "muted" },
  
  //优先级
  critical: { label: "Kritis", variant: "destructive", color: "red" },
  high: { label: "Tinggi", variant: "default", color: "orange" },
  medium: { label: "Sedang", variant: "secondary", color: "yellow" },
  low: { label: "Rendah", variant: "outline", color: "green" },
}

const StatusBadge = ({ status, size = "default" }: { status: string, size?: "sm" | "default" }) => {
  const config = STATUS_CONFIG[status as keyof typeof STATUS_CONFIG]
  
  if (!config) return null
  
  return (
    <Badge variant={config.variant as any} className={cn("gap-1", size === "sm" && "text-xs px-1.5")}>
      {config.icon && <config.icon className={cn("h-3 w-3", size === "sm" && "h-2 w-2")} />}
      {config.label}
    </Badge>
  )
}

// Usage
<StatusBadge status="submitted" /> // Yellow badge with clock icon
<StatusBadge status="completed" /> // Green badge with check icon
<StatusBadge status="rejected" size="sm" /> // Small destructive badge
```

## PEMDI Evaluation Interface

```tsx
// components/pemdi-evaluation.tsx

const PEMDIAspectCard = ({ aspect, indicators }: PEMDIAspectProps) => (
  <Card>
    <CardHeader className="bg-muted/50">
      <CardTitle className="flex items-center justify-between">
        <span>Aspek {aspect.number}: {aspect.name}</span>
        <Badge variant="outline">{aspect.bobot}%</Badge>
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-4 pt-4">
      {indicators.map((indicator) => (
        <div key={indicator.id} className="border rounded-lg p-4">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="font-medium">Indikator {indicator.number}</p>
              <p className="text-sm text-muted-foreground">{indicator.name}</p>
            </div>
            <Badge>{indicator.bobot}%</Badge>
          </div>
          
          {/* Self Assessment Score */}
          <div className="space-y-2">
            <Label>Nilai Self Assessment (1-5)</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((score) => (
                <Button
                  key={score}
                  variant={indicator.score === score ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateScore(indicator.id, score)}
                >
                  {score}
                </Button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              1=Sangat Kurang, 2=Kurang, 3=Cukup, 4=Baik, 5=Sangat Baik
            </p>
          </div>
          
          {/* Evidence Upload */}
          <div className="mt-3 pt-3 border-t">
            <Label>Dokumen Bukti</Label>
            <div className="mt-2 space-y-2">
              <Input type="file" accept=".pdf,.doc,.docx,.jpg,.png" multiple />
              <div className="flex flex-wrap gap-2">
                {indicator.evidence.map((file) => (
                  <Badge key={file.id} variant="secondary" className="gap-1">
                    <Paperclip className="h-3 w-3" />
                    {file.name}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          
          {/* Notes */}
          <div className="mt-3">
            <Textarea placeholder="Catatan/ komentar evaluator..." />
          </div>
        </div>
      ))}
    </CardContent>
  </Card>
)
```

---

# 10. BLOCK & TEMPLATE LIBRARIES

## Free Shadcn/ui Blocks

### Block Library Resources
```markdown
# UI Layouts & Blocks (Free)
- https://ui.shadcn.com/blocks - Official shadcn blocks
- https://shipfast.build - Next.js + shadcn starter
- https://taxonomy.shadcn.com - Full featured Next.js app

# Component Libraries
- Aceternity UI (https://aceternity.com) - Beautiful components
- Magic UI (https://magicui.design) - Trendy animations
- Flowbite (https://flowbite.com) - Tailwind components
- Preline (https://preline.co) - React + Tailwind

# Shadcn Community
- https://github.com/2-fly-4-ai/awesome-shadcnui - Awesome list
- https://shadcnstore.com - Component store
```

### Block Component Template

```tsx
// components/blocks/hero-section.tsx

interface HeroSectionProps {
  badge?: string
  title: string
  description: string
  primaryCTA?: { label: string, href: string }
  secondaryCTA?: { label: string, href: string }
  stats?: { label: string, value: string, icon?: React.ElementType }[]
}

export const HeroSection = ({
  badge,
  title,
  description,
  primaryCTA,
  secondaryCTA,
  stats,
}: HeroSectionProps) => (
  <section className="relative py-20 lg:py-32 overflow-hidden">
    {/* Background gradient */}
    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5" />
    
    <div className="container relative">
      <div className="max-w-3xl mx-auto text-center mb-12">
        {/* Badge */}
        {badge && (
          <div className="inline-flex items-center rounded-full px-4 py-1.5 text-sm bg-primary/10 text-primary mb-6">
            {badge}
          </div>
        )}
        
        {/* Title */}
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
          {title.split(' ').map((word, i) => (
            word === title.split(' ')[title.split(' ').findIndex(w => w.includes('*'))] 
              ? <span key={i} className="text-primary">{word.replace('*', '')} </span>
              : <span key={i}>{word} </span>
          ))}
        </h1>
        
        {/* Description */}
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          {description}
        </p>
        
        {/* CTAs */}
        <div className="flex flex-wrap justify-center gap-4">
          {primaryCTA && (
            <Button size="lg" asChild>
              <Link href={primaryCTA.href}>
                {primaryCTA.label}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          )}
          {secondaryCTA && (
            <Button size="lg" variant="outline" asChild>
              <Link href={secondaryCTA.href}>
                {secondaryCTA.label}
              </Link>
            </Button>
          )}
        </div>
      </div>
      
      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {stats.map((stat, i) => (
            <Card key={i} className="text-center p-6">
              <CardContent className="p-0">
                {stat.icon && <stat.icon className="h-8 w-8 mx-auto mb-2 text-primary" />}
                <div className="text-3xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  </section>
)
```

---

# 11. VISUAL DESIGN - CANVAS & SVG

## SVG Icon System

```tsx
// lib/icons.tsx - Custom Government Icons

import { SVGProps } from "react"

type IconProps = SVGProps<SVGSVGElement> & {
  size?: number
}

export const IconLayanan = ({ size = 24, ...props }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const IconSPBE = ({ size = 24, ...props }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
    <path d="M12 6v6l4 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)

export const IconPEMDI = ({ size = 24, ...props }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M9 11l3 3L22 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
)
```

## Canvas-Based Design (for posters/visual)

```tsx
// components/canvas/government-poster.tsx

import { useEffect, useRef } from "react"

interface PosterProps {
  title: string
  subtitle: string
  date: string
  backgroundColor?: string
}

export const GovernmentPoster = ({ 
  title, 
  subtitle, 
  date,
  backgroundColor = "#0ea5e9" 
}: PosterProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext("2d")
    if (!ctx) return
    
    // Set dimensions
    canvas.width = 1200
    canvas.height = 630
    
    // Background
    ctx.fillStyle = backgroundColor
    ctx.fillRect(0, 0, 1200, 630)
    
    // Add gradient overlay
    const gradient = ctx.createLinearGradient(0, 0, 1200, 630)
    gradient.addColorStop(0, "rgba(255,255,255,0.1)")
    gradient.addColorStop(1, "rgba(0,0,0,0.2)")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, 1200, 630)
    
    // Title
    ctx.fillStyle = "#ffffff"
    ctx.font = "bold 72px Inter, sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(title, 600, 280)
    
    // Subtitle
    ctx.font = "36px Inter, sans-serif"
    ctx.fillStyle = "rgba(255,255,255,0.9)"
    ctx.fillText(subtitle, 600, 350)
    
    // Date
    ctx.font = "24px Inter, sans-serif"
    ctx.fillStyle = "rgba(255,255,255,0.7)"
    ctx.fillText(date, 600, 420)
    
    // Decorative line
    ctx.strokeStyle = "rgba(255,255,255,0.3)"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(400, 460)
    ctx.lineTo(800, 460)
    ctx.stroke()
    
  }, [title, subtitle, date, backgroundColor])
  
  return (
    <div className="space-y-4">
      <canvas ref={canvasRef} className="w-full rounded-lg shadow-lg" />
      <Button variant="outline" onClick={() => {
        const canvas = canvasRef.current
        if (canvas) {
          const link = document.createElement("a")
          link.download = "poster.png"
          link.href = canvas.toDataURL("image/png")
          link.click()
        }
      }}>
        Download PNG
      </Button>
    </div>
  )
}
```

---

# 12. BEST PRACTICES CHECKLIST

## Pre-Implementation Checklist

```markdown
### Design System Setup
- [ ] Install & configure Tailwind CSS
- [ ] Install & configure shadcn/ui
- [ ] Set up CSS variables for theming
- [ ] Configure dark mode
- [ ] Set up Inter font family

### Component Development
- [ ] Use shadcn/ui primitives (no custom UI libs)
- [ ] Follow atomic design structure
- [ ] Implement compound components
- [ ] Add proper TypeScript types
- [ ] Include ARIA attributes
- [ ] Test keyboard navigation
- [ ] Verify color contrast (WCAG AA)

### Responsive Design
- [ ] Mobile-first approach
- [ ] Test on all breakpoints (sm, md, lg, xl, 2xl)
- [ ] Touch-friendly targets (min 44px)
- [ ] Optimize images for mobile

### Performance
- [ ] Use next/image for images
- [ ] Lazy load below-fold content
- [ ] Minimize bundle size
- [ ] Use CSS animations over JS where possible
- [ ] Preload critical fonts

### Accessibility (WCAG 2.1 AA)
- [ ] Color contrast ratio min 4.5:1
- [ ] Focus indicators visible
- [ ] Skip to content link
- [ ] Proper heading hierarchy (h1-h6)
- [ ] Alt text for images
- [ ] Form labels associated
- [ ] Error messages linked to inputs

### Government-Specific
- [ ] Kop surat format correct
- [ ] Status badges consistent
- [ ] PEMDI evaluation UI complete
- [ ] Bahasa formal dalam UI labels
- [ ] Responsive untuk layanan publik
```

## Reference Links
- Shadcn/ui: https://ui.shadcn.com
- Tailwind CSS: https://tailwindcss.com/docs
- Radix UI: https://www.radix-ui.com
- Framer Motion: https://www.framer.com/motion
- Tailwind Blocks: https://tailwindui.com, https://builtwithtailwind.com
- Awesome Shadcn: https://github.com/2-fly-4-ai/awesome-shadcnui