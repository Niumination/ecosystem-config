# SKILL: Manajemen Database & Data Management

## Deskripsi
Skill untuk membantu desain database, query optimization, backup strategy, dan data governance menggunakan PostgreSQL, MySQL, dan tools gratis lainnya.

## Tools Database Gratis

### Database Engines
```
PostgreSQL        → https://postgresql.org (open source, free)
MySQL             → https://mysql.com (open source, free)
SQLite            → https://sqlite.org (embedded, free)
MariaDB           → https://mariadb.org (MySQL fork, free)
MongoDB           → https://mongodb.com (free tier available)
Redis             → https://redis.io (open source, free)
Supabase          → https://supabase.com (Postgres as a service, free tier)
Neon              → https://neon.tech (serverless Postgres, free tier)
PlanetScale       → https://planetscale.com (MySQL serverless, free tier)
```

### Database Management Tools (GUI)
```
pgAdmin           → https://www.pgadmin.org (PostgreSQL GUI, free)
DBeaver           → https://dbeaver.io (universal, free community)
Adminer           → https://adminer.org (single PHP file, free)
HeidiSQL          → https://www.heidisql.com (Windows MySQL client)
TablePlus         → https://tableplus.com (free for 2 tables)
DataGrip          → https://jetbrains.com/datagrip (free for students)
```

### Database Monitoring
```
pg_stat_statements → Built-in Postgres feature
pgBadger           → https://pgbadger.darold.net (Postgres log analyzer)
Percona PMM        → https://www.percona.com/software/percona-monitoring (free)
Metabase           → https://metabase.com (open source BI, free)
Grafana            → https://grafana.com (free tier, dashboards)
```

## Schema Design Templates

### 1. Schema Government Administration

```sql
-- Database:府 government_db

-- Users & Permissions
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nik VARCHAR(16) UNIQUE NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    no_telp VARCHAR(15),
    unit_kerja_id UUID REFERENCES unit_kerja(id),
    role VARCHAR(20) CHECK (role IN ('admin', 'operator', 'viewer', 'supervisor')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE unit_kerja (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kode VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    parent_id UUID REFERENCES unit_kerja(id),
    eselon INT CHECK (eselon BETWEEN 1 AND 4),
    aktif BOOLEAN DEFAULT TRUE
);

-- Services & Permits
CREATE TABLE layanan (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kode_layanan VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    skla_id VARCHAR(50), -- referensi ke sistem SKLA nasional
    target_hari INT DEFAULT 14,
    biaya DECIMAL(12,2) DEFAULT 0,
    required_documents JSONB,
    aktif BOOLEAN DEFAULT TRUE
);

CREATE TABLE permohonan (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nomor_registrasi VARCHAR(30) UNIQUE NOT NULL,
    layanan_id UUID REFERENCES layanan(id),
    pemohon_nik VARCHAR(16),
    pemohon_nama VARCHAR(100),
    pemohon_kontak VARCHAR(100),
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
        'draft', 'submitted', 'verification', 'review', 
        'approved', 'rejected', 'completed', 'cancelled'
    )),
    status_history JSONB DEFAULT '[]',
    assigned_to UUID REFERENCES users(id),
    submitted_at TIMESTAMP,
    completed_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Documents
CREATE TABLE dokumen (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    permohonan_id UUID REFERENCES permohonan(id),
    jenis_dokumen VARCHAR(50),
    filename VARCHAR(255),
    file_path VARCHAR(500),
    file_size BIGINT,
    mime_type VARCHAR(100),
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Letters & Reports
CREATE TABLE surat (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nomor_surat VARCHAR(50) UNIQUE NOT NULL,
    jenis_surat VARCHAR(30),
    tanggal DATE NOT NULL,
    perihal TEXT,
    tembusan JSONB,
    created_by UUID REFERENCES users(id),
    softfile_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE laporan (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    jenis VARCHAR(30) CHECK (jenis IN ('harian', 'mingguan', 'bulanan', 'triwulan', 'tahunan')),
    periode_start DATE,
    periode_end DATE,
    judul VARCHAR(200),
    konten JSONB,
    created_by UUID REFERENCES users(id),
    approved_by UUID REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications
CREATE TABLE notifikasi (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    judul VARCHAR(200),
    pesan TEXT,
    jenis VARCHAR(30) CHECK (jenis IN ('info', 'warning', 'success', 'error')),
    is_read BOOLEAN DEFAULT FALSE,
    action_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_permohonan_status ON permohonan(status);
CREATE INDEX idx_permohonan_layanan ON permohonan(layanan_id);
CREATE INDEX idx_permohonan_tanggal ON permohonan(created_at);
CREATE INDEX idx_surat_nomor ON surat(nomor_surat);
CREATE INDEX idx_notifikasi_user_unread ON notifikasi(user_id, is_read) WHERE is_read = FALSE;
```

### 2. Schema Project & Task Management

```sql
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kode VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    status VARCHAR(20) DEFAULT 'planning',
    prioritas VARCHAR(10) DEFAULT 'medium',
    start_date DATE,
    end_date DATE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    parent_task_id UUID REFERENCES tasks(id),
    judul VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    status VARCHAR(20) DEFAULT 'todo',
    assignee_id UUID REFERENCES users(id),
    estimated_hours DECIMAL(6,2),
    actual_hours DECIMAL(6,2),
    due_date DATE,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE task_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    konten TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE task_attachments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    filename VARCHAR(255),
    file_path VARCHAR(500),
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. Schema PEMDI Indicators Tracking

```sql
CREATE TABLE pemdi_indikator (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aspek VARCHAR(50) NOT NULL,
    nomor_indikator INT NOT NULL,
    nama VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    bobot DECIMAL(4,2),
    target_nilai DECIMAL(3,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pemdi_evaluasi (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    indikator_id UUID REFERENCES pemdi_indikator(id),
    periode VARCHAR(20) NOT NULL, -- '2025-Q1', '2025-T1', etc
    nilai DECIMAL(3,2),
    skor DECIMAL(4,2),
    bukti_pendukung JSONB,
    evaluator_id UUID REFERENCES users(id),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(indikator_id, periode)
);

CREATE TABLE pemdi_bukti (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    evaluasi_id UUID REFERENCES pemdi_evaluasi(id),
    jenis_bukti VARCHAR(50),
    filename VARCHAR(255),
    file_path VARCHAR(500),
    deskripsi TEXT,
    uploaded_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Query Templates

### Common Queries untuk Government

```sql
-- 1. Statistik Layanan per Bulan
SELECT 
    DATE_TRUNC('month', created_at) as bulan,
    COUNT(*) as total_permohonan,
    COUNT(*) FILTER (WHERE status = 'completed') as selesai,
    ROUND(
        COUNT(*) FILTER (WHERE status = 'completed')::NUMERIC / 
        NULLIF(COUNT(*), 0) * 100, 2
    ) as presentase_selesai
FROM permohonan
WHERE created_at >= '2025-01-01'
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY bulan DESC;

-- 2. Capaian Kinerja per Unit Kerja
SELECT 
    uk.nama as unit_kerja,
    COUNT(DISTINCT p.id) as total_tugas,
    COUNT(*) FILTER (WHERE p.status = 'completed') as selesai,
    ROUND(AVG(EXTRACT(EPOCH FROM (p.completed_at - p.submitted_at)) / 86400), 1) as avg_days
FROM users u
JOIN unit_kerja uk ON u.unit_kerja_id = uk.id
LEFT JOIN permohonan p ON p.assigned_to = u.id
GROUP BY uk.nama
ORDER BY selesai DESC;

-- 3. Monitoring Indikator PEMDI
SELECT 
    pi.aspek,
    pi.nama as indikator,
    pe.periode,
    pe.nilai,
    pe.skor,
    CASE 
        WHEN pe.skor >= 4.5 THEN 'Sangat Baik'
        WHEN pe.skor >= 3.5 THEN 'Baik'
        WHEN pe.skor >= 2.5 THEN 'Cukup'
        WHEN pe.skor >= 1.5 THEN 'Kurang'
        ELSE 'Sangat Kurang'
    END as kategori
FROM pemdi_indikator pi
JOIN pemdi_evaluasi pe ON pi.id = pe.indikator_id
WHERE pe.periode = '2025-T1'
ORDER BY pi.aspek, pi.nomor_indikator;

-- 4. Laporan Harian: Semua Aktivitas
SELECT 
    u.nama_lengkap,
    COUNT(*) as jumlah_tugas,
    STRING_AGG(DISTINCT p.kode, ', ') as project_list
FROM tasks t
JOIN users u ON t.assignee_id = u.id
JOIN projects p ON t.project_id = p.id
WHERE t.due_date = CURRENT_DATE
    AND t.status != 'completed'
GROUP BY u.nama_lengkap;
```

## Backup & Restore Strategy

### Automated Backup Script

```bash
#!/bin/bash
# backup.sh - Automated PostgreSQL Backup

# Konfigurasi
DB_NAME="government_db"
DB_USER="postgres"
BACKUP_DIR="/backup/postgres"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# Buat direktori backup
mkdir -p $BACKUP_DIR

# Full backup dengan kompresi
pg_dump -U $DB_USER -F c -b -v -f "$BACKUP_DIR/full_${DATE}.sql"

# Backup schema only (untuk DR)
pg_dump -U $DB_USER -F c --schema-only -f "$BACKUP_DIR/schema_${DATE}.sql"

# Backup kritikal tables only ( untuk quick recovery)
pg_dump -U $DB_USER -F c -t permohonan -t users -t dokumen \
    -f "$BACKUP_DIR/critical_${DATE}.sql"

# Upload ke remote storage (S3 compatible)
# aws s3 cp $BACKUP_DIR/full_${DATE}.sql s3://my-backups/postgres/

# Cleanup old backups
find $BACKUP_DIR -name "*.sql" -mtime +$RETENTION_DAYS -delete

# Log
echo "[$(date)] Backup completed: $DB_NAME" >> /var/log/backup.log
```

### Restore Procedure

```bash
# Restore full database
pg_restore -U postgres -d government_db -c /backup/postgres/full_20250615.sql

# Restore specific table
pg_restore -U postgres -d government_db -t permohonan /backup/postgres/full_20250615.sql

# Point-in-time recovery (PITR)
# Requires WAL archiving enabled in postgresql.conf
pg_restore -U postgres -d government_db --target-time "2025-06-15 10:30:00" /path/to/backup
```

## Data Governance Templates

### Data Classification

```sql
-- Tambahkan kolom klasifikasi
ALTER TABLE dokumen ADD COLUMN klasifikasi VARCHAR(20) 
    CHECK (klasifikasi IN ('terbuka', 'internal', 'rahasia', 'sangat_rahasia'));

-- Update existing
UPDATE dokumen SET klasifikasi = 'terbuka' WHERE dokumen.id IS NOT NULL;

-- Create policy
CREATE POLICY klasifikasi_policy ON dokumen
    FOR ALL
    USING (
        CASE 
            WHEN klasifikasi = 'terbuka' THEN true
            WHEN klasifikasi = 'internal' THEN 
                current_setting('app.user_role', true) IN ('admin', 'internal', 'supervisor')
            WHEN klasifikasi = 'rahasia' THEN 
                current_setting('app.user_role', true) IN ('admin', 'supervisor')
            WHEN klasifikasi = 'sangat_rahasia' THEN 
                current_setting('app.user_role', true) = 'admin'
            ELSE false
        END
    );
```

## Performance Optimization

### Indexing Strategy

```sql
-- Partial indexes untuk query spesifik
CREATE INDEX idx_permohonan_pending ON permohonan(created_at) 
    WHERE status IN ('submitted', 'verification');

CREATE INDEX idx_tasks_today ON tasks(due_date) 
    WHERE status != 'completed';

-- Expression indexes
CREATE INDEX idx_permohonan_nomor_upper ON permohonan(UPPER(nomor_registrasi));

-- JSONB indexes
CREATE INDEX idx_permohonan_status_json ON permohonan USING GIN (status_history);
CREATE INDEX idx_permohonan_bukti_path ON dokumen USING GIN (bukti_pendukung);
```

### Monitoring Queries

```sql
-- Slow queries (> 1 second)
SELECT 
    query,
    calls,
    total_exec_time,
    mean_exec_time,
    max_exec_time
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 20;

-- Table bloat
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
    n_live_tup,
    n_dead_tup,
    ROUND(n_dead_tup::NUMERIC / NULLIF(n_live_tup + n_dead_tup, 0) * 100, 2) as dead_pct
FROM pg_stat_user_tables
WHERE n_dead_tup > 100
ORDER BY dead_pct DESC;
```

## Migration Best Practices

```sql
-- 1. Add column dengan default (Postgres 11+)
ALTER TABLE users ADD COLUMN last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- 2. Safe column rename (two-step)
ALTER TABLE users ADD COLUMN nama_depan VARCHAR(100);
UPDATE users SET nama_depan = SPLIT_PART(nama_lengkap, ' ', 1);
ALTER TABLE users RENAME COLUMN nama_depan TO nama_depan;

-- 3. Add NOT NULL column dengan data
ALTER TABLE users ADD COLUMN nip VARCHAR(20);
UPDATE users SET nip = 'UNKNOWN' WHERE nip IS NULL;
ALTER TABLE users ALTER COLUMN nip SET NOT NULL;

-- 4. Create table sebagai backup sebelum drop
CREATE TABLE users_backup AS SELECT * FROM users;
DROP TABLE users;
```