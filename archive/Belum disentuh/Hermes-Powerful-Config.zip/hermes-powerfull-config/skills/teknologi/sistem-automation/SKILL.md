# SKILL: Sistem Automasi Perkantoran & Bisnis

## Deskripsi
Skill untuk membantu membangun sistem automasi perkantoran, workflow automation, chatbot, dan business process automation menggunakan tool gratis.

## Stack Teknologi Automasi Gratis

### Workflow Automation
```
n8n              → https://n8n.io (open source, self-hosted gratis)
AppFlowy         → https://appflowy.io (open source Notion alternative)
Kestra           → https://kestra.io (open source orchestration)
Windmill         → https://windmill.dev (open source automation)
Huginn           → https://github.com/huginn/huginn (ruby-based automation)
```

### Chatbot & AI Agents
```
Flowise          → https://flowiseai.com (drag-drop LLM flows)
LangFlow         → https://github.com/langflow-ai/langflow
Botpress         → https://botpress.com (free tier available)
OpenAssistant    → https://open-assistant.io
Chatterbot       → https://github.com/gunthercox/ChatterBot

# Free LLM APIs
- Groq API (14,400 req/day free)
- OpenRouter free tier
- Google Gemini API (free tier generous)
```

### Cron & Scheduling
```
systemd timers   → Linux native
launchd          → macOS native
cron             → Universal
jobber           → https://github.com/jobber/jobber (recurring jobs)
```

### Web Scraping & Data
```
Apify            → https://apify.com (free tier: $5 credit)
Scrapy           → https://scrapy.org (Python framework)
Playwright       → https://playwright.dev (browser automation)
Puppeteer        → https://pptr.dev (Node.js)
httpx            → Python async HTTP
BeautifulSoup    → HTML parsing
```

## Template Automasi

### 1. Automasi Pembuatan Laporan Otomatis

```python
#!/usr/bin/env python3
"""
Automated Report Generator untuk laporan harian Diskominfo
Menggunakan Groq API (gratis) untuk生成 laporan
"""
import os
import json
from datetime import datetime, timedelta
from supabase import create_client

# Konfigurasi
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

# Inisialisasi Supabase
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

def generate_daily_report():
    """Generate laporan harian dari data yang dikumpulkan"""
    
    # Ambil data kegiatan hari ini
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    # Query dari database
    response = supabase.table('kegiatan').select('*').eq('tanggal', yesterday).execute()
    activities = response.data
    
    # Format data untuk LLM
    data_summary = {
        'tanggal': yesterday,
        'jumlah_kegiatan': len(activities),
        'kegiatan': [a['deskripsi'] for a in activities],
        'sistem_diakses': sum(1 for a in activities if a.get('jenis') == 'sistem'),
        'tiket_diselesaikan': sum(1 for a in activities if a.get('status') == 'selesai')
    }
    
    # Generate laporan menggunakan prompt template
    prompt = f"""
    Buat laporan harian格式 resmi pemerintahan untuk:
    
    Tanggal: {yesterday}
    Jumlah Kegiatan: {data_summary['jumlah_kegiatan']}
    Detail Kegiatan: {', '.join(data_summary['kegiatan'])}
    Sistem Diakses: {data_summary['sistem_diakses']} kali
    Tiket Diselesaikan: {data_summary['tiket_diselesaikan']}
    
    Laporan harus mencakup:
    1. Ringkasan Eksekutif
    2. Detail Kegiatan
    3. Capaian Kinerja
    4. Kendala dan Solusi
    5. Rencana Tindak Lanjut
    
    Gunakan format surat resmi Indonesia.
    """
    
    # Call Groq API (gratis)
    # Implementasi call API...
    
    return generated_report

def save_report(report, filename):
    """Simpan laporan ke file dan database"""
    # Save to file
    with open(f"reports/{filename}", 'w') as f:
        f.write(report)
    
    # Save to database
    supabase.table('laporan').insert({
        'tanggal': datetime.now().date().isoformat(),
        'jenis': 'harian',
        'konten': report,
        'filename': filename
    }).execute()

if __name__ == "__main__":
    report = generate_daily_report()
    filename = f"laporan-harian-{datetime.now().strftime('%Y%m%d')}.docx"
    save_report(report, filename)
    print(f"Laporan disimpan: {filename}")
```

### 2. Automasi Notifikasi WhatsApp/Telegram

```javascript
// n8n Workflow: Notifikasi Tiket Baru
// Trigger: Supabase Webhook (new ticket created)
// Action: Format message + Send Telegram

const axios = require('axios');

const TELEGRAM_BOT_TOKEN = $env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = $env.TELEGRAM_CHAT_ID;

const ticketData = $json;

// Format pesan
const message = `
🔔 *Tiket Baru Masuk*

📋 ID       : ${ticketData.id}
👤 Pelanggan: ${ticketData.nama}
📝 Masalah  : ${ticketData.deskripsi}
⚡ Priority : ${ticketData.priority}
📅 Tanggal  : ${new Date(ticketData.created_at).toLocaleString('id-ID')}

👨‍💻 *Assigned*: ${ticketData.assigned_to || 'Belum ada'}
`;

await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
  chat_id: TELEGRAM_CHAT_ID,
  text: message,
  parse_mode: 'Markdown'
});
```

### 3. Automasi Scraper Data Statistik

```python
#!/usr/bin/env python3
"""
Website Statistics Auto-Scraper
Mendukung scraping dari multiple sources
"""
import httpx
from selectolax.parser import HTMLParser
import asyncio
from datetime import datetime

async def scrape BPS_data():
    """Ambil data statistik dari BPS"""
    async with httpx.AsyncClient(timeout=30) as client:
        # Contoh: scrap indikator strategis
        response = await client.get("https://acehtengahkab.bps.go.id/")
        html = HTMLParser(response.text)
        
        # Parse data yang diperlukan
        indicators = []
        for item in html.css('.indicator-item'):
            indicators.append({
                'title': item.css_first('h3').text(),
                'value': item.css_first('.value').text(),
                'source': 'BPS'
            })
        
        return indicators

async def scrape_opendata():
    """Ambil data dari portal open data"""
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            "https://data.go.id/api/v1/dataset",
            headers={'Authorization': 'Bearer YOUR_API_KEY'}
        )
        return response.json()

async def main():
    results = await asyncio.gather(
        scrape BPS_data(),
        scrape_opendata()
    )
    
    # Save results
    with open(f'scraped-data-{datetime.now().date()}.json', 'w') as f:
        json.dump(results, f, indent=2)

if __name__ == "__main__":
    asyncio.run(main())
```

### 4. Automasi Email处置

```python
#!/usr/bin/env python3
"""
Email Auto-Classifier & Auto-Reply
Menyortir email masuk dan membalas otomatis
"""
import imaplib
import email
from email.header import decode_header
import logging
from datetime import datetime

class EmailAutomator:
    def __init__(self, imap_server, username, password):
        self.conn = imaplib.IMAP4_SSL(imap_server)
        self.conn.login(username, password)
    
    def fetch_unread(self):
        self.conn.select("INBOX")
        status, messages = self.conn.search(None, 'UNSEEN')
        return messages[0].split()
    
    def parse_email(self, msg_id):
        status, data = self.conn.fetch(msg_id, '(RFC822)')
        msg = email.message_from_bytes(data[0][1])
        
        subject = self._decode_header(msg['Subject'])
        sender = msg['From']
        body = self._get_body(msg)
        
        return {'subject': subject, 'sender': sender, 'body': body}
    
    def classify_intent(self, email_data):
        """Klasifikasi intent email menggunakan keyword matching"""
        subject = email_data['subject'].lower()
        body = email_data['body'].lower()
        
        combined = subject + ' ' + body
        
        if any(k in combined for k in ['permohonan', 'request', 'minta', 'butuh']):
            return 'REQUEST'
        elif any(k in combined for k in ['keluhan', 'complaint', ' masalah', 'gangguan']):
            return 'COMPLAINT'
        elif any(k in combined for k in ['konfirmasi', 'balas', 'reply']):
            return 'REPLY'
        else:
            return 'GENERAL'
    
    def auto_reply(self, email_data, intent):
        """Generate auto-reply based on intent"""
        templates = {
            'REQUEST': f"""
Yth. {email_data['sender']},

Terima kasih atas permohonan Anda. Email Anda telah kami terima dan sedang dalam proses review.

Nomor Tiket: TIK-{datetime.now().strftime('%Y%m%d%H%M')}
Estimasi Respon: 1x24 jam kerja.

Salam,
Tim Diskominfo Aceh Tengah
            """,
            'COMPLAINT': f"""
Yth. {email_data['sender']},

Kami mohon maaf atas ketidaknyamanan yang dialami. Keluhan Anda telah kami catat:

Nomor Tiket: TIK-{datetime.now().strftime('%Y%m%d%H%M')}
Prioritas: HIGH
Estimasi Penyelesaian: 2x24 jam.

Tim teknis kami sedang bekerja menyelesaikan masalah ini.

Terima kasih atas kesabarannya,
Tim Diskominfo Aceh Tengah
            """
        }
        return templates.get(intent, templates['GENERAL'])
    
    def _decode_header(self, header):
        decoded, charset = decode_header(header)[0]
        if isinstance(decoded, bytes):
            return decoded.decode(charset or 'utf-8')
        return decoded
    
    def _get_body(self, msg):
        if msg.is_multipart():
            return ''.join(self._get_body(p) for p in msg.get_payload())
        return msg.get_payload()

# Cron job: runs every 15 minutes
# */15 * * * * /usr/bin/python3 /path/to/email_automator.py
```

## Workflow Templates untuk n8n

### Template: Approval Workflow

```yaml
# n8n workflow JSON template
{
  "name": "Government Approval Workflow",
  "nodes": [
    {
      "name": "Webhook Trigger",
      "type": "n8n-nodes-base.webhook",
      "parameters": {
        "path": "submission-approval"
      }
    },
    {
      "name": "Parse Data",
      "type": "n8n-nodes-base.set",
      "parameters": {
        "mode": "manual",
        "fieldsToSet": [
          {"name": "title", "value": "={{ $json.title }}"},
          {"name": "requester", "value": "={{ $json.requester }}"},
          {"name": "department", "value": "={{ $json.department }}"}
        ]
      }
    },
    {
      "name": "Notify Approver",
      "type": "n8n-nodes-base.telegram",
      "parameters": {
        "chatId": "{{ $env.APPROVER_CHAT_ID }}",
        "text": "📋 Permohonan baru memerlukan persetujuan:\n\n{{ $json.title }}\nPemohon: {{ $json.requester }}"
      }
    },
    {
      "name": "Wait for Approval",
      "type": "n8n-nodes-base.wait",
      "parameters": {
        "amount": 48,
        "unit": "hours"
      }
    },
    {
      "name": "Check Approval",
      "type": "n8n-nodes-base.switch",
      "parameters": {
        "dataType": "string",
        "valueComparison": {
          "leftValue": "={{ $json.status }}",
          "operation": "equals",
          "rightValue": "approved"
        }
      }
    },
    {
      "name": "Notify Requester (Approved)",
      "type": "n8n-nodes-base.email",
      "parameters": {
        "to": "={{ $json.requester_email }}",
        "subject": "✅ Permohonan Disetujui",
        "html": "Permohonan Anda telah disetujui."
      }
    }
  ],
  "connections": {}
}
```

## Integrations Gratis

### Dengan Google Workspace (Gratis)
```python
# Gmail API, Google Sheets API, Google Drive API
# Semua memiliki free tier generous

from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/spreadsheets'
]

def get_gmail_service():
    creds = Credentials.from_service_account_info(
        os.getenv('GOOGLE_SERVICE_ACCOUNT_JSON'), scopes=SCOPES
    )
    return build('gmail', 'v1', credentials=creds)
```

### Dengan WhatsApp Business (Free Tier)
```python
# Menggunakan whatsapp-web.js atau baileys
from baileys import WhatsAppWeb

# Gratis, berbasis browser automation
```

## Cron Jobs untuk Automasi

### Crontab Entries
```bash
# Edit crontab
crontab -e

# Setiap 15 menit - cek email baru
*/15 * * * * /usr/bin/python3 /home/user/automation/email_handler.py >> /var/log/automation.log 2>&1

# Setiap jam - sync data
0 * * * * /usr/bin/python3 /home/user/automation/data_sync.py

# Setiap hari 07:00 - generate laporan
0 7 * * * /usr/bin/python3 /home/user/automation/daily_report.py

# Setiap hari 00:00 - backup database
0 0 * * * /usr/bin/pg_dump -U postgres -F c mydb > /backup/db-$(date +\%Y\%m\%d).sql

# Setiap minggu Senin 08:00 - reminder meeting
0 8 * * 1 echo "Meeting scheduling reminder" | mail -s "Weekly Meeting" user@domain.com
```