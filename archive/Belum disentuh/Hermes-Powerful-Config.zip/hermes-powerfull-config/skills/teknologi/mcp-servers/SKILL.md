# SKILL: MCP Servers Configuration & Indonesian Government Integration

## Deskripsi
Konfigurasi lengkap MCP (Model Context Protocol) servers untuk kebutuhan pengembangan dan integrasi dengan sistem pemerintahan Indonesia.

---

## DAFTAR ISI
1. [MCP Servers yang Sudah Terinstall](#1-mcp-servers-yang-sudah-terinstall)
2. [MCP Servers Tambahan yang Direkomendasikan](#2-mcp-servers-tambahan-yang-direkomendasikan)
3. [Indonesian Government APIs & MCP](#3-indonesian-government-apis--mcp)
4. [Setup & Configuration](#4-setup--configuration)
5. [Security Best Practices](#5-security-best-practices)
6. [Indonesian Data Sources](#6-indonesian-data-sources)

---

# 1. MCP SERVERS YANG SUDAH TERINSTALL

## Core Infrastructure (Wajib)
```yaml
mcp_servers:
  # File System - Akses file lokal
  filesystem:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-filesystem", "/home/user"]
  
  # GitHub - Manajemen repository
  github:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_PERSONAL_ACCESS_TOKEN: "${GITHUB_TOKEN}"
  
  # Playwright - Browser automation (FREE!)
  playwright:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-playwright"]
  
  # Sequential Thinking - Enhanced reasoning
  sequential-thinking:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-sequential-thinking"]
  
  # Memory - Persistent memory
  memory:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-memory"]
```

## Database & Backend
```yaml
  # PostgreSQL - Database operations
  postgres:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-postgres"]
    env:
      DATABASE_URL: "${SUPABASE_DB_URL}"
  
  # Supabase - Database, Auth, Storage (Remote)
  supabase:
    url: "https://mcp.supabase.com/mcp"
```

## Cloud & DevOps
```yaml
  # Cloudflare - CDN, Workers, D1
  cloudflare:
    url: "https://mcp.cloudflare.com/mcp"
    env:
      CLOUDFLARE_API_TOKEN: "${CLOUDFLARE_API_TOKEN}"
  
  # Sentry - Error tracking
  sentry:
    url: "https://mcp.sentry.dev/mcp"
  
  # Atlassian - Jira, Confluence
  atlassian:
    url: "https://mcp.atlassian.com/v1/mcp"
```

## Search & Documentation
```yaml
  # Brave Search - Web search
  brave-search:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-brave-search"]
    env:
      BRAVE_SEARCH_API_KEY: "${BRAVE_SEARCH_API_KEY}"
  
  # Microsoft Learn - Documentation
  microsoft-learn:
    url: "https://learn.microsoft.com/api/mcp"
  
  # Context7 - Library documentation
  context7:
    url: "https://mcp.context7.com/mcp"
  
  # Exa - Web search
  exa:
    url: "https://mcp.exa.ai/mcp"
```

---

# 2. MCP SERVERS TAMBAHAN YANG DIREKOMENDASIKAN

## Docker & Container
```bash
# Install Docker MCP Server
npx -y @QuantGeekDev/docker-mcp

# Atau untuk Python version
pip install docker-mcp
```

```yaml
# config.yaml addition
docker:
  command: "npx"
  args: ["-y", "@QuantGeekDev/docker-mcp"]
  # Provides: container creation, deployment, log retrieval, monitoring
```

## SQLite (Lightweight Database)
```bash
# Install SQLite MCP
npx -y @modelcontextprotocol/server-sqlite
```

```yaml
sqlite:
  command: "npx"
  args: ["-y", "@modelcontextprotocol/server-sqlite", "./data.db"]
```

## Kubernetes (Jika perlu)
```bash
# Install kubectl MCP
npx -y @rohitg00/kubectl-mcp-server

# Atau TypeScript version
npx -y @Flux159/mcp-server-kubernetes
```

## YouTube Transcript (untuk tutorial)
```bash
npx -y @kimtaeyoon83/mcp-server-youtube-transcript
```

```yaml
youtube-transcript:
  command: "npx"
  args: ["-y", "@kimtaeyoon83/mcp-server-youtube-transcript"]
  # Use case: Ambil transcript tutorial untuk analysis
```

## Fetch (HTTP Requests)
```bash
npx -y @modelcontextprotocol/server-fetch
```

```yaml
fetch:
  command: "npx"
  args: ["-y", "@modelcontextprotocol/server-fetch"]
  # Advanced HTTP requests dengan caching
```

---

# 3. INDONESIAN GOVERNMENT APIS & MCP

## Referensi Utama: suryast/indonesia-gov-apis

Repository GitHub ini menyediakan **50+ Indonesian Government APIs** dengan MCP server setup.

### API Sources yang Available

#### Tier 1: Open APIs (Langsung bisa dipakai)
```javascript
// 1. Satu Data (data.go.id) - CKAN API
const response = await fetch("https://data.go.id/api/3/action/package_search", {
  params: { q: "keyword", rows: 10 }
});

// 2. BMKG (data.bmkg.go.id) - Earthquake + Weather JSON
const bmkg = await fetch("https://data.bmkg.go.id/autogempa.json");

// 3. BNPB Disaster (dibi.bnpb.go.id) - REST + GeoJSON
const disaster = await fetch("https://dibi.bnpb.go.id/api/v1/disaster");

// 4. Bank Indonesia (www.bi.go.id)
const bi = await fetch("https://www.bi.go.id/api/statistik/exchangerate");
```

#### Tier 2: APIs yang butuh scraping
- BPS (webapi.bps.go.id) - Cloudflare protected
- IDX (idx.co.id) - Stock data
- DJPB Treasury - Government budget

#### Tier 3: Regional Open Data Portals
- Aceh Tengah Open Data
- Provinsi Aceh
- Kota Banda Aceh
- Kabupaten lainnya

#### Tier 4: Ministry-specific Sources
- Kemenkominfo
- KemenPAN RB
- Kemendagri
- Keuangan ( Kemenkeu )

#### Tier 5: Transparency & Anti-corruption
- JDIH (Jaringan Dokumentasi dan Informasi Hukum)
- LPSE (Lelang Pengadaan Barang/Jasa)
- Eprocurement

## Indonesian MCP Server untuk Hukum (Pasal.id)

```bash
# Connect Pasal.id MCP Server (Indonesian Law Index)
claude mcp add --transport http pasal-id https://pasal-mcp-server-production.up.railway.app/mcp

# Remote MCP server untuk cariUU Indonesia
```

## Custom Indonesian Government MCP

```typescript
// src/mcp/indonesia-gov.ts
// Custom MCP Server untuk Indonesian Government Data

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({
  name: "indonesia-gov-mcp",
  version: "1.0.0",
});

// Tool: Search Satu Data Indonesia
server.setRequestHandler({}, async (request) => {
  if (request.method === "tools/list") {
    return {
      tools: [
        {
          name: "search_satu_data",
          description: "Search Indonesian open data portal (data.go.id)",
          inputSchema: {
            type: "object",
            properties: {
              query: { type: "string", description: "Search query" },
              limit: { type: "number", default: 10 },
            },
          },
        },
        {
          name: "get_bmkg_earthquake",
          description: "Get latest earthquake data from BMKG",
          inputSchema: {
            type: "object",
            properties: {},
          },
        },
        {
          name: "get_bnpb_disaster",
          description: "Get disaster data from BNPB",
          inputSchema: {
            type: "object",
            properties: {
              province: { type: "string" },
              disaster_type: { type: "string" },
            },
          },
        },
        {
          name: "get_exchange_rate",
          description: "Get BI exchange rates",
          inputSchema: {
            type: "object",
            properties: {
              date: { type: "string" },
            },
          },
        },
        {
          name: "search_regulation",
          description: "Search Indonesian regulations (Perpu, UU, PP, Permen)",
          inputSchema: {
            type: "object",
            properties: {
              query: { type: "string" },
              year: { type: "number" },
              type: { 
                type: "string", 
                enum: ["uu", "pp", "permen", "perpres", "perbup", "kepbup"]
              },
            },
          },
        },
      ],
    };
  }
  
  if (request.method === "tools/call") {
    const { name, arguments: args } = request.params;
    
    switch (name) {
      case "search_satu_data":
        const response = await fetch(
          `https://data.go.id/api/3/action/package_search?q=${args.query}&rows=${args.limit || 10}`
        );
        return await response.json();
        
      case "get_bmkg_earthquake":
        const bmkg = await fetch("https://data.bmkg.go.id/autogempa.json");
        return await bmkg.json();
        
      case "get_bnpb_disaster":
        const disaster = await fetch("https://dibi.bnpb.go.id/api/v1/disaster");
        return await disaster.json();
        
      case "get_exchange_rate":
        const rate = await fetch("https://www.bi.go.id/api/statistik/exchangerate");
        return await rate.json();
        
      case "search_regulation":
        // Connect ke JDIH atau Pasal.id API
        return { message: "Regulation search via JDIH API" };
        
      default:
        return { error: "Unknown tool" };
    }
  }
  
  return { error: "Unknown method" };
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
```

---

# 4. SETUP & CONFIGURATION

## Install Semua MCP Servers

```bash
#!/bin/bash
# install-mcp-servers.sh

echo "🔧 Installing MCP Servers for Hermes Agent..."

# Core MCP Servers
echo "📦 Installing core MCP servers..."
npx -y @modelcontextprotocol/server-filesystem /home/user
npx -y @modelcontextprotocol/server-github
npx -y @modelcontextprotocol/server-playwright
npx -y @modelcontextprotocol/server-sequential-thinking
npx -y @modelcontextprotocol/server-memory
npx -y @modelcontextprotocol/server-brave-search
npx -y @modelcontextprotocol/server-postgres
npx -y @modelcontextprotocol/server-google-workspace

# Additional MCP Servers
echo "📦 Installing additional MCP servers..."
npx -y @QuantGeekDev/docker-mcp
npx -y @modelcontextprotocol/server-fetch
npx -y @modelcontextprotocol/server-sqlite

# YouTube Transcript
npx -y @kimtaeyoon83/mcp-server-youtube-transcript

echo "✅ MCP Servers installation complete!"
echo ""
echo "To use Indonesian Government APIs, add to config.yaml:"
echo "- satu-data (data.go.id)"
echo "- bmkg (BMKG earthquake data)"
echo "- bnpb (Disaster data)"
echo "- peraturan (JDIH legal database)"
```

## Configuration di config.yaml

```yaml
# Tambahkan di mcp_servers section:

# Indonesian Government MCP
indonesia-gov:
  command: "node"
  args: ["path/to/indonesia-gov-mcp.js"]
  # Provides: Satu Data, BMKG, BNPB, exchange rates

# Local SQLite (untuk quick queries)
sqlite:
  command: "npx"
  args: ["-y", "@modelcontextprotocol/server-sqlite", "~/.hermes/data.db"]

# Docker management
docker:
  command: "npx"
  args: ["-y", "@QuantGeekDev/docker-mcp"]

# Fetch untuk HTTP requests
fetch:
  command: "npx"
  args: ["-y", "@modelcontextprotocol/server-fetch"]
```

---

# 5. SECURITY BEST PRACTICES

## ⚠️ Warning: Security Findings

Berdasarkan research, **66% scanned MCP servers had security findings**. 

### Guidelines:
1. **Only install 3-5 servers** - Each adds 500-1000 tokens to context
2. **Stick to vendor-maintained servers** - GitHub, Figma, Sentry, Microsoft
3. **Verify npm packages** - Check against official docs
4. **No API keys in code** - Use environment variables
5. **RBAC for databases** - Role-Based Access Control

### Recommended Servers (Safe):
```yaml
# Vendor-maintained (Trustworthy)
- github (official MCP)
- filesystem (official MCP)
- playwright (official MCP)
- supabase (official MCP)
- cloudflare (official MCP)
- sentry (official MCP)
- google-workspace (official MCP)

# Community (Verify first)
- docker-mcp (verified, 482 stars)
- kubectl-mcp (verified, 910 stars)
- sqlite-mcp (official MCP)
```

### Security Checklist:
```
[ ] All API keys in .env (not in code)
[ ] MCP servers use HTTPS (no HTTP)
[ ] No sensitive data in logs
[ ] Regular updates for MCP packages
[ ] Test MCP servers in dev environment first
[ ] Monitor token usage
```

---

# 6. INDONESIAN DATA SOURCES

## Portal yang Sudah Ready (2026)

| # | Portal | Status | Notes |
|---|--------|--------|-------|
| 1 | Satu Data (data.go.id) | ✅ Working | CKAN API stable |
| 2 | BMKG (data.bmkg.go.id) | ✅ Working | Earthquake + weather |
| 3 | BNPB Disaster (dibi.bnpb.go.id) | ✅ Working | REST + GeoJSON API |
| 4 | Bank Indonesia | ✅ Working | Exchange rates |
| 5 | JDIH BPK | ⚠️ Geo-blocked | Blocked from AU |
| 6 | LPSE | ⚠️ Cloudflare | 589 portals affected |

## Quick Access Functions

```javascript
// Indonesia Government Data Access

// 1. Get earthquake data
async function getEarthquake() {
  const res = await fetch("https://data.bmkg.go.id/autogempa.json");
  return res.json();
}

// 2. Search open data
async function searchOpenData(query) {
  const res = await fetch(
    `https://data.go.id/api/3/action/package_search?q=${encodeURIComponent(query)}`
  );
  return res.json();
}

// 3. Get disaster data
async function getDisasterData(province = "aceh") {
  const res = await fetch(`https://dibi.bnpb.go.id/api/v1/disaster?province=${province}`);
  return res.json();
}

// 4. Exchange rates
async function getExchangeRates() {
  const res = await fetch("https://www.bi.go.id/api/statistik/exchangerate");
  return res.json();
}

// 5. BPS Statistics (with API key)
async function getBPSData(indicator) {
  const res = await fetch(
    `https://webapi.bps.go.id/v1/indicator/${indicator}`,
    { headers: { "Authorization": `Bearer ${BPS_API_KEY}` }}
  );
  return res.json();
}
```

## MCP Servers untuk Government Indonesia

```bash
# Install Indonesian Government MCP
# Reference: https://github.com/suryast/indonesia-gov-apis

# 1. Pasal.id - Indonesian Law Search
npx @pasal-id/mcp-server

# 2. Satu Data Indonesia
# Custom implementation needed

# 3. BMKG Integration
# Custom implementation (no official MCP)
```

## Indonesian API Status Dashboard

```markdown
## Real-time Status (Updated: 2026-03-29)

| Portal | Jakarta | Singapore | Sydney | Notes |
|--------|---------|-----------|--------|-------|
| data.go.id | ✅ 200 | ✅ 200 | ✅ 200 | Stable |
| webapi.bps.go.id | ❌ 403 | ❌ 403 | ❌ 403 | Cloudflare |
| data.bmkg.go.id | ✅ 200 | ✅ 200 | ✅ 200 | Stable |
| idx.co.id | ❌ 403 | ❌ 403 | ❌ 403 | Cloudflare |
| dibi.bnpb.go.id | ✅ 200 | ✅ 200 | ✅ 200 | Stable |
|jdih.bpk.go.id | ✅ 200 | ❌ 403 | ❌ 403 | Geo-blocked |
```

---

## Referensi Tambahan

### Awesome MCP Servers
- https://github.com/hireblackout/awesome-mcp-servers (50+ servers)
- https://github.com/appcypher/awesome-mcp-servers
- https://github.com/tolkonepiu/best-of-mcp-servers

### Indonesian Government APIs
- https://github.com/suryast/indonesia-gov-apis (50+ APIs)
- https://github.com/suryast/indonesia-gov-apis/blob/main/SKILL.md

### Official MCP Documentation
- https://modelcontextprotocol.io
- https://github.com/modelcontextprotocol

---

## Summary

### MCP Servers yang Sudah Terinstall (13):
1. ✅ filesystem - File operations
2. ✅ github - Repository management
3. ✅ playwright - Browser automation
4. ✅ sequential-thinking - Reasoning
5. ✅ memory - Persistent memory
6. ✅ postgres - Database
7. ✅ supabase - Database + Auth
8. ✅ cloudflare - CDN/Workers
9. ✅ sentry - Error tracking
10. ✅ atlassian - Jira/Confluence
11. ✅ brave-search - Web search
12. ✅ microsoft-learn - Documentation
13. ✅ context7 - Library docs

### MCP Servers Tambahan (Recommended):
14. 📦 docker - Container management
15. 📦 sqlite - Lightweight database
16. 📦 fetch - HTTP requests
17. 📦 youtube-transcript - Video transcripts
18. 📦 kubectl - Kubernetes (if needed)

### Indonesian Government Integration:
- Satu Data (data.go.id) - ✅ Direct API
- BMKG - ✅ Direct API
- BNPB - ✅ Direct API
- Bank Indonesia - ✅ Direct API
- Pasal.id - 📦 MCP available

### Best Practice:
- Install only 3-5 servers (context overhead)
- Use vendor-maintained servers
- Verify npm packages
- No sensitive data in code