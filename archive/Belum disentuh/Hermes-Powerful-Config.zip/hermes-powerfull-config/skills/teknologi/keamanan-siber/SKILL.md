# SKILL: Keamanan Siber & Cyber Defense

## Deskripsi
Skill untuk membantu implementasi keamanan siber di pemerintahan, analisis ancaman, hardening sistem, dan response handling insiden.

## Framework & Standar

### Referensi Regulasi Indonesia
- UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi (UU PDP)
- Perpres No. 47 Tahun 2023 tentang Politik Umum Negara di Bidang Pertahanan
- Perpres No. 12 Tahun 2025 tentang Sistem Pemerintahan Berbasis Elektronik
- PermenKominfo No. 5 Tahun 2020 tentang Sistem Manajemen Pengamanan Informasi
- NIST Cybersecurity Framework (adaptasi Indonesia)
- ISO 27001:2022

### Indikator PEMDI - Aspek Keamanan Siber (4 Indikator)
1. Kematangan pengelolaan risiko keamanan siber
2. Kematangan penanganan insiden keamanan siber
3. Kematangan pengelolaan keamanan pihak ketiga
4. Kematangan pengelolaan aset teknologi informasi

## Tools Keamanan Gratis

### Scanning & Analysis
```
Nmap           → https://nmap.org (network scanner)
Wireshark      → https://wireshark.org (packet analyzer)
OWASP ZAP      → https://www.zaproxy.org (web vulnerability scanner)
Nikto          → https://sectools.org/tool/nikto/ (web server scanner)
Metasploit     → https://metasploit.com (penetration testing)
Burp Suite     → https://portswigger.net/burp (community edition)
SQLMap         → https://sqlmap.org (SQL injection)
Amass          → https://github.com/owasp-amass/amass (subdomain enum)
```

### Hardening & Monitoring
```
ClamAV         → https://www.clamav.net (antivirus linux)
OSSEC          → https://www.ossec.net (HIDS)
Wazuh          → https://wazuh.com (SIEM gratis)
TheHive        → https://thehive-project.org (incident response)
MISP           → https://www.misp-project.org (threat intel)
Suricata       → https://suricata.io (IDS/IPS)
Crowdsec       → https://crowdsec.net (crowd-driven security)
```

### Password & Crypto
```
John the Ripper → https://www.openwall.com/john/ (password cracker)
Hashcat        → https://hashcat.net (GPU password recovery)
OpenSSL        → Built-in (TLS/SSL, certificates)
Certbot        → https://certbot.eff.org (SSL certificates gratis)
```

### OSINT & Reconnaissance
```
Shodan         → https://shodan.io (IoT search engine)
Censys         → https://censys.io (search engine for servers)
Maltego        → Community edition (link analysis)
theHarvester   → https://github.com/laramies/theHarvester (email recon)
Recon-ng       → https://github.com/lanmaster53/recon-ng
```

## Checklist Keamanan

### [ ] Server Hardening (Linux/macOS)

```bash
# 1. Update sistem
sudo softwareupdate --install --all

# 2. Firewall configuration
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# 3. SSH hardening
# Edit /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
ClientAliveInterval 300

# 4. Fail2ban (brute force protection)
brew install fail2ban  # macOS
sudo apt install fail2ban  # Ubuntu

# 5. Log monitoring
sudo apt install auditd
sudo auditctl -e 1

# 6. Disable unnecessary services
sudo systemctl disable cups
sudo systemctl disable bluetooth
```

### [ ] Web Server Security

```nginx
# Nginx hardening example (nginx.conf)
server {
    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self'" always;
    
    # Hide nginx version
    server_tokens off;
    
    # Rate limiting
    limit_req_zone $binary_remote_addr zone=one:10m rate=10r/s;
    limit_req zone=one burst=20;
}
```

### [ ] Database Security

```sql
-- PostgreSQL hardening
-- Edit postgresql.conf
ssl = on
ssl_cert_file = '/path/to/server.crt'
ssl_key_file = '/path/to/server.key'

-- Create limited user
CREATE USER app_user WITH PASSWORD 'strong_password';
GRANT CONNECT ON DATABASE mydb TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;

-- Enable audit logging
ALTER DATABASE mydb SET log_statement = 'all';
ALTER DATABASE mydb SET log_connections = on;
ALTER DATABASE mydb SET log_disconnections = on;

-- Backup encryption
pg_dump -F c -b -v -f backup.tar.gz mydb
openssl enc -aes-256-cbc -salt -out backup.enc -in backup.tar.gz
```

### [ ] Network Security

```bash
# macOS firewall (PF - Packet Filter)
# Create /etc/pf.anchors/com.custom
# Block incoming on common ports
block in proto tcp from any to any port 23
block in proto tcp from any to any port 135
block in proto tcp from any to any port 139
block in proto tcp from any to any port 445

# Enable firewall
sudo pfctl -e

# Network segmentation check
# Verify VLAN configuration
# Ensure management network separate from production
```

## Incident Response Procedure

### Fase 1: Deteksi & Identifikasi
```
1. Terima laporan insiden (user/system alert)
2. Kategorikan severity:
   - Critical: Data breach, ransomware, service down
   - High: Suspicious activity, failed intrusion attempts
   - Medium: Policy violation, minor vulnerability found
   - Low: Configuration drift, minor misconfiguration

3. Dokumentasi awal:
   - Waktu kejadian
   - Sistem terdampak
   - Indikator compromise (IOC)
   - Sumber laporan
```

### Fase 2: Containment
```
Immediate Actions:
1. Isolasi sistem terdampak (network isolation)
2. Block malicious IP/domains
3. Reset compromised credentials
4. Preserve evidence (disk image, logs)
5. Notifikasi tim terkait

Long-term Containment:
1. Patch vulnerability
2. Update firewall rules
3. Implement monitoring
4. Update detection rules
```

### Fase 3: Eradication
```
1. Remove malware/backdoors
2. Close attack vectors
3. Reset all affected systems
4. Update semua credentials
5. Patch semua sistem
```

### Fase 4: Recovery
```
1. Restore dari backup terverifikasi
2. Validasi integritas sistem
3. Enhanced monitoring
4. User training
5. Document lessons learned
```

### Fase 5: Post-Incident
```
1. Buat Laporan Insiden
2. Root Cause Analysis (RCA)
3. Recommendations
4. Update procedures
5. Share IOC dengan komunitas
```

## Template Laporan Insiden

```
LAPORAN INSIDEN KEAMANAN SIBER
================================

Nomor Laporan    : INS-{YYYYMMDD}-{001}
Tanggal Laporan  : {Tanggal}
Tanggal Kejadian : {Tanggal}
Severity         : [CRITICAL/HIGH/MEDIUM/LOW]

A. INFORMASI UMUM
   Pelapor         : {Nama}
   Unit Kerja      : {Unit}
   Kontak          : {Email/Telp}

B. KRONOLOGI
   {Detail kronologis kejadian}

C. SISTEM TERDAMPAK
   - Hostname/IP   : 
   - OS            : 
   - Services      : 
   - Data impacted : 

D. INDIKATOR COMPROMISE
   - IP attacker   : 
   - Domains       : 
   - Hash malware  : 
   - TTPs          : 

E. TINDAKAN YANG SUDAH DILAKUKAN
   - Containment   : 
   - Eradication   : 
   - Recovery      : 

F. DUGAAN DAMPAK
   - Confidentiality : 
   - Integrity       : 
   - Availability    : 

G. REKOMENDASI
   1. 
   2. 
   3. 

H. LAMPIRAN
   - Screenshots/logs
   - Network traffic analysis
   - Forensic evidence

Ditangani oleh,
{Nama Tim CSIRT}
{Tanggal}

================================
STATUS: [OPEN/IN_PROGRESS/RESOLVED/CLOSED]
```

## Metrics Keamanan Siber

### KPIs untuk PELAPORAN
```
1. Mean Time to Detect (MTTD)        : Target < 24 jam
2. Mean Time to Respond (MTTR)       : Target < 4 jam (critical)
3. Mean Time to Recover (MTTRec)     : Target < 8 jam
4. Number of incidents               : Baseline bulanan
5. Patch compliance rate             : Target > 95%
6. Vulnerability scan coverage       : Target 100%
7. Security training completion      : Target 100%
8. Phishing simulation pass rate     : Target > 90%
```

## Tools untuk Hackintosh Security

```bash
# macOS-specific security tools
brew install --cask little-snitch  # Network monitor/firewall
brew install macos-firmware-verifier
brew install santa  # Googles macOS security tool

# FileVault encryption check
fdesetup status

# Gatekeeper verification
spctl --status

# SIP status check
csrutil status

# Built-in disk encryption
diskutil apfs list
```