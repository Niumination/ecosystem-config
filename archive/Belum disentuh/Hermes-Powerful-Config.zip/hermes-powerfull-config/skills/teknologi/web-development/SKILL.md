# SKILL: Pengembangan Web Fullstack Powerfull

## Deskripsi
Skill komprehensif untuk pengembangan web fullstack modern mencakup frontend, backend, database, DevOps, keamanan, dan optimasi performa. Spesifik untuk kebutuhan pemerintahan dan bisnis Indonesia.

## DAFTAR ISI
1. [Arsitektur & Stack Teknologi](#1-arsitektur--stack-teknologi)
2. [Project Templates Lengkap](#2-project-templates-lengkap)
3. [Frontend Development](#3-frontend-development)
4. [Backend Development](#4-backend-development)
5. [Database Management](#5-database-management)
6. [API Design & Integration](#6-api-design--integration)
7. [Government-Specific Apps](#7-government-specific-apps)
8. [DevOps & Deployment](#8-devops--deployment)
9. [Security Best Practices](#9-security-best-practices)
10. [Performance Optimization](#10-performance-optimization)
11. [Testing & Quality Assurance](#11-testing--quality-assurance)
12. [Real Project Examples](#12-real-project-examples)

---

# 1. ARSITEKTUR & STACK TEKNOLOGI

## Stack Rekomendasi (All Free/Open Source)

### Frontend Stack
```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND OPTIONS                          │
├─────────────────┬─────────────────┬─────────────────────────┤
│  NEXT.JS 14+    │    NUXT 3       │    SVELTEKIT           │
│  React-based    │  Vue-based      │  Svelte-based           │
│  Best for:      │  Best for:      │  Best for:              │
│  - Dashboard    │  - Content      │  - Fast apps            │
│  - E-commerce   │  - Blog/CMS     │  - Static sites         │
│  - SaaS         │  - Landing      │  - Lightweight          │
├─────────────────┴─────────────────┴─────────────────────────┤
│                    UI COMPONENT LIBRARIES                    │
├─────────────────┬─────────────────┬─────────────────────────┤
│  shadcn/ui      │  HeadlessUI     │  Radix UI               │
│  Tailwind-based │  Tailwind only  │  Unstyled components    │
│  Production OK  │  Vue support    │  React only             │
├─────────────────┴─────────────────┴─────────────────────────┤
│                    STYLING                                   │
├─────────────────┬─────────────────┬─────────────────────────┤
│  Tailwind CSS   │  UnoCSS         │  CSS Modules            │
│  3.4+           │  On-demand      │  Scoped styles          │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### Backend Stack
```
┌─────────────────────────────────────────────────────────────┐
│                    BACKEND OPTIONS                           │
├─────────────────┬─────────────────┬─────────────────────────┤
│  NODE.JS        │    PYTHON       │    GO                  │
│  - Next.js API  │  - FastAPI      │  - Fiber               │
│  - Express      │  - Django       │  - Gin                 │
│  - NestJS       │  - Flask        │  - Echo                │
│  Best for:      │  Best for:      │  Best for:             │
│  JS/TS devs     │  AI/ML, Data    │  High performance      │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### Database Stack
```
┌─────────────────────────────────────────────────────────────┐
│                    DATABASE OPTIONS                          │
├─────────────────┬─────────────────┬─────────────────────────┤
│  PostgreSQL     │    MySQL        │    MongoDB             │
│  Best for:      │  Best for:      │  Best for:             │
│  - Relational   │  - Legacy apps  │  - Flexible schema     │
│  - Complex      │  - Shared       │  - Rapid prototyping   │
│    queries      │    hosting      │  - Document store      │
├─────────────────┴─────────────────┴─────────────────────────┤
│                    FREE HOSTING TIERS                        │
├─────────────────┬─────────────────┬─────────────────────────┤
│  Supabase       │  Neon           │  PlanetScale           │
│  500MB DB       │  3GB DB         │  1 DB, 5GB storage     │
│  1GB storage    │  Branches       │  Serverless            │
├─────────────────┴─────────────────┴─────────────────────────┤
│                    CACHE & QUEUE                             │
├─────────────────┬─────────────────┬─────────────────────────┤
│  Redis          │  Upstash Redis  │  BullMQ                │
│  Self-hosted    │  Serverless     │  Job queue             │
│  Free tier OK   │  Free tier OK   │  Free tier OK          │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### Deployment Stack (All Free)
```
┌─────────────────────────────────────────────────────────────┐
│                    DEPLOYMENT OPTIONS                        │
├─────────────────┬─────────────────┬─────────────────────────┤
│  VERCEL         │  NETLIFY        │  RAILWAY              │
│  - Next.js opt  │  - Static       │  - Any app             │
│  - Edge network │  - Functions    │  - $5 free/month       │
│  - Free tier    │  - Free tier    │  - Pay as go          │
├─────────────────┼─────────────────┼─────────────────────────┤
│  FLY.IO         │  CLOUDFLARE     │  SELF-HOSTED          │
│  - Docker       │  - Pages        │  - Docker/VPS          │
│  - Global       │  - Workers      │  - DigitalOcean        │
│  - Free tier    │  - D1 DB        │  - $4-6/month          │
└─────────────────┴─────────────────┴─────────────────────────┘
```

---

# 2. PROJECT TEMPLATES LENGKAP

## Template 1: Next.js 14 App Router + TypeScript + Tailwind

```bash
# Create project
npx create-next-app@latest my-app \
  --typescript \
  --tailwind \
  --eslint \
  --app \
  --src-dir \
  --import-alias "@/*" \
  --no-turbopack

cd my-app

# Install core dependencies
npm install \
  @supabase/supabase-js \
  @supabase/ssr \
  lucide-react \
  clsx \
  tailwind-merge \
  class-variance-authority \
  zod \
  react-hook-form \
  @hookform/resolvers \
  date-fns \
  recharts \
  next-themes

# Install UI helper (shadcn-style)
npm install -D tailwindcss-animate

# Start development
npm run dev
```

### Project Structure
```
src/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   └── layout.tsx
│   ├── (dashboard)/
│   │   ├── dashboard/page.tsx
│   │   ├── users/page.tsx
│   │   ├── reports/page.tsx
│   │   └── layout.tsx
│   ├── api/
│   │   ├── auth/[...nextauth]/route.ts
│   │   ├── users/route.ts
│   │   └── upload/route.ts
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── ui/
│   │   ├── button.tsx
│   │   ├── input.tsx
│   │   ├── card.tsx
│   │   ├── dialog.tsx
│   │   ├── table.tsx
│   │   ├── dropdown-menu.tsx
│   │   └── tabs.tsx
│   ├── layout/
│   │   ├── header.tsx
│   │   ├── sidebar.tsx
│   │   ├── footer.tsx
│   │   └── navbar.tsx
│   ├── forms/
│   │   ├── user-form.tsx
│   │   ├── login-form.tsx
│   │   └── filter-form.tsx
│   └── charts/
│       ├── line-chart.tsx
│       ├── bar-chart.tsx
│       └── pie-chart.tsx
├── lib/
│   ├── supabase/
│   │   ├── client.ts
│   │   ├── server.ts
│   │   └── middleware.ts
│   ├── utils/
│   │   ├── cn.ts
│   │   ├── format.ts
│   │   └── validators.ts
│   ├── constants.ts
│   └── types.ts
├── hooks/
│   ├── use-auth.ts
│   ├── use-debounce.ts
│   └── use-local-storage.ts
└── actions/
    ├── auth-actions.ts
    ├── user-actions.ts
    └── report-actions.ts
```

## Template 2: Next.js Dashboard dengan Shadcn/ui

```bash
# Initialize shadcn/ui
npx shadcn@latest init

# Add components
npx shadcn@latest add button input card dialog table dropdown-menu tabs 
npx shadcn@latest add avatar badge calendar form label select toast

# Add charts
npx shadcn@latest add chart

# Install additional
npm install date-fns react-day-picker
```

### Shadcn/ui Component Setup

```typescript
// lib/utils.ts
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// components/ui/button.tsx
import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
```

## Template 3: Government Portal Next.js

```bash
# Create project
npx create-next-app@latest government-portal \
  --typescript --tailwind --eslint --app --src-dir

cd government-portal

# Install dependencies
npm install @supabase/supabase-js lucide-react date-fns zod react-hook-form
npm install @radix-ui/react-slot @radix-ui/react-dialog @radix-ui/react-dropdown-menu
npm install recharts framer-motion

# Add shadcn components
npx shadcn@latest add button input card table badge avatar
```

---

# 3. FRONTEND DEVELOPMENT

## 3.1 Komponen UI Government-Specific

### Header & Navigation
```tsx
// components/layout/header.tsx
"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Menu, User, LogOut, Settings } from "lucide-react"

const navigation = [
  { name: "Beranda", href: "/" },
  { name: "Layanan", href: "/layanan" },
  { name: "Data", href: "/data" },
  { name: "Desa", href: "/desa" },
  { name: "Tentang", href: "/tentang" },
]

export function Header() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">G</span>
            </div>
            <span className="font-bold text-lg hidden md:inline">Diskominfo Aceh Tengah</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  pathname === item.href
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-4 ml-auto">
          <Button variant="outline" size="sm">
            <User className="mr-2 h-4 w-4" />
            Masuk
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {navigation.map((item) => (
                <DropdownMenuItem key={item.name} asChild>
                  <Link href={item.href}>{item.name}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
```

### Hero Section Government
```tsx
// components/sections/hero.tsx
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, FileText, Clock, Shield, Star } from "lucide-react"

const stats = [
  { label: "Total Layanan", value: "156", icon: FileText },
  { label: "Waktu Respon", value: "< 5 menit", icon: Clock },
  { label: "Keamanan", value: "A+", icon: Shield },
  { label: "Rating", value: "4.9/5", icon: Star },
]

const popularServices = [
  { title: "Pencatatan Sipil", desc: "Kelahiran, Kematian, Perpindahan", icon: "📋" },
  { title: "Izin Usaha", desc: "NIB, TDP, SIUP", icon: "📄" },
  { title: "Pajak Daerah", desc: "PBB, Pajak Hiburan", icon: "💰" },
  { title: "Informasi Publik", desc: "Permintaan data & dokumen", icon: "🔍" },
]

export function Hero() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5" />
      
      <div className="container relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center rounded-full px-4 py-1.5 text-sm bg-primary/10 text-primary">
              🌐 Sistem Pemerintahan Berbasis Elektronik
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
              Layanan Publik
              <span className="text-primary"> Cepat & Transparan</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-lg">
              Akses layanan pemerintahan Kabupaten Aceh Tengah 
              kapan saja, di mana saja. Mudah, cepat, dan gratis.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Button size="lg" asChild>
                <Link href="/layanan">
                  Lihat Layanan
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline">
                Panduan Penggunaan
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat) => (
              <Card key={stat.label} className="p-6">
                <CardContent className="p-0">
                  <stat.icon className="h-10 w-10 text-primary mb-4" />
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Popular Services */}
        <div className="mt-20">
          <h2 className="text-2xl font-bold mb-8">Layanan Populer</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularServices.map((service) => (
              <Card key={service.title} className="group cursor-pointer hover:border-primary transition-colors">
                <CardContent className="p-6">
                  <div className="text-4xl mb-4">{service.icon}</div>
                  <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{service.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
```

## 3.2 Data Table dengan Fitur Lengkap

```tsx
// components/data-table.tsx
"use client"

import * as React from "react"
import { ColumnDef, flexRender, getCoreRowModel, useReactTable, getPaginationRowModel, getSortedRowModel, getFilteredRowModel, SortingState, ColumnFiltersState } from "@tanstack/react-table"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown, MoreHorizontal, ChevronLeft, ChevronRight, ArrowUpDown } from "lucide-react"

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[]
  data: TData[]
}

export function DataTable<TData, TValue>({ columns, data }: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    state: { sorting, columnFilters },
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Input
          placeholder="Filter..."
          value={(table.getColumn("name")?.getFilterValue() as string) ?? ""}
          onChange={(event) =>
            table.getColumn("name")?.setFilterValue(event.target.value)
          }
          className="max-w-sm"
        />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              Filter <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Semua</DropdownMenuItem>
            <DropdownMenuItem>Aktif</DropdownMenuItem>
            <DropdownMenuItem>Nonaktif</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <TableHead key={header.id}>
                    {header.isPlaceholder
                      ? null
                      : flexRender(header.column.columnDef.header, header.getContext())}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {table.getRowModel().rows.length} of {data.length} results
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// Usage example columns
export const columns: ColumnDef<Permohonan>[] = [
  {
    accessorKey: "nomor",
    header: ({ column }) => (
      <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
        Nomor
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
  },
  {
    accessorKey: "nama",
    header: "Nama Pemohon",
  },
  {
    accessorKey: "layanan",
    header: "Layanan",
    cell: ({ row }) => <Badge>{row.original.layanan}</Badge>,
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status
      return <Badge variant={status === "completed" ? "default" : "secondary"}>{status}</Badge>
    },
  },
  {
    id: "actions",
    cell: ({ row }) => (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-8 w-8 p-0">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem>Lihat Detail</DropdownMenuItem>
          <DropdownMenuItem>Edit</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-red-600">Hapus</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    ),
  },
]
```

## 3.3 Form dengan React Hook Form + Zod

```tsx
// components/forms/permohonan-form.tsx
"use client"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Schema validasi
const formSchema = z.object({
  nik: z.string().length(16, "NIK harus 16 digit"),
  nama_lengkap: z.string().min(3, "Nama minimal 3 karakter"),
  email: z.string().email("Email tidak valid"),
  no_telp: z.string().min(10, "Nomor telepon minimal 10 digit"),
  layanan_id: z.string().min(1, "Pilih layanan"),
  alamat: z.string().min(10, "Alamat minimal 10 karakter"),
  deskripsi: z.string().min(20, "Deskripsi minimal 20 karakter"),
  dokumen_pendukung: z.array(z.string()).optional(),
})

type FormValues = z.infer<typeof formSchema>

export function PermohonanForm() {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nik: "",
      nama_lengkap: "",
      email: "",
      no_telp: "",
      layanan_id: "",
      alamat: "",
      deskripsi: "",
    },
  })

  function onSubmit(data: FormValues) {
    console.log(data)
    // Submit to API
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Data Pemohon</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="nik"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>NIK</FormLabel>
                    <FormControl>
                      <Input placeholder="16 digit NIK" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="nama_lengkap"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Lengkap</FormLabel>
                    <FormControl>
                      <Input placeholder="Nama sesuai KTP" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="email@contoh.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="no_telp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nomor Telepon</FormLabel>
                    <FormControl>
                      <Input placeholder="08xxxxxxxxxx" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Detail Permohonan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="layanan_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Jenis Layanan</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih layanan" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="akta-kelahiran">Akta Kelahiran</SelectItem>
                      <SelectItem value="akta-kematian">Akta Kematian</SelectItem>
                      <SelectItem value="kk">Kartu Keluarga</SelectItem>
                      <SelectItem value="ktp">KTP Elektronik</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="deskripsi"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deskripsi Permohonan</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Jelaskan keperluan permohonan Anda..." {...field} />
                  </FormControl>
                  <FormDescription>
                    Minimal 20 karakter
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <div className="flex gap-4">
          <Button type="submit">Kirim Permohonan</Button>
          <Button type="button" variant="outline">Batal</Button>
        </div>
      </form>
    </Form>
  )
}
```

---

# 4. BACKEND DEVELOPMENT

## 4.1 Next.js App Router API Routes

### API Route dengan Supabase
```typescript
// app/api/permohonan/route.ts
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { z } from "zod"

// Schema untuk validasi
const createSchema = z.object({
  nik: z.string().length(16),
  nama_lengkap: z.string().min(3),
  email: z.string().email(),
  no_telp: z.string().min(10),
  layanan_id: z.string().uuid(),
  deskripsi: z.string().min(20),
})

// GET - List semua permohonan
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const page = parseInt(searchParams.get("page") || "1")
  const limit = parseInt(searchParams.get("limit") || "10")
  const status = searchParams.get("status")

  const supabase = createClient()
  
  let query = supabase
    .from("permohonan")
    .select("*, layanan(nama)", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * limit, page * limit - 1)

  if (status) {
    query = query.eq("status", status)
  }

  const { data, error, count } = await query

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({
    data,
    pagination: {
      page,
      limit,
      total: count,
      totalPages: Math.ceil((count || 0) / limit),
    },
  })
}

// POST - Create permohonan baru
export async function POST(request: Request) {
  try {
    const body = await request.json()
    
    // Validasi input
    const validatedData = createSchema.parse(body)
    
    const supabase = createClient()
    
    // Generate nomor registrasi
    const date = new Date()
    const nomor = `PRL/${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, "0")}/${Math.random().toString(36).substr(2, 6).toUpperCase()}`

    // Insert ke database
    const { data, error } = await supabase
      .from("permohonan")
      .insert({
        nomor_registrasi: nomor,
        ...validatedData,
        status: "submitted",
        submitted_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json({ data }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
```

### API Route dengan Auth (Server Actions)
```typescript
// app/actions/auth-actions.ts
"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"

export async function login(formData: FormData) {
  const supabase = createClient()
  
  const data = {
    email: formData.get("email") as string,
    password: formData.get("password") as string,
  }

  const { error } = await supabase.auth.signInWithPassword(data)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/", "layout")
  redirect("/dashboard")
}

export async function register(formData: FormData) {
  const supabase = createClient()
  
  const data = {
    email: formData.get("email") as string,
    password: formData.get("password") as string,
    options: {
      data: {
        nama_lengkap: formData.get("nama_lengkap") as string,
        nik: formData.get("nik") as string,
      },
    },
  }

  const { error } = await supabase.auth.signUp(data)

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/", "layout")
  redirect("/login")
}

export async function logout() {
  const supabase = createClient()
  await supabase.auth.signOut()
  revalidatePath("/", "layout")
  redirect("/login")
}
```

## 4.2 Express.js Backend (Alternative)

```bash
# Initialize project
mkdir backend-api && cd backend-api
npm init -y
npm install express cors helmet morgan dotenv zod pg bcryptjs jsonwebtoken
npm install -D typescript @types/node @types/express @types/cors @types/pg ts-node nodemon
npx tsc --init
```

```typescript
// src/index.ts
import express from "express"
import cors from "cors"
import helmet from "helmet"
import morgan from "morgan"
import { config } from "dotenv"
import { authRouter } from "./routes/auth"
import { permohonanRouter } from "./routes/permohonan"
import { laporanRouter } from "./routes/laporan"
import { errorHandler } from "./middleware/error"
import { rateLimiter } from "./middleware/rateLimit"

config()

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(helmet())
app.use(cors({ origin: process.env.CORS_ORIGIN }))
app.use(morgan("combined"))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Rate limiting
app.use(rateLimiter)

// Routes
app.use("/api/auth", authRouter)
app.use("/api/permohonan", permohonanRouter)
app.use("/api/laporan", laporanRouter)

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() })
})

// Error handler
app.use(errorHandler)

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
```

```typescript
// src/routes/permohonan.ts
import { Router } from "express"
import { Pool } from "pg"
import { z } from "zod"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { authenticate } from "../middleware/auth"

const router = Router()
const pool = new Pool({ connectionString: process.env.DATABASE_URL })

// Validasi schema
const createPermohonanSchema = z.object({
  nik: z.string().length(16),
  nama_lengkap: z.string().min(3),
  email: z.string().email(),
  layanan_id: z.string().uuid(),
  deskripsi: z.string().min(20),
})

// GET /api/permohonan
router.get("/", authenticate, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query
    
    const offset = (Number(page) - 1) * Number(limit)
    
    let query = "SELECT * FROM permohonan"
    let countQuery = "SELECT COUNT(*) FROM permohonan"
    const params: any[] = []
    
    if (status) {
      query += " WHERE status = $1"
      countQuery += " WHERE status = $1"
      params.push(status)
    }
    
    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)
    
    const [data, count] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, status ? [status] : [])
    ])
    
    res.json({
      data: data.rows,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total: Number(count.rows[0].count),
      },
    })
  } catch (error) {
    res.status(500).json({ error: "Internal server error" })
  }
})

// POST /api/permohonan
router.post("/", async (req, res) => {
  try {
    const validatedData = createPermohonanSchema.parse(req.body)
    
    // Generate nomor registrasi
    const nomor = `PRL/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, "0")}/${Math.random().toString(36).substr(2, 6).toUpperCase()}`
    
    const result = await pool.query(
      `INSERT INTO permohonan (nomor_registrasi, nik, nama_lengkap, email, layanan_id, deskripsi, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'submitted')
       RETURNING *`,
      [nomor, validatedData.nik, validatedData.nama_lengkap, validatedData.email, validatedData.layanan_id, validatedData.deskripsi]
    )
    
    res.status(201).json({ data: result.rows[0] })
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ error: error.errors })
    } else {
      res.status(500).json({ error: "Internal server error" })
    }
  }
})

export { router as permohonanRouter }
```

---

# 5. DATABASE MANAGEMENT

## 5.1 Supabase Schema untuk Government Portal

```sql
-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users & Authentication (extends Supabase auth.users)
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    nik VARCHAR(16) UNIQUE,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    no_telp VARCHAR(15),
    alamat TEXT,
    unit_kerja_id UUID REFERENCES public.unit_kerja(id),
    role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('admin', 'operator', 'viewer', 'supervisor')),
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.unit_kerja (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    kode VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    singkatan VARCHAR(20),
    parent_id UUID REFERENCES public.unit_kerja(id),
    eselon INT CHECK (eselon BETWEEN 1 AND 4),
    telepon VARCHAR(20),
    email VARCHAR(255),
    alamat TEXT,
    aktif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Master Data: Layanan
CREATE TABLE public.layanan (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    kode_layanan VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(200) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    deskripsi TEXT,
    kategori VARCHAR(50),
    skla_id VARCHAR(50), -- referensi ke SKLA nasional
    target_hari INT DEFAULT 14,
    biaya DECIMAL(12,2) DEFAULT 0,
    Persyaratan JSONB DEFAULT '[]',
    required_documents JSONB DEFAULT '[]',
    workflow JSONB DEFAULT '[]', -- steps dalam workflow
    ikon VARCHAR(50),
    aktif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Permohonan Layanan
CREATE TABLE public.permohonan (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nomor_registrasi VARCHAR(30) UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id),
    layanan_id UUID REFERENCES public.layanan(id) NOT NULL,
    
    -- Data pemohon
    nik VARCHAR(16),
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    no_telp VARCHAR(15),
    alamat TEXT,
    
    -- Detail permohonan
    deskripsi TEXT,
    data_masukan JSONB DEFAULT '{}', -- data tambahan sesuai layanan
    
    -- Workflow
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN (
        'draft', 'submitted', 'verification', 'review', 
        'approved', 'rejected', 'revision', 'completed', 'cancelled'
    )),
    status_history JSONB DEFAULT '[]',
    current_step INT DEFAULT 0,
    
    -- Assignment
    assigned_to UUID REFERENCES public.profiles(id),
    assigned_at TIMESTAMP WITH TIME ZONE,
    
    -- Timestamps
    submitted_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    expired_at TIMESTAMP WITH TIME ZONE,
    
    -- Notes
    notes TEXT,
    internal_notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Dokumen Pendukung
CREATE TABLE public.dokumen (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permohonan_id UUID REFERENCES public.permohonan(id) ON DELETE CASCADE,
    jenis_dokumen VARCHAR(50) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255),
    file_path TEXT NOT NULL,
    file_size BIGINT,
    mime_type VARCHAR(100),
    storage_bucket VARCHAR(50) DEFAULT 'documents',
    uploaded_by UUID REFERENCES auth.users(id),
    verified BOOLEAN DEFAULT FALSE,
    verified_by UUID REFERENCES public.profiles(id),
    verified_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Surat / Dokumen Output
CREATE TABLE public.surat (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permohonan_id UUID REFERENCES public.permohonan(id),
    nomor_surat VARCHAR(50) UNIQUE NOT NULL,
    jenis_surat VARCHAR(30),
    tanggal DATE NOT NULL,
    tahun INT,
   .perihal TEXT,
    tembusan JSONB DEFAULT '[]',
    softfile_path TEXT,
    created_by UUID REFERENCES public.profiles(id),
    signed_by UUID REFERENCES public.profiles(id),
    signed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Laporan & Evaluasi
CREATE TABLE public.laporan (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    jenis VARCHAR(30) CHECK (jenis IN ('harian', 'mingguan', 'bulanan', 'triwulan', 'tahunan', 'lkip')),
    periode VARCHAR(20) NOT NULL,
    periode_start DATE,
    periode_end DATE,
    judul VARCHAR(200),
    ringkasan TEXT,
    konten JSONB,
    lampiran JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'draft',
    created_by UUID REFERENCES public.profiles(id),
    approved_by UUID REFERENCES public.profiles(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- PEMDI Indicators Tracking
CREATE TABLE public.pemdi_aspek (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nomor INT NOT NULL,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    bobot DECIMAL(4,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.pemdi_indikator (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    aspek_id UUID REFERENCES public.pemdi_aspek(id),
    nomor INT NOT NULL,
    nama VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    bobot DECIMAL(4,2),
    target_nilai DECIMAL(3,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE public.pemdi_evaluasi (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    indikator_id UUID REFERENCES public.pemdi_indikator(id),
    periode VARCHAR(20) NOT NULL,
    tahun INT NOT NULL,
    triwulan INT CHECK (triwulan BETWEEN 1 AND 4),
    nilai DECIMAL(3,2),
    skor DECIMAL(4,2),
    self_assessment BOOLEAN DEFAULT FALSE,
    bukti_pendukung JSONB DEFAULT '[]',
    evaluator_id UUID REFERENCES public.profiles(id),
    reviewer_id UUID REFERENCES public.profiles(id),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(indikator_id, periode, triwulan)
);

-- Notifications
CREATE TABLE public.notifikasi (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    judul VARCHAR(200) NOT NULL,
    pesan TEXT NOT NULL,
    jenis VARCHAR(30) CHECK (jenis IN ('info', 'success', 'warning', 'error')),
    is_read BOOLEAN DEFAULT FALSE,
    action_url VARCHAR(500),
    related_id UUID, -- bisa riferensi ke permohonan, laporan, dll
    related_type VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Activity Log
CREATE TABLE public.activity_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id),
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes untuk performa
CREATE INDEX idx_permohonan_status ON public.permohonan(status);
CREATE INDEX idx_permohonan_user ON public.permohonan(user_id);
CREATE INDEX idx_permohonan_layanan ON public.permohonan(layanan_id);
CREATE INDEX idx_permohonan_created ON public.permohonan(created_at DESC);
CREATE INDEX idx_permohonan_assigned ON public.permohonan(assigned_to) WHERE assigned_to IS NOT NULL;

CREATE INDEX idx_dokumen_permohonan ON public.dokumen(permohonan_id);
CREATE INDEX idx_notifikasi_user_unread ON public.notifikasi(user_id, is_read) WHERE is_read = FALSE;
CREATE INDEX idx_activity_user ON public.activity_log(user_id);
CREATE INDEX idx_activity_created ON public.activity_log(created_at DESC);

-- Full text search
CREATE INDEX idx_permohonan_search ON public.permohonan USING GIN (to_tsvector('indonesian', nomor_registrasi || ' ' || COALESCE(nama_lengkap, '') || ' ' || COALESCE(deskripsi, '')));

-- Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permohonan ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dokumen ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifikasi ENABLE ROW LEVEL SECURITY;

-- Policies untuk profiles
CREATE POLICY "Users can view all profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can insert profiles" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can delete profiles" ON public.profiles FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Policies untuk permohonan
CREATE POLICY "Anyone can create permohonan" ON public.permohonan FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can view own permohonan" ON public.permohonan FOR SELECT USING (
    auth.uid() = user_id OR
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'operator', 'supervisor'))
);
CREATE POLICY "Operators can update permohonan" ON public.permohonan FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('admin', 'operator', 'supervisor'))
);

-- Policies untuk notifikasi
CREATE POLICY "Users can view own notifications" ON public.notifikasi FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own notifications" ON public.notifikasi FOR UPDATE USING (auth.uid() = user_id);

-- Trigger untuk auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_permohonan_updated_at BEFORE UPDATE ON public.permohonan
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_laporan_updated_at BEFORE UPDATE ON public.laporan
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger untuk generate nomor surat
CREATE OR REPLACE FUNCTION generate_nomor_surat()
RETURNS TRIGGER AS $$
BEGIN
    NEW.tahun = EXTRACT(YEAR FROM NEW.tanggal);
    NEW.nomor_surat = NEW.nomor_surat || '/KP/' || NEW.tahun;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Initial data: Unit Kerja
INSERT INTO public.unit_kerja (kode, nama, singkatan, eselon) VALUES
('SETDA', 'Sekretariat Daerah', 'SETDA', 2),
('DISKOMINFO', 'Dinas Komunikasi dan Informatika', 'DISKOMINFO', 2),
('DPMD', 'Dinas Pemberdayaan Masyarakat dan Desa', 'DPMD', 2),
('DISDUKCAPIL', 'Dinas Kependudukan dan Pencatatan Sipil', 'DISDUKCAPIL', 2);

-- Initial data: PEMDI Aspects & Indicators
INSERT INTO public.pemdi_aspek (nomor, nama, bobot) VALUES
(1, 'Tata Kelola SPBE', 10),
(2, 'Penyelenggara SPBE', 12),
(3, 'Data dan Informasi', 20),
(4, 'Keamanan Siber', 20),
(5, 'Teknologi', 10),
(6, 'Keterpaduan Layanan', 20),
(7, 'Kepuasan Pengguna', 8);
```

## 5.2 Query Templates untuk Reporting

```typescript
// lib/queries/laporan.ts

// Statistik Bulanan Permohonan
export const STATS_BULANAN = `
SELECT 
    TO_CHAR(DATE_TRUNC('month', created_at), 'YYYY-MM') as bulan,
    COUNT(*) as total,
    COUNT(*) FILTER (WHERE status = 'submitted') as baru,
    COUNT(*) FILTER (WHERE status = 'verification') as verifikasi,
    COUNT(*) FILTER (WHERE status = 'review') as review,
    COUNT(*) FILTER (WHERE status = 'completed') as selesai,
    COUNT(*) FILTER (WHERE status = 'rejected') as ditolak,
    ROUND(
        COUNT(*) FILTER (WHERE status = 'completed')::NUMERIC / 
        NULLIF(COUNT(*), 0) * 100, 2
    ) as presentase_selesai,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (completed_at - submitted_at)) / 86400) FILTER (WHERE status = 'completed'),
        1
    ) as avg_hari_selesai
FROM permohonan
WHERE created_at >= $1 AND created_at <= $2
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY bulan;
`

// Statistik per Layanan
export const STATS_PER_LAYANAN = `
SELECT 
    l.nama as layanan,
    l.kategori,
    COUNT(p.id) as total_permohonan,
    COUNT(p.id) FILTER (WHERE p.status = 'completed') as selesai,
    ROUND(
        COUNT(p.id) FILTER (WHERE p.status = 'completed')::NUMERIC / 
        NULLIF(COUNT(p.id), 0) * 100, 2
    ) as presentase_selesai,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (p.completed_at - p.submitted_at)) / 86400) FILTER (WHERE p.status = 'completed'),
        1
    ) as avg_hari
FROM layanan l
LEFT JOIN permohonan p ON l.id = p.layanan_id
    AND p.created_at >= $1 AND p.created_at <= $2
GROUP BY l.id, l.nama, l.kategori
ORDER BY total_permohonan DESC;
`

// Capaian Kinerja Operator
export const CAPAIAN_OPERATOR = `
SELECT 
    pr.nama_lengkap,
    uk.nama as unit_kerja,
    COUNT(p.id) as total_tugas,
    COUNT(p.id) FILTER (WHERE p.status = 'completed') as selesai,
    COUNT(p.id) FILTER (WHERE p.status IN ('submitted', 'verification', 'review')) as sedang_dikerjakan,
    COUNT(p.id) FILTER (WHERE p.status = 'completed' AND p.completed_at <= p.submitted_at + (l.target_hari || ' days')::INTERVAL) as selesai_tepat_waktu,
    ROUND(
        COUNT(p.id) FILTER (WHERE p.status = 'completed' AND p.completed_at <= p.submitted_at + (l.target_hari || ' days')::INTERVAL)::NUMERIC /
        NULLIF(COUNT(p.id) FILTER (WHERE p.status = 'completed'), 0) * 100, 2
    ) as presentase_tepat_waktu
FROM profiles pr
JOIN unit_kerja uk ON pr.unit_kerja_id = uk.id
LEFT JOIN permohonan p ON p.assigned_to = pr.id
LEFT JOIN layanan l ON p.layanan_id = l.id
WHERE p.created_at >= $1 AND p.created_at <= $2
GROUP BY pr.id, pr.nama_lengkap, uk.nama
ORDER BY selesai DESC;
`

// PEMDI Progress
export const PEMDI_PROGRESS = `
SELECT 
    pa.nama as aspek,
    COUNT(pi.id) as total_indikator,
    COUNT(pe.id) as indikator_diisi,
    ROUND(
        AVG(pe.skor) FILTER (WHERE pe.periode = $1),
        2
    ) as avg_skor
FROM pemdi_aspek pa
LEFT JOIN pemdi_indikator pi ON pa.id = pi.aspek_id
LEFT JOIN pemdi_evaluasi pe ON pi.id = pe.indikator_id AND pe.periode = $1
GROUP BY pa.id, pa.nama
ORDER BY pa.nomor;
`

// Dashboard Summary
export const DASHBOARD_SUMMARY = `
SELECT 
    (SELECT COUNT(*) FROM permohonan WHERE DATE(created_at) = CURRENT_DATE) as permohonan_hari_ini,
    (SELECT COUNT(*) FROM permohonan WHERE status = 'submitted') as menunggu_verifikasi,
    (SELECT COUNT(*) FROM permohonan WHERE status = 'review') as menunggu_review,
    (SELECT COUNT(*) FROM permohonan WHERE status = 'completed' AND DATE(completed_at) = CURRENT_DATE) as selesai_hari_ini,
    (SELECT COUNT(*) FROM notifikasi WHERE user_id = $1 AND is_read = false) as notifikasi_belum_dibaca;
`
```

---

# 6. API DESIGN & INTEGRATION

## 6.1 REST API Design Patterns

```typescript
// API Response Standard
interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
    details?: any
  }
  meta?: {
    page?: number
    limit?: number
    total?: number
    totalPages?: number
  }
}

// Success response helper
export function successResponse<T>(data: T, meta?: ApiResponse<T>['meta']): ApiResponse<T> {
  return { success: true, data, meta }
}

// Error response helper
export function errorResponse(code: string, message: string, details?: any): ApiResponse<never> {
  return { success: false, error: { code, message, details } }
}

// Usage in route handlers
export async function GET(request: Request) {
  try {
    const data = await fetchData()
    return NextResponse.json(successResponse(data, { total: 100 }))
  } catch (error) {
    return NextResponse.json(
      errorResponse('FETCH_ERROR', 'Gagal mengambil data'),
      { status: 500 }
    )
  }
}
```

## 6.2 Integration dengan Sistem Nasional

### Integrasi SKLA (Sistem Katalog Layanan Aceh)
```typescript
// lib/integrations/skla.ts

interface SKLAService {
  id: string
  name: string
  category: string
  requirements: string[]
  estimatedDays: number
}

export async function fetchSKLAServices(): Promise<SKLAService[]> {
  const response = await fetch(process.env.SKLA_API_URL + '/services', {
    headers: {
      'Authorization': `Bearer ${process.env.SKLA_API_KEY}`,
      'Content-Type': 'application/json',
    },
    next: { revalidate: 3600 } // Cache 1 hour
  })
  
  if (!response.ok) throw new Error('Failed to fetch SKLA services')
  return response.json()
}

export async function syncServiceToSKLA(service: any): Promise<void> {
  await fetch(process.env.SKLA_API_URL + '/services', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.SKLA_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(service)
  })
}
```

### Integrasi SIAK (Sistem Informasi Administrasi Kependudukan)
```typescript
// lib/integrations/siak.ts

interface SIAKResponse {
  nik: string
  nama: string
  tempat_lahir: string
  tanggal_lahir: string
  jenis_kelamin: string
  alamat: {
    prov: string
    kab: string
    kec: string
    kel: string
  }
}

export async function verifyNIK(nik: string): Promise<SIAKResponse | null> {
  try {
    const response = await fetch(`${process.env.SIAK_API_URL}/verify-nik`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.SIAK_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ nik })
    })
    
    if (!response.ok) return null
    return response.json()
  } catch {
    return null
  }
}
```

## 6.3 Webhook Handler

```typescript
// app/api/webhooks/route.ts
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import crypto from "crypto"

export async function POST(request: Request) {
  const body = await request.text()
  const signature = request.headers.get("x-signature")
  
  // Verify webhook signature
  const expectedSignature = crypto
    .createHmac("sha256", process.env.WEBHOOK_SECRET!)
    .update(body)
    .digest("hex")
  
  if (signature !== expectedSignature) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
  }
  
  const payload = JSON.parse(body)
  const supabase = createClient()
  
  switch (payload.type) {
    case "permohonan.completed":
      await handlePermohonanCompleted(supabase, payload.data)
      break
    case "user.registered":
      await handleUserRegistered(supabase, payload.data)
      break
    case "payment.success":
      await handlePaymentSuccess(supabase, payload.data)
      break
  }
  
  return NextResponse.json({ received: true })
}

async function handlePermohonanCompleted(supabase: any, data: any) {
  // Create notification
  await supabase.from("notifikasi").insert({
    user_id: data.user_id,
    judul: "Permohonan Selesai",
    pesan: `Permohonan ${data.nomor} telah selesai diproses`,
    jenis: "success",
    related_id: data.id,
    related_type: "permohonan"
  })
  
  // Log activity
  await supabase.from("activity_log").insert({
    user_id: data.user_id,
    action: "permohonan_completed",
    entity_type: "permohonan",
    entity_id: data.id,
    details: { nomor: data.nomor }
  })
}
```

---

# 7. GOVERNMENT-SPECIFIC APPS

## 7.1 Portal Layanan Cepat (Layanan Express)

```typescript
// app/(public)/layanan/[slug]/page.tsx
import { notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, FileText, CheckCircle } from "lucide-react"

interface PageProps {
  params: { slug: string }
}

export default async function ServicePage({ params }: PageProps) {
  const supabase = createClient()
  
  const { data: layanan } = await supabase
    .from("layanan")
    .select("*")
    .eq("slug", params.slug)
    .single()
  
  if (!layanan) notFound()
  
  return (
    <div className="container py-10">
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Badge>{layanan.kategori}</Badge>
              <Badge variant="outline">{layanan.kode_layanan}</Badge>
            </div>
            <h1 className="text-4xl font-bold">{layanan.nama}</h1>
          </div>
          
          <div className="prose max-w-none">
            <p>{layanan.deskripsi}</p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Persyaratan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {(layanan.persyaratan || []).map((req: string, i: number) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informasi Layanan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Waktu Proses</p>
                  <p className="text-sm text-muted-foreground">{layanan.target_hari} Hari Kerja</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Biaya</p>
                  <p className="text-sm text-muted-foreground">
                    {layanan.biaya === 0 ? "Gratis" : `Rp ${layanan.biaya.toLocaleString("id-ID")}`}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Button className="w-full" size="lg" asChild>
            <a href={`/layanan/${params.slug}/pengajuan`}>
              Ajukan Permohonan
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
```

## 7.2 Dashboard Operator

```typescript
// app/(dashboard)/dashboard/page.tsx
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Link } from "next/link"
import { ArrowRight, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react"

export default async function DashboardPage() {
  const supabase = createClient()
  
  // Fetch stats
  const { data: stats } = await supabase.rpc("get_dashboard_stats")
  
  // Fetch recent permohonan
  const { data: recentPermohonan } = await supabase
    .from("permohonan")
    .select("*, layanan(nama)")
    .order("created_at", { ascending: false })
    .limit(10)
  
  return (
    <div className="container py-10 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard Operator</h1>
          <p className="text-muted-foreground">Selamat datang di Portal Diskominfo Aceh Tengah</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/permohonan/baru">
            <AlertCircle className="mr-2 h-4 w-4" />
            Permohonan Baru
          </Link>
        </Button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.menunggu_verifikasi || 0}</p>
                <p className="text-sm text-muted-foreground">Menunggu Verifikasi</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <AlertCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.menunggu_review || 0}</p>
                <p className="text-sm text-muted-foreground">Menunggu Review</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.selesai_hari_ini || 0}</p>
                <p className="text-sm text-muted-foreground">Selesai Hari Ini</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.ditolak || 0}</p>
                <p className="text-sm text-muted-foreground">Ditolak</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Permohonan */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Permohonan Terbaru</CardTitle>
          <Button variant="outline" asChild>
            <Link href="/dashboard/permohonan">
              Lihat Semua <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">Semua</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="completed">Selesai</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-4">
              <div className="space-y-4">
                {recentPermohonan?.map((p) => (
                  <div key={p.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{p.nomor_registrasi}</p>
                      <p className="text-sm text-muted-foreground">{p.layanan?.nama}</p>
                      <p className="text-sm text-muted-foreground">{p.nama_lengkap}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge variant={getStatusVariant(p.status)}>{p.status}</Badge>
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/dashboard/permohonan/${p.id}`}>
                          Detail <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

function getStatusVariant(status: string) {
  switch (status) {
    case "completed": return "default"
    case "rejected": return "destructive"
    case "revision": return "warning"
    default: return "secondary"
  }
}
```

---

# 8. DEVOPS & DEPLOYMENT

## 8.1 Dockerfile untuk Backend

```dockerfile
# Dockerfile.backend
FROM node:20-alpine AS base

# Install dependencies only when needed
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV=production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public

# Set the correct permission for prerender cache
RUN mkdir .next && chown nextjs:nodejs .next

# Automatically leverage output traces to reduce image size
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

CMD ["node", "server.js"]
```

## 8.2 Docker Compose untuk Full Stack

```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://postgres:password@db:5432/government
      - NEXT_PUBLIC_SUPABASE_URL=${SUPABASE_URL}
      - NEXT_PUBLIC_SUPABASE_ANON_KEY=${SUPABASE_ANON_KEY}
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=government
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

## 8.3 Nginx Configuration

```nginx
# nginx.conf
events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log /var/log/nginx/access.log main;
    error_log /var/log/nginx/error.log warn;

    # Performance
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript 
               application/json application/javascript application/xml+rss 
               application/rss+xml font/truetype font/opentype 
               application/vnd.ms-fontobject image/svg+xml;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=1r/s;

    upstream app {
        server app:3000;
        keepalive 32;
    }

    server {
        listen 80;
        server_name localhost;
        return 301 https://$server_name$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name localhost;

        # SSL Configuration
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;
        ssl_prefer_server_ciphers on;
        ssl_session_cache shared:SSL:10m;
        ssl_session_timeout 10m;

        root /var/www/html;
        index index.html;

        # API routes
        location /api/ {
            limit_req zone=api burst=20 nodelay;
            proxy_pass http://app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
        }

        # Static files
        location /_next/static {
            proxy_pass http://app;
            proxy_cache_valid 200 60m;
            add_header Cache-Control "public, immutable";
        }

        # Public static files
        location /static {
            proxy_pass http://app;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }

        # Health check
        location /health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }

        # Default fallback
        location / {
            proxy_pass http://app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }
    }
}
```

## 8.4 CI/CD dengan GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

env:
  NODE_VERSION: '20'

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci
      - run: npm run lint

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci
      - run: npm run test

  build:
    runs-on: ubuntu-latest
    needs: [lint, test]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-artifact@v4
        with:
          name: dist
          path: .next

  deploy-staging:
    runs-on: ubuntu-latest
    needs: [build]
    if: github.ref == 'refs/heads/main'
    environment:
      name: staging
      url: ${{ steps.deploy.outputs.url }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - run: npm ci
      - run: npm run build
      - name: Deploy to Railway
        run: railway up --service $SERVICE_NAME
        env:
          RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}

  deploy-production:
    runs-on: ubuntu-latest
    needs: [deploy-staging]
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    environment:
      name: production
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Production
        run: |
          # Add production deployment steps
          echo "Deploying to production..."
```

---

# 9. SECURITY BEST PRACTICES

## 9.1 Authentication & Authorization

```typescript
// lib/auth/middleware.ts
import { createServerClient, type CookieOptions } from "@supabase/ssr"
import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({
    request: { headers: request.headers },
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({ name, value, ...options })
          response = NextResponse.next({
            request: { headers: request.headers },
          })
          response.cookies.set({ name, value, ...options })
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({ name, value: "", ...options })
          response = NextResponse.next({
            request: { headers: request.headers },
          })
          response.cookies.set({ name, value: "", ...options })
        },
      },
    }
  )

  // Refresh session if expired
  await supabase.auth.getUser()

  // Protected routes
  const protectedPaths = ["/dashboard", "/admin", "/settings"]
  const isProtected = protectedPaths.some(path => 
    request.nextUrl.pathname.startsWith(path)
  )

  if (isProtected) {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  return response
}
```

```typescript
// middleware.ts
import { updateSession } from "@/lib/auth/middleware"

export async function middleware(request: NextRequest) {
  return await updateSession(request)
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
```

## 9.2 Input Validation & Sanitization

```typescript
// lib/validators/sanitize.ts
import DOMPurify from "isomorphic-dompurify"

// Sanitize HTML input
export function sanitizeHTML(dirty: string): string {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li'],
    ALLOWED_ATTR: [],
  })
}

// Validate NIK format
export function isValidNIK(nik: string): boolean {
  // Basic validation: 16 digits
  if (!/^\d{16}$/.test(nik)) return false
  
  // Check province code (01 = Aceh)
  const provCode = nik.substring(0, 2)
  if (provCode !== '11') return false // Aceh code is 11
  
  // Check birthdate code
  const birthDateCode = nik.substring(6, 12)
  const day = parseInt(birthDateCode.substring(0, 2))
  const month = parseInt(birthDateCode.substring(2, 4))
  
  if (day < 1 || day > 31 || month < 1 || month > 12) return false
  
  return true
}

// Validate Email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Validate Phone Number (Indonesian)
export function isValidPhone(phone: string): boolean {
  // Accept: 08xx, +628xx, 628xx
  const phoneRegex = /^(\+62|62|0)[2-9]\d{7,11}$/
  return phoneRegex.test(phone.replace(/\s/g, ''))
}

// Sanitize filename
export function sanitizeFilename(filename: string): string {
  return filename
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/\.{2,}/g, '.')
    .substring(0, 255)
}
```

## 9.3 CSRF Protection

```typescript
// app/api/csrf/route.ts
import { cookies } from "next/headers"
import { randomBytes } from "crypto"

export async function GET() {
  const cookieStore = await cookies()
  
  // Generate CSRF token
  const csrfToken = randomBytes(32).toString('hex')
  
  // Store in cookie (HttpOnly, Secure)
  cookieStore.set('csrf_token', csrfToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 60 * 60 * 24, // 24 hours
  })
  
  return Response.json({ csrfToken })
}
```

```typescript
// lib/csrf.ts
export async function verifyCSRF(token: string, cookieToken: string): Promise<boolean> {
  if (!token || !cookieToken) return false
  if (token !== cookieToken) return false
  
  // Timing-safe comparison
  const tokenBuffer = Buffer.from(token)
  const cookieBuffer = Buffer.from(cookieToken)
  
  if (tokenBuffer.length !== cookieBuffer.length) return false
  
  return crypto.timingSafeEqual(tokenBuffer, cookieBuffer) === true
}
```

---

# 10. PERFORMANCE OPTIMIZATION

## 10.1 Caching Strategy

```typescript
// lib/cache.ts
import { Redis } from "ioredis"

const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379")

// Cache helper functions
export async function cacheGet<T>(key: string): Promise<T | null> {
  const data = await redis.get(key)
  return data ? JSON.parse(data) : null
}

export async function cacheSet<T>(key: string, value: T, ttlSeconds = 3600): Promise<void> {
  await redis.setex(key, ttlSeconds, JSON.stringify(value))
}

export async function cacheDelete(key: string): Promise<void> {
  await redis.del(key)
}

export async function cacheInvalidatePattern(pattern: string): Promise<void> {
  const keys = await redis.keys(pattern)
  if (keys.length > 0) {
    await redis.del(...keys)
  }
}

// Usage in API route
export async function GET(request: Request) {
  const cacheKey = `stats:monthly:${dateRange}`
  
  // Try cache first
  const cached = await cacheGet(cacheKey)
  if (cached) {
    return NextResponse.json(cached, {
      headers: { 'X-Cache': 'HIT' }
    })
  }
  
  // Fetch from database
  const data = await fetchStats(dateRange)
  
  // Store in cache (1 hour)
  await cacheSet(cacheKey, data, 3600)
  
  return NextResponse.json(data, {
    headers: { 'X-Cache': 'MISS' }
  })
}
```

## 10.2 Image Optimization

```typescript
// lib/images.ts
import sharp from "sharp"

interface ResizeOptions {
  width: number
  height?: number
  fit?: 'cover' | 'contain' | 'fill'
  quality?: number
}

export async function optimizeImage(
  buffer: Buffer,
  options: ResizeOptions = { width: 800 }
): Promise<Buffer> {
  const { width, height, fit = 'cover', quality = 80 } = options
  
  return sharp(buffer)
    .resize(width, height, { fit })
    .jpeg({ quality })
    .toBuffer()
}

export async function generateThumbnail(
  buffer: Buffer
): Promise<Buffer> {
  return sharp(buffer)
    .resize(200, 200, { fit: 'cover' })
    .jpeg({ quality: 60 })
    .toBuffer()
}

export async function getImageMetadata(buffer: Buffer) {
  const metadata = await sharp(buffer).metadata()
  return {
    width: metadata.width,
    height: metadata.height,
    format: metadata.format,
    size: buffer.length,
  }
}
```

## 10.3 Database Query Optimization

```typescript
// Use EXPLAIN ANALYZE to check query performance
const EXPLAIN_ANALYZE = `
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT p.*, l.nama as layanan_nama
FROM permohonan p
JOIN layanan l ON p.layanan_id = l.id
WHERE p.status = 'completed'
ORDER BY p.created_at DESC
LIMIT 100;
`

// Pagination with cursor (better for large tables)
export async function getPermohonanCursor(
  cursor: string | null,
  limit: number = 20
) {
  const supabase = createClient()
  
  let query = supabase
    .from("permohonan")
    .select("*, layanan(nama)")
    .order("created_at", { ascending: false })
    .limit(limit + 1) // Get one extra to check if there's more
  
  if (cursor) {
    query = query.lt("created_at", cursor)
  }
  
  const { data, error } = await query
  
  if (error) throw error
  
  // Check if there's more data
  const hasMore = data.length > limit
  const results = hasMore ? data.slice(0, -1) : data
  const nextCursor = hasMore ? results[results.length - 1].created_at : null
  
  return { results, nextCursor }
}

// Batch inserts for better performance
export async function batchInsertPermohonan(items: any[]) {
  const supabase = createClient()
  
  // Insert in batches of 100
  const batchSize = 100
  const results = []
  
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize)
    const { data, error } = await supabase
      .from("permohonan")
      .insert(batch)
      .select()
    
    if (error) throw error
    results.push(...data)
  }
  
  return results
}
```

---

# 11. TESTING & QUALITY ASSURANCE

## 11.1 Unit Testing dengan Jest

```typescript
// __tests__/validators.test.ts
import { describe, expect, test } from '@jest/globals'
import { isValidNIK, isValidEmail, isValidPhone, sanitizeFilename } from '@/lib/validators/sanitize'

describe('Validators', () => {
  describe('isValidNIK', () => {
    test('should accept valid Aceh NIK', () => {
      expect(isValidNIK('1101051201800001')).toBe(true)
    })
    
    test('should reject invalid length', () => {
      expect(isValidNIK('1101051201')).toBe(false)
    })
    
    test('should reject non-numeric', () => {
      expect(isValidNIK('11010512018000ab')).toBe(false)
    })
  })
  
  describe('isValidEmail', () => {
    test('should accept valid email', () => {
      expect(isValidEmail('test@example.com')).toBe(true)
    })
    
    test('should reject invalid email', () => {
      expect(isValidEmail('invalid-email')).toBe(false)
    })
  })
  
  describe('sanitizeFilename', () => {
    test('should remove special characters', () => {
      expect(sanitizeFilename('file<>:"/\\|*?.pdf')).toBe('file______.pdf')
    })
    
    test('should truncate long filenames', () => {
      const longName = 'a'.repeat(300) + '.pdf'
      expect(sanitizeFilename(longName).length).toBeLessThanOrEqual(255)
    })
  })
})
```

## 11.2 Integration Testing

```typescript
// __tests__/api/permohonan.test.ts
import { describe, expect, test, beforeAll, afterAll } from '@jest/globals'
import request from 'supertest'

// Mock Supabase for tests
jest.mock('@/lib/supabase/server', () => ({
  createClient: () => ({
    from: jest.fn().mockReturnValue({
      select: jest.fn().mockReturnThis(),
      insert: jest.fn().mockReturnThis(),
      eq: jest.fn().mockReturnThis(),
      single: jest.fn().mockResolvedValue({ data: mockData, error: null }),
    }),
  }),
}))

describe('Permohonan API', () => {
  test('GET /api/permohonan should return list', async () => {
    const response = await request(app)
      .get('/api/permohonan')
      .set('Authorization', `Bearer ${testToken}`)
    
    expect(response.status).toBe(200)
    expect(response.body.success).toBe(true)
    expect(Array.isArray(response.body.data)).toBe(true)
  })
  
  test('POST /api/permohonan should create new permohonan', async () => {
    const newPermohonan = {
      nik: '1101051201800001',
      nama_lengkap: 'Test User',
      email: 'test@example.com',
      no_telp: '081234567890',
      layanan_id: 'mock-uuid',
      deskripsi: 'Test description for permohonan',
    }
    
    const response = await request(app)
      .post('/api/permohonan')
      .send(newPermohonan)
    
    expect(response.status).toBe(201)
    expect(response.body.data.nomor_registrasi).toBeDefined()
  })
})
```

## 11.3 E2E Testing dengan Playwright

```typescript
// e2e/layanan.spec.ts
import { test, expect } from '@playwright/test'

test.describe('Layanan Page', () => {
  test('should display layanan list', async ({ page }) => {
    await page.goto('/layanan')
    
    // Check page title
    await expect(page.locator('h1')).toContainText('Layanan')
    
    // Check layanan cards exist
    await expect(page.locator('[data-testid="layanan-card"]').first()).toBeVisible()
    
    // Check filter options
    await expect(page.locator('select[name="kategori"]')).toBeVisible()
  })
  
  test('should filter layanan by category', async ({ page }) => {
    await page.goto('/layanan')
    
    // Select category filter
    await page.selectOption('select[name="kategori"]', 'kependudukan')
    
    // Wait for results to update
    await page.waitForLoadState('networkidle')
    
    // Verify filtered results
    const cards = page.locator('[data-testid="layanan-card"]')
    await expect(cards).toHaveCount(await cards.all().then(c => c.length))
  })
  
  test('should submit permohonan form', async ({ page }) => {
    await page.goto('/layanan/akta-kelahiran')
    
    // Fill form
    await page.fill('input[name="nik"]', '1101051201800001')
    await page.fill('input[name="nama_lengkap"]', 'Test User')
    await page.fill('input[name="email"]', 'test@example.com')
    await page.fill('input[name="no_telp"]', '081234567890')
    await page.fill('textarea[name="deskripsi"]', 'Test submission for e2e testing purposes')
    
    // Submit
    await page.click('button[type="submit"]')
    
    // Check success message
    await expect(page.locator('[data-testid="success-message"]')).toBeVisible()
    await expect(page.locator('[data-testid="nomor-registrasi"]')).toBeVisible()
  })
})
```

---

# 12. REAL PROJECT EXAMPLES

## 12.1 Complete Government Portal Structure

```
government-portal/
├── src/
│   ├── app/
│   │   ├── (public)/
│   │   │   ├── page.tsx                 # Homepage
│   │   │   ├── layout.tsx
│   │   │   ├── layanan/
│   │   │   │   ├── page.tsx             # List layanan
│   │   │   │   ├── [slug]/
│   │   │   │   │   ├── page.tsx         # Detail layanan
│   │   │   │   │   └── pengajuan/
│   │   │   │   │       └── page.tsx     # Form pengajuan
│   │   │   ├── data/
│   │   │   │   ├── page.tsx             # Open data
│   │   │   │   └── [dataset]/
│   │   │   │       └── page.tsx
│   │   │   ├── tentang/
│   │   │   │   └── page.tsx
│   │   │   └── kontak/
│   │   │       └── page.tsx
│   │   ├── (auth)/
│   │   │   ├── login/
│   │   │   │   └── page.tsx
│   │   │   ├── register/
│   │   │   │   └── page.tsx
│   │   │   └── forgot-password/
│   │   │       └── page.tsx
│   │   ├── (dashboard)/
│   │   │   ├── layout.tsx               # Dashboard layout with sidebar
│   │   │   ├── dashboard/
│   │   │   │   └── page.tsx             # Overview
│   │   │   ├── permohonan/
│   │   │   │   ├── page.tsx             # List permohonan
│   │   │   │   ├── [id]/
│   │   │   │   │   └── page.tsx         # Detail permohonan
│   │   │   │   └── baru/
│   │   │   │       └── page.tsx         # Buat permohonan
│   │   │   ├── layanan/
│   │   │   │   └── page.tsx             # Kelola layanan
│   │   │   ├── laporan/
│   │   │   │   └── page.tsx
│   │   │   ├── pemdi/
│   │   │   │   └── page.tsx             # PEMDI evaluation
│   │   │   ├── users/
│   │   │   │   └── page.tsx
│   │   │   └── settings/
│   │   │       └── page.tsx
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   │   └── [...nextauth]/
│   │   │   │       └── route.ts
│   │   │   ├── permohonan/
│   │   │   │   └── route.ts
│   │   │   ├── upload/
│   │   │   │   └── route.ts
│   │   │   └── reports/
│   │   │       └── route.ts
│   │   ├── layout.tsx
│   │   └── globals.css
│   ├── components/
│   │   ├── ui/                          # shadcn/ui components
│   │   ├── layout/
│   │   │   ├── header.tsx
│   │   │   ├── footer.tsx
│   │   │   ├── sidebar.tsx
│   │   │   └── mobile-nav.tsx
│   │   ├── forms/
│   │   │   ├── permohonan-form.tsx
│   │   │   ├── login-form.tsx
│   │   │   └── filter-form.tsx
│   │   ├── tables/
│   │   │   └── data-table.tsx
│   │   ├── charts/
│   │   │   └── dashboard-charts.tsx
│   │   └── shared/
│   │       ├── loading.tsx
│   │       ├── error-boundary.tsx
│   │       └── empty-state.tsx
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts
│   │   │   ├── server.ts
│   │   │   └── middleware.ts
│   │   ├── utils/
│   │   │   ├── cn.ts
│   │   │   ├── format.ts
│   │   │   └── validators.ts
│   │   ├── constants.ts
│   │   └── types.ts
│   ├── hooks/
│   │   ├── use-auth.ts
│   │   └── use-permissions.ts
│   └── actions/
│       ├── auth-actions.ts
│       └── permohonan-actions.ts
├── public/
│   ├── images/
│   └── documents/
├── .env.local
├── tailwind.config.ts
├── next.config.js
├── package.json
└── README.md
```

## 12.2 Deployment Checklist

```markdown
# Pre-Deployment Checklist

## Development
- [ ] All tests passing
- [ ] Code linting clean
- [ ] No console errors
- [ ] Responsive design verified

## Security
- [ ] API keys in .env (not in code)
- [ ] RLS policies enabled on all tables
- [ ] Input validation implemented
- [ ] HTTPS enforced
- [ ] Security headers configured

## Performance
- [ ] Images optimized
- [ ] Static pages pre-rendered
- [ ] Caching configured
- [ ] Database indexes created
- [ ] Bundle size < 200KB gzipped

## SEO
- [ ] Meta tags complete
- [ ] Sitemap generated
- [ ] robots.txt configured
- [ ] Structured data added
- [ ] Open Graph images

## Government Compliance
- [ ] Privacy policy page
- [ ] Terms of service page
- [ ] Data protection notice
- [ ] Accessibility compliance (WCAG 2.1)
- [ ] PDP compliance (UU No. 27/2022)

## Monitoring
- [ ] Error tracking (Sentry) configured
- [ ] Analytics (Plausible/Umami) integrated
- [ ] Uptime monitoring set up
- [ ] Log aggregation configured

## Backup & Recovery
- [ ] Database backup scheduled
- [ ] Files backup configured
- [ ] Recovery procedure documented
- [ ] Backup tested
```

---

## Referensi Tambahan

### Dokumentasi
- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [shadcn/ui](https://ui.shadcn.com)
- [Supabase](https://supabase.com/docs)
- [React Hook Form](https://react-hook-form.com)
- [TanStack Table](https://tanstack.com/table)

### Video Tutorials
- [Next.js Full Course](https://youtube.com/playlist?list=PLC3Sv8zrFTw-pA5R9-c7CKwMXG2qkE5oO)
- [Build Government Portal](https://youtube.com/playlist?list=...)

### Communities
- [r/nextjs](https://reddit.com/r/nextjs)
- [Next.js Discord](https://discord.gg/nextjs)
- [Indonesian Dev Community](https://discord.gg/id-dev)