# SKILL: Hackintosh Setup & Optimization

## Metadata
```
name: ckm:hackintosh-setup
description: Setup, configure, and optimize Hackintosh on ThinkPad X13 Yoga Gen 1. 
             Use when installing macOS on non-Apple hardware, troubleshooting boot issues, 
             optimizing performance, or managing OpenCore configuration.
version: 1.0.0
author: Niumination
```

---

## DAFTAR ISI
1. [Hardware Overview](#1-hardware-overview)
2. [OpenCore Setup](#2-opencore-setup)
3. [EFI Configuration](#3-efi-configuration)
4. [Kexts & Drivers](#4-kexts--drivers)
5. [Post-Installation](#5-post-installation)
6. [Performance Optimization](#6-performance-optimization)
7. [Troubleshooting](#7-troubleshooting)
8. [Maintenance](#8-maintenance)

---

# 1. HARDWARE OVERVIEW

## ThinkPad X13 Yoga Gen 1 Specifications

```
┌─────────────────────────────────────────────────────────────┐
│           ThinkPad X13 Yoga Gen 1 - Hackintosh Target       │
├─────────────────────────────────────────────────────────────┤
│  CPU:    Intel Core i5-10210U (Comet Lake)                  │
│          - Base: 1.6 GHz, Boost: 4.2 GHz                    │
│          - 4 Cores / 8 Threads                              │
│  RAM:    16GB DDR4 (upgradeable to 32GB)                    │
│  SSD:    512GB NVMe (Samsung PM981a atau similiar)          │
│  GPU:    Intel UHD Graphics 620                             │
│  Display: 13.3" FHD IPS Touchscreen                         │
│  Network: Intel Wi-Fi 6 AX201 (需要替换)                    │
│  Audio:   Realtek ALC3287                                   │
│  Touchpad: Synaptics (I2C)                                  │
│  Fingerprint: Goodix (需要驱动)                            │
├─────────────────────────────────────────────────────────────┤
│  Status: MOSTLY COMPATIBLE ⚠️                               │
│  Notes: Wi-Fi needs replacement, others working             │
└─────────────────────────────────────────────────────────────┘
```

## Component Compatibility

| Component | Status | Notes |
|-----------|--------|-------|
| CPU | ✅ Working | All features working |
| iGPU | ✅ Working | Hardware acceleration OK |
| RAM | ✅ Working | 16GB recognized |
| SSD | ⚠️ Partial | NVMe works, but may need SSDT |
| Wi-Fi | ❌ Replace | Intel AX201 not supported - replace with Broadcom |
| Bluetooth | ⚠️ Partial | Works after Wi-Fi replacement |
| Audio | ✅ Working | AppleALC layout-id 21 |
| Touchpad | ✅ Working | VoodooI2C + gesture support |
| Screen | ✅ Working | Brightness control OK |
| Fingerprint | ❌ Not Working | No driver available |
| USB | ✅ Working | All ports functional |
| Camera | ✅ Working | FaceTime HD |
| Keyboard | ✅ Working | FN keys working |
| Battery | ✅ Working | ACPI patches OK |
| Sleep/Wake | ⚠️ Partial | May need tweaks |

---

# 2. OPENCORE SETUP

## Installation Prerequisites

```bash
# Yang dibutuhkan:
# 1. macOS installer (Catalina, Big Sur, Monterey, Ventura, atau Sequoia)
# 2. OpenCore (latest release dari https://github.com/acidanthera/OpenCorePkg)
# 3. Proper EFI folder structure
# 4. USB drive 16GB+
```

## OpenCore Version Matrix

| macOS Version | OpenCore Minimum | Recommended |
|---------------|------------------|-------------|
| Catalina | 0.5.9 | 0.6.0+ |
| Big Sur | 0.6.3 | 0.6.7+ |
| Monterey | 0.7.0 | 0.7.9+ |
| Ventura | 0.8.0 | 0.8.8+ |
| Sequoia | 0.9.0 | Latest |

## Recommended Version: **macOS Sequoia 15.x with OpenCore 1.0.0+**

## OpenCore Folder Structure

```
EFI/
├── BOOT/
│   └── BOOTx64.efi
└── OC/
    ├── OpenCore.efi
    ├── Config.plist
    ├── Drivers/
    │   ├── HfsPlus.efi
    │   └── OpenRuntime.efi
    ├── Kexts/
    │   ├── Lilu.kext
    │   ├── WhateverGreen.kext
    │   ├── AppleALC.kext
    │   ├── VirtualSMC.kext
    │   ├── IntelBluetoothFirmware.kext
    │   ├── AirportItlwm.kext  # atau yang compatible
    │   └── VoodooI2C.kext
    └── ACPI/
        ├── SSDT-PLUG.aml
        ├── SSDT-EC.aml
        ├── SSDT-USBX.aml
        └── SSDT-X13.aml  # Custom untuk ThinkPad
```

---

# 3. EFI CONFIGURATION

## Config.plist Essential Settings

### Boot Settings
```xml
<!-- Config.plist -->
<key>Boot</key>
<dict>
    <key>Timeout</key>
    <integer>5</integer>
    <key>ShowPicker</key>
    <true/>
    <key>HideSelf</key>
    <true/>
</dict>

<key>Booter</key>
<dict>
    <key>Quirk</key>
    <dict>
        <key>EnableWriteUnprotector</key>
        <true/>
        <key>RebuildAppleMemoryMap</key>
        <true/>
        <key>EnableSysCallPatch</key>
        <true/>
    </dict>
</dict>

<key>Kernel</key>
<dict>
    <key>Add</key>
    <array>
        <!-- Kexts diurutkan: Lilu first, then others -->
    </array>
    <key>Quirk</key>
    <dict>
        <key>AppleXcpmExtraMsrs</key>
        <true/>
        <key>CustomSMBIOSGuid</key>
        <true/>
        <key>DisableIoMapper</key>
        <true/>
        <key>PanicNoKextDump</key>
        <true/>
        <key>XhciPortLimit</key>
        <true/>
    </dict>
</dict>
```

### DeviceProperties (Graphics)
```xml
<key>DeviceProperties</key>
<dict>
    <key>Add</key>
    <dict>
        <key>PciRoot(0x0)/Pci(0x2,0x0)</key>
        <dict>
            <key>AAPL,ig-platform-id</key>
            <data>
            <!-- Coffee Lake: 0300923E -->
            </data>
            <key>device-id</key>
            <data>
            <!-- Intel UHD 620 -->
            </data>
            <key>framebuffer-patch-enable</key>
            <data>AQAAAA==</data>
        </dict>
    </dict>
</dict>
```

### UEFI Drivers Order
```
1. OpenRuntime.efi (REQUIRED - dari OpenCore package)
2. HfsPlus.efi (untuk boot dari HFS+ jika perlu)
3. OpenCanopy.efi (untuk GUI picker - optional)
4. CrScreenshotDxe.efi (untuk screenshot - optional)
```

---

# 4. KEXTS & DRIVERS

## Required Kexts

### Core Kexts (Wajib)
```bash
# Download semua dari https://github.com/acidanthera
# atau ketuk langsung:

Lilu.kext          # Framework untuk semua patching
WhateverGreen.kext # GPU patching
AppleALC.kext      # Audio output
VirtualSMC.kext    # SMC emulation
```

### Graphics (Wajib untuk UHD 620)
```
WhateverGreen.kext
# Automatically handles Intel UHD 620
```

### Audio Setup (Layout-ID 21 untuk X13 Yoga)
```bash
# Edit boot-args di config.plist:
# <key>boot-args</key>
# <string>-v alcid=21</string>

# Atau gunakan ProperTree untuk set:
DeviceProperties > Add > PciRoot(0x0)/Pci(0x1f,0x3) >
  layout-id = 21000000 (decimal 21)
```

### Wi-Fi Solution (CRITICAL - Intel not supported!)

**Option 1: Replace with Broadcom (RECOMMENDED)**
```bash
# Ganti Intel Wi-Fi card dengan:
# - Broadcom BCM94352Z (DW1560) - Recommended
# - Broadcom BCM94360NG - Native support
# - Fenvi FV-T919 - PCIe, no adapter needed

# После penggantian, gunakan:
AirportItlwm.kext  # Untuk Intel (setelah replace)
# atau
AirportBrcmFixup.kext  # Untuk Broadcom
```

**Option 2: Use Intel Wi-Fi dengan itlwm (Limited)**
```bash
# itlwm + HeliPort app
#局限性:
# - No WPA3
# - No Monitor mode
# - May have issues dengan tertentu networks

# Install:
1. AirportItlwm.kext (sesuaikan dengan macOS version)
2. HeliPort (https://github.com/NoahApache/HeliPort)
```

### Touchpad (Wajib untuk Yoga - I2C)
```bash
# VoodooI2C + VoodooI2CHID
VoodooI2C.kext
VoodooI2CHID.kext

# Enable dalam config.plist:
<key>DeviceProperties</key>
<dict>
    <key>Add</key>
    <dict>
        <key>PciRoot(0x0)/Pci(0x15,0x0)/Pci(0x0,0x0)</key>
        <dict>
            <key>IOInterruptSpecifiers</key>
            <data></data>
        </dict>
    </dict>
</dict>
```

### Bluetooth
```bash
# Untuk Intel:
IntelBluetoothFirmware.kext
IntelBluetoothInject.kext

# Untuk Broadcom:
BlueToolFixup.kext  # Dalam Lilu plugins
BrcmBluetoothInjector.kext
```

## Kexts Installation

```bash
# Install kexts ke EFI/OC/Kexts/
# Pastikan semua permissions correct:

sudo cp -R *.kext /Volumes/ESP/EFI/OC/Kexts/
sudo chmod -R 755 /Volumes/ESP/EFI/OC/Kexts/*.kext
sudo chown -R root:wheel /Volumes/ESP/EFI/OC/Kexts/*.kext
```

---

# 5. POST-INSTALLATION

## Initial Setup

```bash
# 1. Update OpenCore (terbaru)
# 2. Generate new Serial, MLB, ROM
#    Use GenSMBIOS: https://github.com/corpnewt/GenSMBIOS

# 3. Set sebagai MacBookPro15,2 (atau sesuai)
# 4. Verify dengan iMessage activation check

# 5. Install semua kexts dengan proper ordering:

# Order Penting:
1. Lilu.kext          (First!)
2. VirtualSMC.kext
3. WhateverGreen.kext
4. AppleALC.kext
5. AirportItlwm.kext  (atau Broadcom equivalent)
6. IntelBluetoothFirmware.kext
7. VoodooI2C.kext + VoodooI2CHID.kext
8. USBMap.kext atau USBInjectAll.kext
```

## Clover to OpenCore Migration

```bash
# 1. Backup existing Clover EFI
cp -R /Volumes/ESP/EFI /Volumes/ESP/EFI-CLOVER-BACKUP

# 2. Mount EFI partition
sudo diskutil mount /dev/disk0s1

# 3. Create new OpenCore structure
mkdir -p EFI/BOOT
mkdir -p EFI/OC/{Drivers,Kexts,ACPI,Tools}

# 4. Copy files dari OpenCore package
cp OpenCore.efi EFI/
cp BOOTx64.efi EFI/BOOT/
cp Drivers/*.efi EFI/OC/Drivers/

# 5. Copy kexts
cp -R Lilu.kext EFI/OC/Kexts/
cp -R WhateverGreen.kext EFI/OC/Kexts/
# ... etc
```

## Essential Post-Install Tweaks

```bash
# 1. Disable Intel SpeedStep (untuk stability)
# Tambahkan di boot-args: -disableTsd

# 2. Enable HiDPI untuk Retina display
# Install RDM: https://github.com/sys kb/Reset-CV

# 3. Disable Gatekeeper untuk development
sudo spctl --master-disable

# 4. Install Xcode
xcode-select --install

# 5. Enable SSH untuk remote access
sudo systemsetup -f -setremotelogin on

# 6. Setup Samba untuk file sharing
# Install via Homebrew: brew install samba
```

---

# 6. PERFORMANCE OPTIMIZATION

## Battery Optimization

```bash
# Install Volta atau AlDente untuk charging limit
# https://github.com/sickcodes/AlDente
brew install --cask aldente

# atau Volta
brew install --cask volta
```

## Power Management

```xml
<!-- SSDT-PLUG.aml untuk CPUSet plugin -->
DefinitionBlock("", "SSDT", 2, "ACDT", "CpuPlug", 0x00003000)
{
    Method(_SB_.CPU0._PSD, 0, NotSerialized)
    {
        Return(Package(0x05)
        {
            0x05, 0x00, 0x00, 0x00, 0x00
        })
    }
}
```

## SSD Optimization

```bash
# TRIM enable untuk third-party SSDs
sudo trimforce enable

# Disable sudden motion sensor (ThinkPad specific)
sudo pmset -a sms 0
```

## Memory Optimization

```bash
# 16GB RAM - adequate untuk development
# Add more dengan ZIP:
# Tambahkan di /Library/LaunchDaemons/com.custom.plist:

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "...">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.custom.memory</string>
    <key>ProgramArguments</key>
    <array>
        <string>sysctl</string>
        <string>-w</string>
        <string>vm.compressor_mode=2</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
```

## Thermal Management

```bash
# Install Macs Fan Control untuk monitoring
brew install --cask Macs-fan-control

# Set custom fan curve untuk ThinkPad
# X13 Yoga tidak memiliki fan kontrol via software
# Gunakan SSDT untuk PPMC control jika available
```

---

# 7. TROUBLESHOOTING

## Common Issues & Solutions

### Issue: Kernel Panic on Boot
```
🔍 Diagnosis:
- Black screen atau panic dengan teks
- Screen freeze

🛠️ Solutions:
1. Add -v di boot-args untuk verbose output
2. Check kext order - Lilu harus first
3. Disable AppleCpuPmCfgLock dan AppleXcpmCfgLock
4. Verify ig-platform-id correct untuk UHD 620
5. Try -disableTsd boot arg
```

### Issue: No Audio Output
```
🔍 Diagnosis:
- Speaker tidak working
- No output device detected

🛠️ Solutions:
1. Verify AppleALC.kext installed correctly
2. Try different layout-id (try 21, 11, 13, 15)
3. Add alcid=XX ke boot-args
4. Check DeviceProperties untuk layout-id
5. Reset NVRAM: sudo nvram -c
```

### Issue: Wi-Fi Not Detected
```
🔍 Diagnosis:
- No Wi-Fi networks found
- Airport icon not showing

🛠️ Solutions:
1. Intel AX201 cannot be used - REPLACE with Broadcom
2. If using itlwm, verify AirportItlwm.kext version matches macOS
3. Check System Preferences > Network - Wi-Fi enabled
4. Reset NVRAM
5. Check boot-args untuk -itlwm=1
```

### Issue: Touchpad Not Working
```
🔍 Diagnosis:
- Touchpad tidak respond
- Gestures not working

🛠️ Solutions:
1. Install VoodooI2C + VoodooI2CHID.kext
2. Verify I2C controller in DeviceProperties
3. Add -i2c-force-polling to boot-args if needed
4. Check for conflicting drivers
5. Verify GPIO pin in SSDT
```

### Issue: Screen Brightness Not Adjusting
```
🔍 Diagnosis:
- Brightness keys not working
- Slider in System Preferences not visible

🛠️ Solutions:
1. Install WhateverGreen.kext
2. Add GFX0 to PEGP patch jika perlu
3. Add -igfxblr boot-arg
4. Verify ACPI backlight control
5. Use BCBacklight.kext jika required
```

### Issue: Sleep/Wake Problems
```
🔍 Diagnosis:
- Can't sleep
- Wake from sleep fails
- Black screen after wake

🛠️ Solutions:
1. Disable hibernation: sudo pmset -a hibernatemode 0
2. Add darkwake=0 ke boot-args
3. Check USB power delivery settings
4. Disable Bluetooth wake if problematic
5. Use hibernation with proper SSDT
```

### Issue: Bluetooth Not Pairing
```
🔍 Diagnosis:
- Bluetooth won't connect
- Devices not found

🛠️ Solutions:
1. Install BlueToolFixup.kext
2. For Intel: install IntelBluetoothFirmware.kext
3. Move Bluetooth chip wake to USB power
4. Reset Bluetooth module: sudo pkill bluetoothd
```

## NVRAM Reset

```bash
# When stuck, reset NVRAM:
# 1. Boot ke OpenCore picker
# 2. Press Space on boot option
# 3. Select "Reset NVRAM"
# atau
# Terminal:
sudo nvram -c
sudo nvram -d csr-active-config  # Jika ada CSR flags
```

## Verbose Boot for Debugging

```bash
# Add ke boot-args di config.plist:
<key>boot-args</key>
<string>-v debug=0x100 keepsyms=1</string>

# This will show all kernel messages
# Capture dengan photo atau serial output
```

---

# 8. MAINTENANCE

## Regular Maintenance

```bash
# Weekly:
# 1. Check for OpenCore updates
# 2. Check for kext updates
# 3. Verify backup EFI

# Monthly:
# 1. Update macOS if safe
# 2. Rebuild kernel cache: sudo kextcache -i /
# 3. Verify kext permissions

# Before major updates:
# 1. Backup entire EFI
# 2. Create snapshot dengan Time Machine
# 3. Verify all kexts compatible with new macOS
```

## Update Procedure

```bash
# 1. Check OpenCore version compatibility
#    https://github.com/acidanthera/OpenCorePkg/releases

# 2. Update OpenCore:
#    - Download latest OpenCore
#    - Mount EFI
#    - Replace BOOTx64.efi and OpenCore.efi
#    - Update Drivers/*.efi if needed

# 3. Update Kexts:
#    - Check each kext for updates
#    - Test after each update
#    - Document any breaking changes

# 4. Test after update:
#    - Boot success
#    - Sleep/wake
#    - Audio
#    - Wi-Fi/Bluetooth
#    - Touchpad
```

## Backup Strategy

```bash
# Daily: Automatic backup dengan script
#!/bin/bash
DATE=$(date +%Y%m%d)
EFI="/Volumes/ESP"
BACKUP="/Volumes/Backup/EFI-$DATE"
rm -rf $BACKUP
cp -R $EFI $BACKUP

# Weekly: Clone EFI to separate partition
# Monthly: Full system backup dengan Time Machine
```

## Useful Tools

```bash
# OC Auxiliary Tools - Visual config editor
# https://github.com/ic005k/OCAuxiliaryTools

# OpenCore Configurator - Alternative
# https://mackie100projects.altervista.org/

# GenSMBIOS - Generate serial numbers
# https://github.com/corpnewt/GenSMBIOS

# MountEFI - Mount EFI easily
# https://github.com/corpnewt/MountEFI

# ProperTree - Config plist editor
# https://github.com/corpnewt/ProperTree

# SSDTTime - Generate SSDTs
# https://github.com/corpnewt/SSDTTime
```

---

## Reference Links

### Official Documentation
- OpenCore Install Guide: https://dortania.github.io/OpenCore-Install-Guide/
- ACPI patching: https://dortania.github.io/Getting-Started-With-ACPI/
- Kexts installation: https://dortania.github.io/OpenCore-Install-Guide/ktext.html

### ThinkPad Specific
- ThinkPad X13 Yoga Gen 1: https://github.com/niumination/hackintosh (repository)
- RehabMan Laptop Guide: https://www.tonymacx86.com/threads/guide-booting-the-os-x-installer-on-laptops-with-clover.148093/

### Downloads
- OpenCore: https://github.com/acidanthera/OpenCorePkg/releases
- Lilu: https://github.com/acidanthera/Lilu/releases
- WhateverGreen: https://github.com/acidanthera/WhateverGreen/releases
- AppleALC: https://github.com/acidanthera/AppleALC/releases
- VirtualSMC: https://github.com/acidanthera/VirtualSMC/releases
- VoodooI2C: https://github.com/VoodooI2C/VoodooI2C/releases

---

## Checklist

### Pre-Installation
- [ ] Research your hardware
- [ ] Download OpenCore + kexts
- [ ] Prepare USB installer
- [ ] Backup existing system
- [ ] Read OpenCore documentation

### Post-Installation
- [ ] Generate new Serial/MLB/ROM
- [ ] Test iMessage, FaceTime
- [ ] Configure audio
- [ ] Configure Wi-Fi (replace card if Intel)
- [ ] Configure touchpad
- [ ] Test sleep/wake
- [ ] Verify all peripherals
- [ ] Create backup

### Weekly Maintenance
- [ ] Check for updates
- [ ] Verify backup
- [ ] Test critical functions
- [ ] Document any issues

---

**Last Updated: 20 Juni 2026**  
**Target Hardware: ThinkPad X13 Yoga Gen 1**  
**Status: ACTIVE DEVELOPMENT**