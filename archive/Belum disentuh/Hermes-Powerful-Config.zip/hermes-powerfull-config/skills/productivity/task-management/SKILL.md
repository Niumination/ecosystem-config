# SKILL: Manajemen Tugas & Project

## Deskripsi
Skill untuk membantu manajemen tugas harian, project management, dan produktivitas kerja menggunakan tool gratis dan open source.

## Tools Gratis untuk Task Management

### Self-hosted / Open Source
```
Taskwarrior      → https://taskwarrior.org (CLI-based task manager)
Todo.txt         → https://todotxt.org (simple text-based)
Super Productivity → https://super-productivity.com (web app, free)
Wekan            → https://wekan.github.io (Kanban board, Trello alternative)
Focalboard       → https://focalboard.com (Notion/Monday alternative)
Plane            → https://plane.so (Jira alternative, free tier)
MeisterTask      → https://meistertask.com (free tier available)
```

### Cloud-based (Free Tier)
```
Todoist          → https://todoist.com (free: 5 persons, limited projects)
TickTick         → https://ticktick.com (free tier generous)
Microsoft To Do  → https://toodledo.com / Microsoft 365 integration
Google Tasks     → https://tasks.google.com (integrated with Google)
Notion           → https://notion.so (free for individuals)
ClickUp          → https://clickup.com (free tier: unlimited tasks)
Asana            → https://asana.com (free: 15 users)
Trello           → https://trello.com (free: unlimited boards)

# Government-specific
Sistem Pengaduan KemenpanRB → https://sirup.kemenpan.go.id
SPBE Monitoring             → https://spanint.kemenpan.go.id
```

### Time Tracking
```
Toggl            → https://toggl.com (free: 5 users)
Clockify         → https://clockify.me (free: unlimited users)
Kimai            → https://kimai.org (open source, self-hosted)
ActivityWatch    → https://activitywatch.net (open source)
```

## Templates Task Management

### 1. Daily Routine Template

```markdown
## Rutinitas Harian - {Tanggal}

### 08:00 - 08:30 📋 Briefing & Plan
- [ ] Check email & Slack messages
- [ ] Review today's tasks
- [ ] Prioritize dengan Eisenhower Matrix

### 08:30 - 10:00 💻 Deep Work (Pagi)
- [ ] Task: {Task-name}
- [ ] Subtask: {Subtask}
- Notes:

### 10:00 - 10:15 ☕ Break

### 10:15 - 12:00 💻 Deep Work (Lanjutan)
- [ ] Task: {Task-name}
- Notes:

### 12:00 - 13:00 🍽️ Lunch Break

### 13:00 - 14:00 📬 Communication Block
- [ ] Balas email urgent
- [ ] Update status di chat
- [ ] Brief tim terkait

### 14:00 - 16:00 🔧 Meetings & Collaboration
- [ ] Meeting: {Meeting-name}
- [ ] Task: {Task-name}

### 16:00 - 16:30 📝 End of Day Review
- [ ] Dokumentasi progress
- [ ] Update task status
- [ ] Plan besok
```

### 2. Eisenhower Matrix Template

```markdown
## Eisenhower Matrix - Prioritization

### 🔴 QUADRANT 1: Urgent + Important (DO FIRST)
Deadline today or consequences severe

- [ ] 
- [ ] 
- [ ] 

### 🟡 QUADRANT 2: Important + Not Urgent (SCHEDULE)
Contributes to goals, no immediate deadline

- [ ] 
- [ ] 
- [ ] 

### 🟠 QUADRANT 3: Urgent + Not Important (DELEGATE)
Interruptions, but not crucial

- [ ] 
- [ ] 
- [ ] 

### 🟢 QUADRANT 4: Not Urgent + Not Important (ELIMINATE)
Time wasters

- [ ] 
- [ ] 
- [ ] 

---
## Prioritization Rules:
1. Max 3 items di Q1 per hari
2. Schedule Q2 activities in advance
3. Batch Q3 activities together
4. Eliminate or minimize Q4
```

### 3. Weekly Planning Template

```markdown
## Weekly Plan - {Minggu ke-X, Bulan YYYY}

### Goals Minggu Ini:
1. {Goal 1}
2. {Goal 2}
3. {Goal 3}

### Monday
- [ ] 
- [ ] 
- [ ] 

### Tuesday
- [ ] 
- [ ] 

### Wednesday
- [ ] 
- [ ] 

### Thursday
- [ ] 
- [ ] 

### Friday
- [ ] Review mingguan
- [ ] Update laporan
- [ ] Plan minggu depan

### Metrics Minggu Ini:
- Tasks completed: __/__
- Hours worked: __
- Biggest achievement: 
- Blockers encountered: 

### Focus Minggu Depan:
1. 
2. 
```

### 4. Project Management Template

```markdown
## Project: {Nama Project}

### Informasi Umum
- **Kode Project**: PRJ-{YYYY}-{XXX}
- **Project Manager**: {Nama}
- **Timeline**: {Start} - {End}
- **Status**: [ ] Planning [ ] In Progress [ ] On Hold [ ] Completed
- **Prioritas**: Critical / High / Medium / Low

### Tujuan (Goals)
1. 
2. 

### Deliverables
| No | Deliverable | Due Date | Status | Owner |
|----|-------------|----------|--------|-------|
| 1  |             |          |        |       |
| 2  |             |          |        |       |

### Resources
- **Human**: 
- **Budget**: Rp {Amount}
- **Tools**: 

### Timeline & Milestones
```
[ ] Milestone 1 - {Date}
    - Task A
    - Task B
[ ] Milestone 2 - {Date}
    - Task C
    - Task D
```

### Risks & Mitigation
| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
|      |        |             |            |

### Team Members
| Nama | Role | Responsibility |
|------|------|----------------|
|      |      |                |

### Progress Tracking
- Last Updated: {Date}
- Overall Progress: ██░░░░░░░░ 20%
- Last Blockers: 
- Next Actions: 
```

### 5. Meeting Notes Template

```markdown
## Meeting Notes

### Informasi
- **Date**: {Tanggal}
- **Time**: {Waktu}
- **Location**: {Ruang/Link Zoom}
- **Attendees**: 

### Agenda
1. 
2. 
3. 

### Discussion Notes

#### Agenda 1: {Topic}
- Points discussed:
- Decisions made:
- Action items:

#### Agenda 2: {Topic}
- Points discussed:
- Decisions made:
- Action items:

### Decisions Made
1. 
2. 

### Action Items
| No | Action | Owner | Due Date | Status |
|----|--------|-------|----------|--------|
| 1  |        |       |          |        |
| 2  |        |       |          |        |

### Next Meeting
- **Date**: 
- **Time**: 
- **Agenda Topics**: 

---
**Recorded by**: {Nama}
```

## Taskwarrior CLI Guide

```bash
# Install
brew install task  # macOS
sudo apt install taskwarrior  # Ubuntu

# Add task
task add "Review dokumen SPBE" +pemdi due:today +priority:H

# List tasks
task list
task list +pemdi
task list status:pending

# Modify task
task 1 modify +urgent
task 1 modify due:tomorrow
task 1 modify wait:2025-07-01

# Complete task
task 1 done

# Tags
task add "Install server backup" +server +backup

# Projects
task add "Implementasi database" project:spbe.2025

# Report
task summary
task burndown

# Export to CSV
task export > tasks.csv

# Sync (using Taskwarrior Server or Third-party)
task sync http://your-taskd-server
```

## Git-based Task Management

```bash
# Using git-issues or similar

# Create issue
git issue new -t "Implementasi dashboard monitoring" -m "Detail..."

# List issues
git issue list
git issue list --status=open
git issue list --label=bug

# Close issue
git issue close 42

# Add comment
git issue comment 42 -m "Update: sudah selesai testing"

# Create branch from issue
git issue checkout 42  # Creates branch: fix/42-dashboard-monitoring
```

## Pomodoro Technique

```bash
#!/bin/bash
# pomodoro.sh - Simple Pomodoro Timer

WORK_MIN=25
BREAK_MIN=5
LONG_BREAK_MIN=15
CYCLE=4

echo "🍅 Pomodoro Timer Started"

for ((i=1; i<=CYCLE; i++)); do
    echo "🍅 Focus session $i/$CYCLE (${WORK_MIN} min)"
    sleep ${WORK_MIN}m
    
    if [ $i -eq $CYCLE ]; then
        echo "☕ Long break (${LONG_BREAK_MIN} min)"
        sleep ${LONG_BREAK_MIN}m
    else
        echo "☕ Short break (${BREAK_MIN} min)"
        sleep ${BREAK_MIN}m
    fi
done

echo "✅ Pomodoro cycle completed!"
```

## Integration Scripts

### Todoist Integration

```python
#!/usr/bin/env python3
"""
Todoist API Integration
Sync tasks between systems
"""
import os
from todoist_api_python.api import TodoistAPI

TODOIST_API_KEY = os.getenv("TODOIST_API_KEY")
api = TodoistAPI(TODOIST_API_KEY)

def get_today_tasks():
    """Ambil semua tasks untuk hari ini"""
    tasks = api.get_tasks(filter='today')
    return tasks

def create_task(content, due_string=None, project_id=None):
    """Buat task baru di Todoist"""
    task = api.add_task(
        content=content,
        due_string=due_string,
        project_id=project_id
    )
    return task

def sync_from_database():
    """Sync tasks dari database Supabase"""
    from supabase import create_client
    supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
    
    # Ambil tasks yang belum sync
    tasks = supabase.table('tasks').select('*').eq('synced', False).execute()
    
    for task in tasks.data:
        # Create di Todoist
        create_task(
            content=f"[{task['project_code']}] {task['title']}",
            due_string=task['due_date']
        )
        
        # Update sync status
        supabase.table('tasks').update({'synced': True}).eq('id', task['id']).execute()

# Run via cron: */15 * * * * /path/to/todoist_sync.py
```

## Notification & Reminders

### macOS Reminders Integration

```bash
# Using macOS Reminders app
osascript -e 'tell application "Reminders"
    tell list "Work"
        make new reminder with properties {name:"Review laporan", due date:current date}
    end tell
end tell'

# Or using terminal-notifier
brew install terminal-notifier

terminal-notifier -title "🍅 Pomodoro" -message "Break time!" -sound default
```

### Slack Integration

```bash
# Webhook notification to Slack
curl -X POST -H 'Content-type: application/json' \
    --data '{"text": "📋 *Daily Standup* in 5 minutes!
Reminder untuk membahas:
- Progress kemarin
- Plan hari ini
- Blocker?"}' \
    https://hooks.slack.com/services/YOUR/WEBHOOK/URL
```