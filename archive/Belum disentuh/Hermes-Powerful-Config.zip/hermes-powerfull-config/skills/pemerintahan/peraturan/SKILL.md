# SKILL: Pembuatan Peraturan Desa/Kabupaten

## Deskripsi
Skill untuk membantu menyusun draft peraturan daerah (Perda), peraturan bupati (Perbup), keputusan bupati (Kepbup), dan peraturan desa (Perdes) sesuai format resmi Indonesia.

## Referensi Hukum
- UU No. 23 Tahun 2014 tentang Pemerintahan Daerah
- PP No. 12 Tahun 2019 tentang Pengelolaan Keuangan Daerah
- Permendagri No. 80 Tahun 2015 tentang Produk Hukum Daerah (hasil olahan Permendagri terbaru)

## Struktur Umum Peraturan

### HEADER PERATURAN
```
{KOP SURAT/LEMBAGA}
{NOMOR PERATURAN} TAHUN {TAHUN}

tentang
{Judul Peraturan dalam Huruf Kapital}
```

### KONSIDERANS
```
Menimbang:
a. bahwa {alasan 1};
b. bahwa {alasan 2};
dst.

Mengingat:
1. Undang-Undang Nomor ... Tahun ... tentang ...;
2. Peraturan Pemerintah Nomor ... Tahun ...;
3. dst.
```

### PASAL-DPASAL
```
Pasal 1
{Isi ketentuan}

Pasal 2
{Isi ketentuan}
dst.
```

### PENUTUP
```
Pasal N
Peraturan ini mulai berlaku pada tanggal diundangkan.

Ditetapkan di {Kota} 
pada tanggal {Tanggal}

{PEJABAT PENANDATANGAN}

{SPASI 4 CM UNTUK TANDA TANGAN}

{Nama Lengkap}
{NIP}
```

### PENJELASAN
```
PENJELASAN
Terlampir
```

## Format Perbup

### Contoh Perbup tentang SPBE
```
BUPATI ACEH TENGAH
PERATURAN BUPATI ACEH TENGAH NOMOR 18 TAHUN 2024

TENTANG SISTEM PEMERINTAHAN BERBASIS ELEKTRONIK
DALAM RANGKA PENINGKATAN PELAYANAN PUBLIK

DENGAN RAHMAT TUHAN YANG MAHA ESA
BUPATI ACEH TENGAH,

Menimbang:
a. bahwa untuk mewujudkan tata kelola pemerintahan yang good governance dan clean government perlu dukungan teknologi informasi;
b. bahwa Undang-Undang Nomor 23 Tahun 2014 mengamanatkan pembangunan SPBE;
c. dst.

Mengingat:
1. Undang-Undang Nomor 13 Tahun 2003 tentang Pembentukan Kabupaten Aceh Tengah;
2. Undang-Undang Nomor 23 Tahun 2014 tentang Pemerintahan Daerah;
3. dst.

MEMUTUSKAN:

Menetapkan: PERATURAN BUPATI TENTANG SISTEM PEMERINTAHAN BERBASIS ELEKTRONIK.

BAB I
KETENTUAN UMUM

Pasal 1
Dalam Peraturan ini yang dimaksud dengan:
1. Sistem Pemerintahan Berbasis Elektronik yang selanjutnya disingkat SPBE adalah sistem pemerintahan yang menerapkan teknologi informasi dan komunikasi untuk meningatkan kualitas layanan publik;
2. dst.
```

## Format Keputusan Bupati

### Contoh Kepbup tentang Tim
```
KEPUTUSAN BUPATI ACEH TENGAH
NOMOR: 800/KEP/158/2024

TENTANG
PEMBENTUKAN TIM PENGGERAK DIGITALISASI PEMERINTAHAN
KABUPATEN ACEH TENGAH

BUPATI ACEH TENGAH,

Menimbang:
a. bahwa dalam rangka accelerate implementasi SPBE perlu dibentuk tim;
b. dst.

Mengingat:
1. dst.

MEMUTUSKAN:

Menetapkan:
KEPUTUSAN BUPATI TENTANG PEMBENTUKAN TIM PENGGERAK DIGITALISASI

KESATU: Membentuk Tim Penggerak Digitalisasi Pemerintahan Kabupaten Aceh Tengah sebagaimana tercantum dalam Lampiran yang merupakan bagian tidak terpisahkan dari Keputusan ini.

KEDUA: dst.

Ditetapkan di Takengon
pada tanggal 15 Juni 2024

BUPATI ACEH TENGAH,

ttd

MUHAMMAD FAKHRUDDIN, SE
NIP. 19730815 199403 1 004
```

## Format Peraturan Desa

### Contoh Perdes tentang DLH
```
PEMERINTAH DESA {NAMA DESA}
KECAMATAN {KECAMATAN}
KABUPATEN ACEH TENGAH

PERATURAN DESA {NAMA DESA}
NOMOR 3 TAHUN 2024

TENTANG
PENGELOLAAN SAMPAH LINGKUNGAN

DENGAN RAHMAT TUHAN YANG MAHA ESA
KEPALA DESA {NAMA DESA},

Menimbang:
a. bahwa pengelolaan sampah merupakan tanggung jawab bersama;
b. dst.
```

## Tips Penyusunan
1. Selalu cantumkn Nomor Peraturan dengan format: {Kode}/{Jenis}/{Nomor}/{Bulan Romawi}/{Tahun}
2. Gunakan bahasa hukum formal Indonesia
3. Hindari multitafsir - jelas dan tegas
4. Sesuaikan hierarki norma (Undang-Undang → PP → Permen → Perbup/Perda → Kepbup → Perdes)
5. Sertakan قاعدة hukum (dasar hukum) yang relevan
6. Cantumkan modalitas: Wajib, Harus, Tidak boleh, Diperbolehkan
7. Sertakan sanksi bagi pelanggaran
8. Perhatikan aspek legal drafting: kepastian hukum, kejelasan norma, dan enforceability

## Kategori Peraturan yang Sering Dibutuhkan
- Perda: Pajak Daerah, Retribusi, Rencana Tata Ruang
- Perbup: SPBE, Satu Data, Keamanan Siber, PDPP
- Kepbup: Pembentukan Tim, Penetapan Standards, Honorarium
- Perdes: Tanah Kas Desa,垄Asset Desa, Dana Desa