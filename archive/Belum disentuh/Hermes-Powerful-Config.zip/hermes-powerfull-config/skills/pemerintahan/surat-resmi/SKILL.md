# SKILL: Pembuatan Surat Resmi Pemerintahan Indonesia

## Metadata
```yaml
name: surat-resmi-indonesia
description: Membuat surat resmi pemerintahan Indonesia dengan format yang benar
version: 1.0.0
metadata:
  hermes:
    tags: [pemerintah, surat, administrasi, indonesia]
    category: pemerintahan
```

---

## Kapan Menggunakan Skill Ini

Gunakan skill ini ketika user meminta untuk:
- Membuat surat undangan
- Membuat surat edaran
- Membuat nota dinas
- Membuat surat tugas
- Membuat memorandum
- Membuat proposal atau permohonan
- Membuat surat keputusan (SK)
- Membuat peraturan (Perbup, Perda)

## Format Surat Resmi Standar

### Struktur Umum Surat Resmi

```
┌─────────────────────────────────────────────────────────┐
│                    KOP SURAT                            │
│         (Logo + Nama Instansi + Alamat)                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Nomor    : [Nomor Surat]                               │
│  Lampiran : [Jumlah] Lembar                            │
│  Hal      : [Perihal]                                  │
│                                                         │
│  Kepada Yth.                                            │
│  [Penerima]                                             │
│  [Alamat]                                               │
│                                                         │
│  [Isi Surat - dengan struktur yang jelas]              │
│                                                         │
│  Hormat kami,                                           │
│                                                         │
│  [Tanda Tangan]                                         │
│                                                         │
│  [Nama]                                                 │
│  [NIP]                                                  │
│  [Jabatan]                                              │
│                                                         │
│  Tembusan:                                              │
│  1. [Penerima tembusan 1]                               │
│  2. [Penerima tembusan 2]                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Jenis-Jenis Surat dan Format Spesifik

### 1. Surat Undangan

```
Nomor      : [Nomor Surat]
Lampiran   : -
Hal        : Undangan [Judul Kegiatan]

Kepada Yth.
[Nama Penerima]
[Jabatan]
di Tempat

Dengan hormat,

Berdasarkan [alasan/referensi], kami mengundang Bapak/Ibu untuk 
menghadiri kegiatan sebagai berikut:

Hari/Tanggal : [Hari], [Tanggal] [Bulan] [Tahun]
Waktu        : [Waktu] WIB s.d selesai
Tempat       : [Lokasi]
Agenda       : [Deskripsi kegiatan]

Mengingat pentingnya acara tersebut, kami mohon kehadiran Bapak/Ibu 
tepat pada waktu yang telah ditentukan.

Horman kami,
[Nama Jabatan]

[Nama]
NIP. [Nomor NIP]
```

### 2. Nota Dinas

```
NOTA DINAS

Nomor     : [Nomor ND]
Lampiran  : -
Hal       : [Perihal]

Kepada Yth.
[Nama/Jabatan Penerima]
di Tempat

Dari      : [Nama/Jabatan Pengirim]
Tanggal   : [Tanggal]
Sifat     : [Biasa/Penting/Sangat Penting]
Lampiran  : [Jumlah] Berkas

I. MAKSUD DAN TUJUAN
   [Penjelasan maksud dan tujuan]

II. DASAR
   [Referensi dasar pelaksanaan]

III. RUANG LINGKUP
   [Cakupan kegiatan]

IV. PELAKSANAAN
   [Detail pelaksanaan kegiatan]

V. PENUTUP
   [Penutup dan harapan]

Diketahui/Mengesahkan,
[Nama Jabatan]                    Yang menyampaikan,
                                 
[Nama]                           [Nama]
NIP. [NIP]                       NIP. [NIP]
```

### 3. Surat Edaran

```
PEMERINTAH KABUPATEN [NAMA]
DINAS [NAMA DINAS]

SURAT EDARAN
Nomor: [Nomor SE]
Hal   : [Perihal]

Menindaklanjuti [referensi], dengan ini kami sampaikan agar 
[isi edaran] kepada seluruh [target].

Petunjuk:
1. [Petunjuk 1]
2. [Petunjuk 2]
3. [Petunjuk 3]

Demikian untuk menjadi perhatian dan dilaksanakan dengan penuh 
tanggung jawab.

Dikeluarkan di [Kota]
pada tanggal [Tanggal]

[Nama]
NIP. [NIP]
Jabatan: [Jabatan]
```

### 4. Surat Tugas

```
SURAT TUGAS
Nomor: [Nomor ST]

Berdasarkan [referensi], yang bertanda tangan di bawah ini:
Nama        : [Nama Pemberi Tugas]
NIP         : [NIP Pemberi Tugas]
Jabatan     : [Jabatan]
instansi    : [Nama Instansi]

Dengan ini menugaskan:

Nama        : [Nama yang ditugaskan]
NIP         : [NIP]
Jabatan     : [Jabatan]
Pangkat/Gol : [Pangkat/Golongan]

Untuk: [Tugas yang diberikan]
Pada: [Waktu dan Tempat]
Anggaran: [Sumber Anggaran]

Demikian Surat Tugas ini dibuat untuk dapat dilaksanakan 
sebagaimana mestinya.

[Kota], [Tanggal]

Pemberi Tugas,

[Nama]
NIP. [NIP]
```

### 5. Memorandum

```
MEMORANDUM

Kepada   : [Penerima]
Dari     : [Pengirim]
Tanggal  : [Tanggal]
Hal      : [Perihal]

I. MAKSUD
   [Maksud memorandum]

II. DASAR
   [Dasar perhitungan]

III. PERTIMBANGAN
   [Pertimbangan yang ada]

IV. KEPUTUSAN
   [Keputusan yang diambil]

V. PENUTUP
   [Penutup]

Atasan,
   
[Nama]
NIP. [NIP]
```

## Template Umum

### Header/Kop Surat

```
PEMERINTAH KABUPATEN ACEH TENGAH
DINAS KOMUNIKASI DAN INFORMATIKA

Jl. [Alamat] Telp. [Nomor] Fax. [Nomor]
Email: [Email] Website: [Website]
```

### Penutup Formal

```
Demikian surat ini dibuat dengan sebenarnya dan dapat 
dipertanggungjawabkan.

Hormat kami,
[Pejabat yang menandatangani]

[Nama Lengkap]
[NIP]
[Jabatan]
```

## Tips Penting

### ✅ LAKUKAN
1. Selalu gunakan kop surat resmi
2. Cantumkan nomor surat dengan format yang benar
3. Gunakan bahasa Indonesia yang baku
4. Cantumkan tembusan untuk pihak terkait
5. Tanda tangan pejabat berwenang
6. Gunakan format tanggal Indonesia

### ❌ Hindari
1. Typo dan salah penulisan
2. Format yang tidak standar
3. Bahasa yang tidak formal
4. Melewatkan elemen penting (nomor, tanggal, hal)
5. Tanda tangan elektronik yang tidak valid

## Referensi Regulasi

- Permendagri No. 90 Tahun 2019 tentang Klasifikasi Baku Komponen数据
- SE Mendagri No. 500/354/SE/2020 tentang Format Surat Dinas
- Pedoman Tata Naskah Dinas Instansi Pemerintah

---

**Author:** Hermes Niumination  
**Created:** 19 Juni 2026  
**Version:** 1.0.0