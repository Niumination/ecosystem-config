# SKILL: 20 Indikator PEMDI (Pemerintahan Digital)

## Metadata
```yaml
name: 20-indikator-pemdi
description: Guide untuk mencapai dan mengevaluasi 20 Indikator PEMDI (Pemerintahan Digital)
version: 1.0.0
metadata:
  hermes:
    tags: [pemerintah, digital, pemdi, spbe, indikator]
    category: pemerintahan
```

---

## Kapan Menggunakan Skill Ini

Gunakan skill ini untuk:
- Menganalisis kesiapan instansi dalam implementasi PEMDI
- Membuat checklist untuk 20 Indikator PEMDI
- Menyusun rencana perbaikan untuk memenuhi standar
- Membuat laporan evaluasi implementasi PEMDI
- Membantu instansi mencapai maturitas level yang dipersyaratkan

## Latar Belakang

Berdasarkan **PermenPANRB No. 8 Tahun 2026**, evaluasi kinerja pemerintah digital telah berubah dari **Indeks SPBE** menjadi **Indeks PEMDI** (Pemerintahan Digital).

Tujuan: Mengukur keterpaduan layanan digital dan dampaknya bagi masyarakat, bukan hanya penggunaan teknologi.

---

## 7 ASPEK & 20 INDIKATOR PEMDI

### 🏛️ ASPEK 1: TATA KELOLA (10%)

---

#### INDIKATOR 1: Tata Kelola Pemerintah Digital

**Bobot:** [Sesuaikan]

**Deskripsi:** Menilai kesiapan tata kelola dalam implementasi pemerintahan digital.

**Kriteria Penilaian:**
1. Tersedianya Kebijakan/Tata Kelola Digital
   - Rencana Induk SPBE / Transformasi Digital
   - SOP terkait layanan digital
   
2. Kepemimpinan Digital
   - Komitmen pimpinan dalam transformasi digital
   - Pembentukan Tim Kerja SPBE/PEMDI

3. Koordinasi Lintas Sektor
   - Koordinasi dengan instansi terkait
   - Participate dalam forum digital

**Checklist:**
```
[ ] Memiliki Dokumen Rencana Induk SPBE/TIK
[ ] Memiliki SOP Layanan Digital
[ ] Ada tim Pengelola SPBE yang terstruktur
[ ] Ada koordinasi rutin dengan OPD terkait
[ ] Ada laporan evaluasi berkala
```

**Template Dokumen:**
```
TATA KELOLA PEMERINTAH DIGITAL
DINAS KOMUNIKASI DAN INFORMATIKA
KABUPATEN ACEH TENGAH

1. DASAR HUKUM
   - UU No. 23 Tahun 2014 tentang Pemerintahan Daerah
   - PP No. 12 Tahun 2019 tentang Pengelolaan Keuangan Daerah
   - Perpres No. 95 Tahun 2018 tentang SPBE
   - PermenPANRB No. 8 Tahun 2026 tentang PEMDI

2. VISI DAN MISI DIGITAL
   Visi: [Visi Instansi dalam Transformasi Digital]
   Misi: [Misi yang mendukung]
   
3. STRUKTUR PENGELOLA SPBE
   Coordinator SPBE: [Nama]
   Sekretariat: [Nama]
   Tim Teknis: [Daftar Nama]
   
4. ROADMAP TRANSFORMASI DIGITAL
   Tahun 2025-2029
   [Detail roadmap]

5. KOORDINASI LINTAS SEKTOR
   [Daftar instansi terkait dan mekanisme koordinasi]
```

---

#### INDIKATOR 2: Manajemen Layanan Digital Pemerintah

**Deskripsi:** Menilai kualitas pengelolaan layanan digital yang diberikan kepada masyarakat dan stakeholder.

**Kriteria Penilaian:**
1. Ketersediaan Layanan Digital
   - Jumlah layanan yang tersedia secara online
   - Persentase layanan yang fully digital
   
2. Kualitas Layanan
   - User experience dan kemudahan akses
   - Response time layanan
   
3. Monitoring Layanan
   - Sistem feedback pengguna
   - Analisis kepuasan pengguna

**Checklist:**
```
[ ] Katalog layanan digital tersedia dan updated
[ ] Minimal 70% layanan core tersedia online
[ ] Ada sistem feedback pengguna
[ ] Ada metrics kepuasan pengguna
[ ] Ada improvement based on feedback
```

---

### 👥 ASPEK 2: PENYELENGGARA (10%)

---

#### INDIKATOR 3: Kompetensi SDM Digital

**Deskripsi:** Menilai kemampuan sumber daya manusia dalam pengelolaan teknologi digital.

**Kriteria Penilaian:**
1. Ketersediaan SDM
   - Rasio petugas IT terhadap total pegawai
   - Kualifikasi dan sertifikasi SDM IT
   
2. Pengembangan Kompetensi
   - Program pelatihan IT berkala
   - Kesempatan sertifikasi dan training
   
3. Literasi Digital Umum
   - Tingkat kemampuan digital seluruh pegawai
   - Program literasi digital

**Checklist:**
```
[ ] Ada SDM IT yang qualified (minimal 2-3 orang)
[ ] Ada program pelatihan IT yearly
[ ] Minimal 50% pegawai mengikuti training digital
[ ] Ada program sertifikasi (CCNA, MCSA, dll)
[ ] Ada assessment kompetensi digital berkala
```

---

#### INDIKATOR 4: Kolaborasi Pemerintah Digital

**Deskripsi:** Menilai tingkat kolaborasi antar instansi dalam implementasi pemerintah digital.

**Kriteria Penilaian:**
1. Sharing Resources
   - Sharing infrastruktur IT
   - Sharing aplikasi/sistem
   
2. Koordinasi Project
   - Partisipasi dalam project lintas OPD
   - Koordinasi data dan informasi
   
3. Partnership
   - Kolaborasi dengan akademisi
   - Kolaborasi dengan pihak ketiga (vendor)

**Checklist:**
```
[ ] Ada MoU/kerjasama dengan instansi lain
[ ] Ada sharing infrastruktur (cloud, server)
[ ] Ada project lintas OPD yang berjalan
[ ] Ada kolaborasi dengan universitas/institusi
[ ] Ada documented partnership agreements
```

---

### 📊 ASPEK 3: DATA DAN INFORMASI (15%)

---

#### INDIKATOR 5: Tata Kelola Data

**Deskripsi:** Menilai kualitas pengelolaan data pemerintah.

**Kriteria Penilaian:**
1. Kebijakan Data
   - Adanya kebijakan pengelolaan data
   - Standar dan prosedur data
   
2. Kualitas Data
   - Akurasi dan kelengkapan data
   - Konsistensi dan validitas data
   
3. Keamanan Data
   - Kebijakan keamanan data
   - Implementasi security measures

**Checklist:**
```
[ ] Ada kebijakan/data management policy
[ ] Ada standar data (metadata, format)
[ ] Ada database/data warehouse terintegrasi
[ ] Ada data quality monitoring
[ ] Ada backup dan disaster recovery plan
```

---

#### INDIKATOR 6: Informasi Geospasial

**Deskripsi:** Menilai ketersediaan dan kualitas data informasi geospasial.

**Kriteria Penilaian:**
1. Ketersediaan Data Spasial
   - Peta dasar dan peta tematik
   - Data geospasial sesuai standar
   
2. Aksesibilitas
   - Platform sharing data spasial
   - Integrasi dengan portal data

**Checklist:**
```
[ ] Ada bigmap/spatial data tersedia
[ ] Data sesuai standar ISO 19100 series
[ ] Ada metadata lengkap
[ ] Data updated secara berkala
[ ] Ada akses untuk stakeholder
```

---

#### INDIKATOR 7: Statistik Sektoral

**Deskripsi:** Menilai kualitas pengelolaan statistik sektoral.

**Kriteria Penilaian:**
1. Produksi Statistik
   - Ketersediaan data statistik berkualitas
   - Metodologi yang sesuai
   
2. Diseminasi
   - Publikasi data statistik
   - Akses data untuk publik

**Checklist:**
```
[ ] Ada Satu Data Statistik sektoral
[ ] Ada publikasi statistik berkala
[ ] Data sesuai standar BPS
[ ] Ada metadata dan kamus data
[ ] Ada sistem informasi statistik
```

---

#### INDIKATOR 8: Pelindungan Data Pribadi (PDP)

**Deskripsi:** Menilai implementasi perlindungan data pribadi dalam sistem pemerintah.

**Kriteria Penilaian:**
1. Kepatuhan Regulasi
   - Align dengan UU PDP No. 27 Tahun 2022
   - SOP perlindungan data
   
2. Teknis Keamanan
   - Enkripsi data sensitif
   - Access control dan audit trail
   
3. Prosedural
   - Consent management
   - Data breach response plan

**Checklist:**
```
[ ] Ada SOP perlindungan data pribadi
[ ] Ada consentimiento untuk pengumpulan data
[ ] Ada encryption untuk data sensitif
[ ] Ada access control yang ketat
[ ] Ada data breach response plan
[ ] Ada privacy impact assessment
```

---

### 🔒 ASPEK 4: KEAMANAN PEMERINTAH DIGITAL (15%)

---

#### INDIKATOR 9: Audit Keamanan

**Deskripsi:** Menilai pelaksanaan audit keamanan sistem secara berkala.

**Kriteria Penilaian:**
1. Scheduled Audit
   - Audit security rutin (minimal yearly)
   - Review dan assessment berkala
   
2. Remediation
   - Tindak lanjut finding audit
   - Implementasi improvement

**Checklist:**
```
[ ] Ada jadwal audit keamanan tahunan
[ ] Ada laporan audit terdokumentasi
[ ] Ada tracking finding dan remediation
[ ] Ada external audit (minimal 3 tahun)
[ ] Ada security assessment periodik
```

---

#### INDIKATOR 10: Keamanan Siber

**Deskripsi:** Menilai kapabilitas keamanan siber instansi.

**Kriteria Penilaian:**
1. Security Infrastructure
   - Firewall, IDS/IPS, antivirus
   - Monitoring system
   
2. Security Operations
   - SOC atau tim security
   - Incident detection & response
   
3. Security Awareness
   - Training security untuk staff
   - Simulasi phishing test

**Checklist:**
```
[ ] Ada firewall dan security appliances
[ ] Ada intrusion detection/prevention
[ ] Ada security monitoring (SIEM)
[ ] Ada security team/responsibility
[ ] Ada incident response procedure
[ ] Ada security awareness training
```

---

#### INDIKATOR 11: Penerapan Kriptografi

**Deskripsi:** Menilai implementasi kriptografi untuk perlindungan data.

**Kriteria Penilaian:**
1. Data at Rest
   - Enkripsi database dan file sensitif
   - Key management system
   
2. Data in Transit
   - TLS/SSL untuk komunikasi
   - VPN untuk akses remote
   
3. Kriptografi Dokumen
   - Digital signature
   - Enkripsi dokumen rahasia

**Checklist:**
```
[ ] Ada encryption untuk data sensitif (at rest)
[ ] Ada TLS untuk semua web services
[ ] Ada VPN untuk remote access
[ ] Ada digital signature untuk dokumen resmi
[ ] Ada key management procedure
[ ] Ada certified elektronik untuk surat
```

---

#### INDIKATOR 12: Penanganan Insiden Siber

**Deskripsi:** Menilai kapabilitas dalam penanganan insiden keamanan siber.

**Kriteria Penilaian:**
1. CSIRT
   - Tim tanggap insiden siber
   - Prosedur respons insiden
   
2. Detection & Response
   - Kemampuan deteksi insiden
   - Response time dan escalation
   
3. Recovery
   - Business continuity plan
   - Disaster recovery procedure

**Checklist:**
```
[ ] Ada tim CSIRT (Computer Security Incident Response Team)
[ ] Ada SOP penanganan insiden
[ ] Ada incident classification matrix
[ ] Ada escalation procedure
[ ] Ada communication plan saat insiden
[ ] Ada backup dan recovery procedure
[ ] Ada latihan simulasi insiden berkala
```

---

### 💻 ASPEK 5: TEKNOLOGI PEMERINTAH DIGITAL (10%)

---

#### INDIKATOR 13: Aplikasi Pemerintah Digital

**Deskripsi:** Menilai kualitas dan kematangan aplikasi digital pemerintah.

**Kriteria Penilaian:**
1. Ketersediaan Aplikasi
   - Jumlah dan jenis aplikasi
   - Coverage layanan publik
   
2. Kualitas Aplikasi
   - User experience
   - Integrasi dan interoperability
   
3. Maintenance
   - Update dan improvement berkala
   - Technical support

**Checklist:**
```
[ ] Ada aplikasi core untuk layanan utama
[ ] Aplikasi user-friendly dan accessible
[ ] Ada integrasi antar aplikasi
[ ] Ada regular maintenance dan update
[ ] Ada technical support/helpdesk
[ ] Ada mobile version (responsive)
```

---

#### INDIKATOR 14: Infrastruktur Pemerintah Digital

**Deskripsi:** Menilai kualitas infrastruktur TIK pendukung.

**Kriteria Penilaian:**
1. Network Infrastructure
   - Bandwidth dan konektivitas
   - Network security
   
2. Data Center/Server
   - Kapasitas dan reliability
   - Disaster recovery site
   
3. End User Infrastructure
   - Device dan workstation
   - Software licensing

**Checklist:**
```
[ ] Ada bandwidth cukup (>10 Mbps)
[ ] Ada redundancy network (2 ISP min)
[ ] Ada server dengan uptime >99%
[ ] Ada backup site/DR location
[ ] Ada hardware/software inventory
[ ] Ada licensing compliance
```

---

### 🔗 ASPEK 6: KETERPADUAN LAYANAN DIGITAL (15%)

---

#### INDIKATOR 15: Keterpaduan Proses Bisnis

**Deskripsi:** Menilai tingkat integrasi dan keterpaduan proses bisnis digital.

**Kriteria Penilaian:**
1. Process Digitalization
   - Alur proses yang digitized
   - Automasi proses rutin
   
2. End-to-End Integration
   - Integrasi antar proses
   - Seamless workflow

**Checklist:**
```
[ ] Ada business process automation
[ ] Ada integrated workflow system
[ ] Ada process documentation
[ ] Ada continuous improvement process
```

---

#### INDIKATOR 16: Integrasi Aplikasi

**Deskripsi:** Menilai tingkat integrasi antar aplikasi dan sistem.

**Kriteria Penilaian:**
1. API Integration
   - Aplikasi saling terintegrasi
   - Standardized API
   
2. Data Exchange
   - Real-time atau near real-time data exchange
   - Data consistency

**Checklist:**
```
[ ] Ada integration antar aplikasi utama
[ ] Ada standardized API/format
[ ] Ada middleware/API gateway
[ ] Ada data synchronization mechanism
[ ] Ada monitoring untuk integrasi
```

---

#### INDIKATOR 17: Portal Layanan Digital Pemerintah

**Deskripsi:** Menilai kualitas portal/platform layanan digital.

**Kriteria Penilaian:**
1. Portal Availability
   - Single portal untuk layanan
   - 24/7 availability
   
2. Content & Services
   - Informasi lengkap dan updated
   - Self-service capabilities
   
3. User Experience
   - Easy to navigate
   - Accessible (WCAG compliant)

**Checklist:**
```
[ ] Ada single portal layanan digital
[ ] Ada Informasi publik yang lengkap
[ ] Ada layanan transaksi online
[ ] Ada search dan navigation yang baik
[ ] Ada mobile-friendly design
[ ] Ada accessibility compliance
```

---

#### INDIKATOR 18: Interoperabilitas Data

**Deskripsi:** Menilai kemampuan pertukaran data antar sistem/instansi.

**Kriteria Penilaian:**
1. Standards Compliance
   - Gunakan standar data nasional
   - Metadata compliance
   
2. Cross-System Data Exchange
   - Data sharing dengan instansi lain
   - Integrasi dengan portal nasional

**Checklist:**
```
[ ] Ada data dictionary dan metadata
[ ] Ada standardized data format
[ ] Ada API untuk data exchange
[ ] Ada integration dengan data center nasional
[ ] Ada participation dalam Satu Data Indonesia
```

---

### 😊 ASPEK 7: KEPUASAN PENGGUNA (25%)

---

#### INDIKATOR 19: Kapabilitas Sumber Daya Manusia Digital

**Deskripsi:** Menilai kapabilitas dan budaya digital SDM pemerintah.

**Kriteria Penilaian:**
1. Technical Skills
   - Kemampuan teknis IT
   - Digital literacy
   
2. Innovation Culture
   - Budaya inovasi digital
   - Adoption of new technology
   
3. Leadership Digital
   - Komitmen pimpinan
   - Digital transformation leadership

**Checklist:**
```
[ ] Ada assessment kompetensi digital
[ ] Ada program pengembangan kapasitas
[ ] Ada sistem reward untuk inovasi
[ ] Ada Champions/Digital ambassadors
[ ] Ada monitoring budaya digital
```

---

#### INDIKATOR 20: Kapabilitas Kepemimpinan Digital

**Deskripsi:** Menilai kapabilitas pimpinan dalam memimpin transformasi digital.

**Kriteria Penilaian:**
1. Strategic Vision
   - Visi digital yang jelas
   - Alignment dengan national strategy
   
2. Resource Allocation
   - Alokasi anggaran untuk digital
   - Investasi teknologi
   
3. Change Management
   - Kemampuan mengelola perubahan
   - Stakeholder engagement

**Checklist:**
```
[ ] Ada executive sponsorship untuk digital
[ ] Ada digital strategy yang approved
[ ] Ada budget allocation untuk digital
[ ] Ada governance structure yang jelas
[ ] Ada measurable digital KPIs
```

---

## Template Evaluasi PEMDI

```
EVALUASI CAPAIAN 20 INDIKATOR PEMDI
DINAS KOMUNIKASI DAN INFORMATIKA
KABUPATEN ACEH TENGAH
Tahun: [Tahun]

| No | Aspek | Indikator | Bobot | Score (1-5) | Weighted Score |
|----|-------|-----------|-------|-------------|----------------|
| 1  | Tata Kelola | Tata Kelola PD | x% | [1-5] | [Bobot x Score] |
| 2  | Tata Kelola | Manajemen LD | x% | [1-5] | [Bobot x Score] |
| ... | ... | ... | ... | ... | ... |

TOTAL SCORE PEMDI: [Sum Weighted Score]

INTERPRETATION:
- 1.0 - 2.0: Awal
- 2.1 - 3.0: Berkembang
- 3.1 - 4.0: Maju
- 4.1 - 5.0: Utama

RECOMMENDATIONS:
1. [Area perbaikan prioritas]
2. [Action items]
3. [Timeline]
```

---

## Referensi Regulasi

1. PermenPANRB No. 8 Tahun 2026 - Evaluasi Kinerja Pemerintah Digital
2. Perpres No. 12 Tahun 2025 - Transformasi Digital
3. Perpres No. 95 Tahun 2018 - SPBE (sebagian diperbarui)
4. UU No. 27 Tahun 2022 - Pelindungan Data Pribadi
5. PP No. 71 Tahun 2019 - Penyelenggaraan SPBE

---

**Author:** Hermes Niumination  
**Created:** 19 Juni 2026  
**Version:** 1.0.0