# SKILL: Penyusunan Laporan Dinas & Dokumen Kinerja

## Metadata
```yaml
name: laporan-dinas
description: Menyusun laporan dinas, LKIP, LAKIP, dan dokumen kinerja pemerintahan
version: 1.0.0
metadata:
  hermes:
    tags: [pemerintah, laporan, kinerja, administrasi]
    category: pemerintahan
```

---

## Kapan Menggunakan Skill Ini

Gunakan skill ini untuk membuat:
- Laporan Kinerja Instansi Pemerintah (LKIP)
- Laporan Akuntabilitas Kinerja (LAKIP)
- Laporan Pertanggungjawaban (LPJ)
- Laporan Bulanan/Triwulanan/Tahunan
- Laporan Keuangan (LK, LRA, LO)
- Profil Instansi
- Dokumen Evaluasi Kinerja

## Struktur Laporan Kinerja Standar

### Cover/Front Page

```
LAPORAN KINERJA
[INSTANSI PEMERINTAH]

Tahun Anggaran : [Tahun]
Provinsi/Kabupaten : [Wilayah]
Logo Instansi

[Dinas Komunikasi dan Informatika Kabupaten Aceh Tengah]
[Tahun]
```

### BAB I: RINGKASAN EKSEKUTIF

```
1.1 Gambaran Umum Instansi
    - Visi dan Misi
    - Tugas dan Fungsi
    - Struktur Organisasi

1.2 Capaian Kinerja Utama
    - Ringkasan pencapaian target
    - Perbandingan dengan tahun sebelumnya

1.3 Capaian Target Indikator Kinerja
    [Tabel Target vs Realisasi]

1.4 Realisasi Anggaran
    [Tabel pagu vs penyerapan]

1.5 Permasalahan dan Solusi
```

### BAB II: PENDAHULUAN

```
2.1 Latar Belakang
2.2 Maksud dan Tujuan
2.3 Ruang Lingkup
2.4 Sistematika Penulisan
```

### BAB III: PERENCANAAN KINERJA

```
3.1 Rencana Strategis (Renstra)
3.2 Penetapan Kinerja (SKP)
3.3 Indikator Kinerja Utama (IKU)
3.4 Alokasi Anggaran
```

### BAB IV: REALISASI KINERJA

```
4.1 Capaian Setiap Indikator Kinerja
4.2 Analisis Capaian Kinerja
4.3 Perbandingan dengan Target
4.4 Faktor-faktor yang Mempengaruhi
```

### BAB V: REALISASI ANGGARAN

```
5.1 Perbandingan Planning vs Realisasi
5.2 Efisiensi Penggunaan Anggaran
5.3 Hambatan dan Kendala
```

### BAB VI: KEBIJAKAN OPTIMASI

```
6.1 Langkah Optimasi yang Dilakukan
6.2 Efektivitas Kebijakan
6.3 Inovasi yang Dihasilkan
```

### BAB VII: PENUTUP

```
7.1 Kesimpulan
7.2 Saran/Rekomendasi
7.3 Rencana Tindak Lanjut
```

## Format Tabel Target vs Realisasi

```
| No | Indikator Kinerja | Target | Realisasi | % | Keterangan |
|----|-------------------|--------|-----------|---|-------------|
| 1  | [IKU 1]          | [T]   | [R]       | % | [Status]  |
| 2  | [IKU 2]          | [T]   | [R]       | % | [Status]  |
```

## Template Laporan Bulanan

```
LAPORAN BULANAN
DINAS KOMUNIKASI DAN INFORMATIKA
KABUPATEN ACEH TENGAH

Bulan        : [Nama Bulan] [Tahun]
Laporan ke   : [Nomor]

1. KEGIATAN YANG TELAH DILAKSANAKAN
   1.1 [Nama Kegiatan 1]
       - Waktu     : [Tanggal]
       - Tempat    : [Lokasi]
       - Peserta   : [Jumlah orang]
       - Hasil     : [Deskripsi hasil]
   
   1.2 [Nama Kegiatan 2]
       ...

2. CAPAIAN INDIKATOR KINERJA
   [Tabel dengan target dan realiasi]

3. ANGGARAN YANG DIGUNAKAN
   - Pagu        : Rp [Jumlah]
   - Realisasi   : Rp [Jumlah]
   - Persentase  : [%]

4. PERMASALAHAN DAN SOLUSI
   Permasalahan  : [Deskripsi]
   Solusi        : [Langkah yang diambil]

5. RENCANA KEGIATAN BULAN BERIKUTNYA
   - [Kegiatan 1]
   - [Kegiatan 2]

Diketahui,                    Aceh Tengah, [Tanggal]
Kepala Dinas                  Penanggung Jawab,

[Nama]                        [Nama]
NIP. [NIP]                    NIP. [NIP]
```

## Indikator Kinerja Umum untuk Diskominfo

### Bidang Teknologi Informasi
1. Persentase sistem informasi yang terintegrasi
2. Jumlah aplikasi yang dikembangkan
3. Ketersediaan bandwidth internet
4. Uptime server dan sistem

### Bidang Statistik dan Data
1. Tersedianya data sektoral yang akurat
2. PelaksanaanSatu Data Indonesia
3. Kualitas metadata

### Bidang Keamanan Siber
1. Jumlah insiden keamanan
2. Persentase sistem yang ter-audit
3. Ketersediaan disaster recovery

### Bidang Elektronik dan Dokumentasi
1. Persentase arsip yang ter-digitasi
2. Ketersediaan layanan elektronik
3. Response time helpdesk IT

## Tips Penyusunan

### ✅ Best Practices
1. Gunakan data yang akurat dan terverifikasi
2. Sertakan bukti dukung (foto, dokumen)
3. Gunakan visualisasi data (grafik, chart)
4. Ikuti template resmi dari pusat
5. Review dengan atasan sebelum final

### ❌ Hindari
1. Data yang tidak akurat atau manipulatif
2. Target yang tidak realistis
3. Laporan yang copy-paste tanpa analisis
4. Mengabaikan indikator yang tidak tercapai

## Referensi Regulasi

- PermenPANRB No. 8 Tahun 2026 - Evaluasi Kinerja Pemerintah Digital
- PermenPANRB No. 12 Tahun 2015 - Sistem Akuntabilitas Kinerja
- Peraturan Presiden No. 29 Tahun 2014 - Sistem Akuntabilitas Kinerja
- PMK No. XX/PMK.05/2022 - Penyusunan Laporan Keuangan

---

**Author:** Hermes Niumination  
**Created:** 19 Juni 2026  
**Version:** 1.0.0