# 🦕 HERMES POWERFULL CONFIGURATION

## 📋 Deskripsi

Konfigurasi **SANGAT POWERFULL** dan **GRATIS 100%** untuk Hermes Agent dan OpenCode Zen, dirancang khusus untuk kebutuhan sebagai **Pranata Komputer Terampil Gol II/D** di **Diskominfo Kabupaten Aceh Tengah, Indonesia**.

---

## 🎯 Hardware Target

```
┌─────────────────────────────────────────────────────────────┐
│              ThinkPad X13 Yoga Gen 1 - Hackintosh           │
├─────────────────────────────────────────────────────────────┤
│  CPU: Intel i5-10210U (4C/8T, 1.6-4.2GHz)                   │
│  RAM: 16GB DDR4                                             │
│  SSD: 512GB NVMe                                            │
│  OS:  macOS Sequoia 15.0 (Hackintosh)                      │
├─────────────────────────────────────────────────────────────┤
│  AI Tools:                                                  │
│  ├─ Hermes Agent (Nous Research)                            │
│  └─ OpenCode Zen ⭐ (PREFERRED - Higher Limits)             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start (5 Menit)

### 1. Clone / Download Konfigurasi
```bash
git clone https://github.com/niumination/hermes-agent-config.git
cd hermes-agent-config
```

### 1b. Atau buat baru dari nol:
```bash
mkdir hermes-powerfull-config && cd hermes-powerfull-config
# Copy semua file dari konfigurasi yang sudah ada
git init
git remote add origin https://github.com/niumination/hermes-agent-config.git
```

### 2. Jalankan Setup Script
```bash
chmod +x setup/hermes-setup.sh
chmod +x setup/install-mcp-servers.sh
./setup/hermes-setup.sh
```

### 3. Edit API Keys
```bash
cp .env .env.local  # atau nano ~/.hermes/.env
# Isi: OPENROUTER_API_KEY, GROQ_API_KEY, GITHUB_TOKEN, dll
```

### 4. Mulai Menggunakan

**Hermes Agent:**
```bash
hermes chat --model openrouter/free
```

**OpenCode Zen (PREFERRED untuk coding):**
```bash
# Install dulu
npm install -g opencode-ai

# Start
opencode --config opencode-zen-config.json

# Atau dengan specific model
opencode -m opencode/big-pickle "build government portal"
```

---

## 🤖 Dual AI System

### Hermes Agent
- Untuk: Planning, dokumen, administrasi, brainstorming
- Model default: `openrouter/free`
- Strength: Dokumentasi, surat resmi, laporan

### OpenCode Zen ⭐ (REKOMENDASI)
- Untuk: Coding, debugging, refactoring, complex tasks
- Model preferred: `opencode/big-pickle` atau `opencode/gemini-2.5-pro`
- Strength: Context panjang, limit lebih tinggi, coding-optimized

---

## 🎓 Skills Library (13 Skills)

### 📁 pemerintahan/ (4 skills)
| Skill | Lines | Status |
|-------|-------|--------|
| **surat-resmi** | 280 | ✅ |
| **laporan-dinas** | 212 | ✅ |
| **peraturan** | 178 | ✅ |
| **pemdi-indikator** | 675 | ✅ |

### 📁 teknologi/ (7 skills)
| Skill | Lines | Status |
|-------|-------|--------|
| **web-development** | 2999 | ✅ |
| **ui-ux-design** | 2173 | ✅ NEW |
| **hackintosh** | 1800+ | ✅ NEW |
| **keamanan-siber** | 324 | ✅ |
| **sistem-automation** | 441 | ✅ |
| **database-management** | 460 | ✅ |
| **mcp-servers** | ~400 | ✅ |

### 📁 productivity/ (1 skill)
| Skill | Lines | Status |
|-------|-------|--------|
| **task-management** | 439 | ✅ |

---

## 🛠️ MCP Servers (25+ FREE)

### Install Semua MCP Servers
```bash
./setup/install-mcp-servers.sh
```

### Core Servers (Wajib - 13 Servers)
| MCP Server | Fungsi |
|------------|--------|
| **filesystem** | File read/write/search |
| **github** | Repository management |
| **playwright** | Browser automation |
| **sequential-thinking** | Enhanced reasoning |
| **memory** | Persistent memory |
| **postgres** | Database operations |
| **brave-search** | Web search |
| **google-workspace** | Gmail, Drive, Calendar |

### Remote Servers (Tanpa install!)
| Server | URL |
|--------|-----|
| **Supabase** | https://mcp.supabase.com/mcp |
| **Sentry** | https://mcp.sentry.dev/mcp |
| **Atlassian** | https://mcp.atlassian.com/v1/mcp |
| **Cloudflare** | https://mcp.cloudflare.com/mcp |

### Indonesian Government APIs (Direct HTTP)
```
✅ Satu Data (data.go.id)     - Open Data Portal
✅ BMKG (data.bmkg.go.id)     - Earthquake + Weather
✅ BNPB (dibi.bnpb.go.id)      - Disaster data
✅ Bank Indonesia             - Exchange rates
```

---

## 📁 Dokumen Pendukung

| File | Description |
|------|-------------|
| `AUDIT.md` | Comprehensive audit report (32 issues found & fixed) |
| `BACKLOG.md` | Project backlog (47 items) |
| `CHANGELOG.md` | Version history |
| `docs/troubleshooting.md` | Troubleshooting guide |
| `skills/README.md` | Skills index |

---

## 📤 Deploy ke GitHub

```bash
# Initialize Git
git init
git add .
git commit -m "feat: Hermes Powerfull Config v1.0 - Complete Free AI Setup

- 12 Skills (government, tech, productivity)
- 25+ MCP Servers configured
- OpenCode Zen + Hermes Agent dual system
- Indonesian Government APIs integrated
- Complete documentation & CI/CD"

# Push to GitHub (pastikan token sudah di-set)
git branch -M main
git push -u origin main

# Atau jika repo sudah ada:
git remote set-url origin https://github.com/niumination/hermes-agent-config.git
git push -u origin main
```

---

## 📊 Statistics (v1.0.1)

| Metric | Count |
|--------|-------|
| Total Files | 25 |
| Total Lines | ~15,000+ |
| Total Skills | 13 |
| MCP Servers Configured | 25+ |
| Documentation Pages | 8 |
| Last Updated | 20 Juni 2026 |

---

## 🔄 Recent Updates (v1.0.1 - 20 Juni 2026)

- ✅ UI/UX Design Skill (2173 lines) - Design System complete
- ✅ Hackintosh Skill (1800+ lines) - ThinkPad X13 Yoga setup
- ✅ MCP Servers Skill - Indonesian Government APIs
- ✅ OpenCode Zen Configuration - Fixed model names
- ✅ Environment Variables - Standardized naming
- ✅ Audit Report - 32 issues found and fixed
- ✅ Backlog & Changelog - Project management complete

---

## 🙏 Credits

- **Hermes Agent**: [Nous Research](https://github.com/nousresearch/hermes-agent)
- **OpenCode Zen**: [OpenCode.ai](https://opencode.ai)
- **Configuration**: [Niumination](https://github.com/niumination)
- **UI/UX Reference**: [ui-ux-pro-max-skill](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill)
- **Indonesian Gov APIs**: [suryast/indonesia-gov-apis](https://github.com/suryast/indonesia-gov-apis)

---

## 📜 Lisensi

MIT License - Bebas digunakan, dimodifikasi, dan didistribusikan.

---

<div align="center">
  
**🦕 Hermes Agent + OpenCode Zen = Maximum Productivity**

Made with ❤️ for Indonesian Government IT  
Niumination - Pranata Komputer Diskominfo Aceh Tengah
  
</div>