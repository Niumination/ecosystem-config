#!/bin/bash
# ==============================================================================
# MCP SERVERS INSTALLATION SCRIPT
# For: Niumination - Hermes Agent + OpenCode Zen
# Target: Indonesian Government + Development Workflow
# ==============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   MCP SERVERS INSTALLATION${NC}"
echo -e "${BLUE}   Indonesian Government + Dev Workflow${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js not found. Please install Node.js first.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Node.js version: $(node --version)${NC}"

# Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}✗ npm not found.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ npm version: $(npm --version)${NC}"
echo ""

# Create MCP servers directory
MCP_DIR="$HOME/.hermes/mcp-servers"
mkdir -p "$MCP_DIR"

echo -e "${YELLOW}[1/3] Installing CORE MCP Servers...${NC}"
echo ""

# Core MCP Servers (Official MCP)
CORE_SERVERS=(
    "@modelcontextprotocol/server-filesystem:$HOME"
    "@modelcontextprotocol/server-github"
    "@modelcontextprotocol/server-playwright"
    "@modelcontextprotocol/server-sequential-thinking"
    "@modelcontextprotocol/server-memory"
    "@modelcontextprotocol/server-brave-search"
    "@modelcontextprotocol/server-postgres"
    "@modelcontextprotocol/server-google-workspace"
)

for server in "${CORE_SERVERS[@]}"; do
    IFS=':' read -r package path <<< "$server"
    if [ -z "$path" ]; then
        echo -e "  📦 Installing $package..."
        npm install -g "$package" 2>/dev/null || echo -e "  ⚠️ $package (may need manual config)"
    else
        echo -e "  📦 Installing $package with path: $path..."
        npm install -g "$package" 2>/dev/null || echo -e "  ⚠️ $package (may need manual config)"
    fi
done

echo ""
echo -e "${YELLOW}[2/3] Installing ADDITIONAL MCP Servers...${NC}"
echo ""

# Additional MCP Servers
ADDITIONAL_SERVERS=(
    "@QuantGeekDev/docker-mcp"
    "@modelcontextprotocol/server-fetch"
    "@modelcontextprotocol/server-sqlite"
    "@kimtaeyoon83/mcp-server-youtube-transcript"
)

for server in "${ADDITIONAL_SERVERS[@]}"; do
    echo -e "  📦 Installing $server..."
    npm install -g "$server" 2>/dev/null || echo -e "  ⚠️ $server (may need manual config)"
done

echo ""
echo -e "${YELLOW}[3/3] Verifying Installation...${NC}"
echo ""

# Check installed packages
echo -e "${GREEN}Installed MCP packages:${NC}"
npm list -g --depth=0 2>/dev/null | grep -E "(mcp|@modelcontextprotocol|@QuantGeekDev)" || echo "  No MCP packages found in global"

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}   MCP INSTALLATION COMPLETE!${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

echo -e "${YELLOW}Next steps:${NC}"
echo ""
echo -e "1. ${GREEN}Add to ~/.hermes/config.yaml:${NC}"
echo ""
cat << 'EOF'
mcp_servers:
  filesystem:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-filesystem", "/home/user"]
  github:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-github"]
    env:
      GITHUB_PERSONAL_ACCESS_TOKEN: "${GITHUB_TOKEN}"
  playwright:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-playwright"]
  postgres:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-postgres"]
    env:
      DATABASE_URL: "${SUPABASE_DB_URL}"
  supabase:
    url: "https://mcp.supabase.com/mcp"
  docker:
    command: "npx"
    args: ["-y", "@QuantGeekDev/docker-mcp"]
  sqlite:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-sqlite", "~/.hermes/data.db"]
EOF

echo ""
echo -e "2. ${GREEN}Indonesian Government APIs:${NC}"
echo "   Reference: https://github.com/suryast/indonesia-gov-apis"
echo "   - Satu Data (data.go.id) - Direct API"
echo "   - BMKG (data.bmkg.go.id) - Direct API"
echo "   - BNPB (dibi.bnpb.go.id) - Direct API"
echo ""
echo -e "3. ${GREEN}Restart Hermes:${NC}"
echo "   hermes chat"
echo ""

echo -e "${BLUE}✅ Happy coding! 🚀${NC}"