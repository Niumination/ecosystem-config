#!/bin/bash
# ==============================================================================
# HERMES POWERFULL CONFIG - VERIFICATION SCRIPT
# Run this to verify all configuration is correct
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   HERMES POWERFULL - VERIFICATION${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

PASS=0
FAIL=0

# Helper function
check() {
    local name="$1"
    local result="$2"
    if [ "$result" = "PASS" ]; then
        echo -e "✅ $name"
        PASS=$((PASS + 1))
    else
        echo -e "❌ $name: $result"
        FAIL=$((FAIL + 1))
    fi
}

# 1. Check files exist
echo -e "${YELLOW}[1] Checking file structure...${NC}"
[ -f "config.yaml" ] && check "config.yaml exists" "PASS" || check "config.yaml missing" "FAIL"
[ -f "SOUL.md" ] && check "SOUL.md exists" "PASS" || check "SOUL.md missing" "FAIL"
[ -f "opencode-zen-config.json" ] && check "opencode-zen-config.json exists" "PASS" || check "opencode-zen-config.json missing" "FAIL"
[ -f ".env" ] && check ".env exists" "PASS" || check ".env missing" "FAIL"

# 2. Check YAML validity
echo -e "${YELLOW}[2] Checking YAML...${NC}"
python3 -c "import yaml; yaml.safe_load(open('config.yaml'))" 2>/dev/null && \
    check "config.yaml valid YAML" "PASS" || check "config.yaml invalid" "FAIL"

# 3. Check JSON validity
echo -e "${YELLOW}[3] Checking JSON...${NC}"
python3 -c "import json; json.load(open('opencode-zen-config.json'))" 2>/dev/null && \
    check "opencode-zen-config.json valid JSON" "PASS" || check "opencode-zen-config.json invalid" "FAIL"

# 4. Check skills
echo -e "${YELLOW}[4] Checking skills...${NC}"
skill_count=$(find skills -name "SKILL.md" 2>/dev/null | wc -l)
[ "$skill_count" -ge 10 ] && check "Skills present ($skill_count skills)" "PASS" || check "Skills missing" "FAIL"

# 5. Check skill headers
echo -e "${YELLOW}[5] Checking skill headers...${NC}"
bad_headers=0
for skill in $(find skills -name "SKILL.md" 2>/dev/null); do
    first=$(head -1 "$skill" 2>/dev/null)
    if ! echo "$first" | grep -q "^# SKILL:"; then
        bad_headers=$((bad_headers + 1))
        echo "   ❌ Bad header in: $skill"
    fi
done
[ "$bad_headers" -eq 0 ] && check "All skill headers valid ($skill_count skills)" "PASS" || check "Bad skill headers: $bad_headers" "FAIL"

# 6. Check scripts
echo -e "${YELLOW}[6] Checking scripts...${NC}"
bash -n setup/hermes-setup.sh 2>/dev/null && check "hermes-setup.sh syntax OK" "PASS" || check "hermes-setup.sh syntax error" "FAIL"
bash -n setup/install-mcp-servers.sh 2>/dev/null && check "install-mcp-servers.sh syntax OK" "PASS" || check "install-mcp-servers.sh syntax error" "FAIL"

# 7. Check documentation
echo -e "${YELLOW}[7] Checking documentation...${NC}"
[ -f "README.md" ] && check "README.md exists" "PASS" || check "README.md missing" "FAIL"
[ -f "AUDIT.md" ] && check "AUDIT.md exists" "PASS" || check "AUDIT.md missing" "FAIL"
[ -f "BACKLOG.md" ] && check "BACKLOG.md exists" "PASS" || check "BACKLOG.md missing" "FAIL"

# 8. Check env variables
echo -e "${YELLOW}[8] Checking env variables...${NC}"
grep -q "OPENROUTER_API_KEY" .env && check "OPENROUTER_API_KEY defined" "PASS" || check "OPENROUTER_API_KEY missing" "FAIL"
grep -q "GROQ_API_KEY" .env && check "GROQ_API_KEY defined" "PASS" || check "GROQ_API_KEY missing" "FAIL"
grep -q "GITHUB_TOKEN" .env && check "GITHUB_TOKEN defined" "PASS" || check "GITHUB_TOKEN missing" "FAIL"

# Summary
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   VERIFICATION SUMMARY${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "✅ Passed: $PASS"
echo -e "❌ Failed: $FAIL"
echo ""

if [ $FAIL -eq 0 ]; then
    echo -e "${GREEN}🎉 ALL CHECKS PASSED!${NC}"
    echo -e "${GREEN}Configuration is ready for deployment.${NC}"
    exit 0
else
    echo -e "${RED}⚠️  SOME CHECKS FAILED${NC}"
    echo -e "${RED}Please fix the issues above before deploying.${NC}"
    exit 1
fi