#!/bin/bash
# ==============================================================================
# HERMES AGENT - POWERFULL CONFIGURATION SETUP SCRIPT
# Untuk: ThinkPad X13 Yoga Gen 1, Hackintosh, 16GB RAM
# Dibuat untuk: Niumination (Pranata Komputer Terampil, Diskominfo Aceh Tengah)
# ==============================================================================

set -e  # Exit on error

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
REPO_URL="https://github.com/niumination/hermes-powerfull-config.git"
CONFIG_DIR="$HOME/hermes-powerfull-config"
BACKUP_DIR="$HOME/.hermes-backup-$(date +%Y%m%d%H%M%S)"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   HERMES POWERFULL CONFIG SETUP${NC}"
echo -e "${BLUE}   ThinkPad X13 Yoga Gen 1 - Hackintosh${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check for required tools
check_requirements() {
    echo -e "${YELLOW}[1/8] Checking requirements...${NC}"
    
    # Check git
    if ! command -v git &> /dev/null; then
        echo -e "${RED}✗ Git not found. Installing...${NC}"
        if [[ "$OSTYPE" == "darwin"* ]]; then
            brew install git
        else
            sudo apt update && sudo apt install git
        fi
    fi
    
    # Check curl
    if ! command -v curl &> /dev/null; then
        echo -e "${RED}✗ curl not found. Installing...${NC}"
        if [[ "$OSTYPE" == "darwin"* ]]; then
            brew install curl
        else
            sudo apt update && sudo apt install curl
        fi
    fi
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}✗ Python3 not found. Installing...${NC}"
        if [[ "$OSTYPE" == "darwin"* ]]; then
            brew install python@3.11
        else
            sudo apt update && sudo apt install python3 python3-pip
        fi
    fi
    
    echo -e "${GREEN}✓ Requirements OK${NC}"
    echo ""
}

# Backup existing config
backup_existing() {
    echo -e "${YELLOW}[2/8] Backing up existing Hermes config...${NC}"
    
    if [ -d "$HOME/.hermes" ]; then
        echo -e "${YELLOW}Found existing .hermes directory. Creating backup...${NC}"
        mkdir -p "$BACKUP_DIR"
        cp -r "$HOME/.hermes" "$BACKUP_DIR/"
        echo -e "${GREEN}✓ Backup created at: $BACKUP_DIR${NC}"
    else
        echo -e "${YELLOW}No existing .hermes directory found. Skipping backup.${NC}"
    fi
    echo ""
}

# Install Hermes Agent
install_hermes() {
    echo -e "${YELLOW}[3/8] Installing Hermes Agent...${NC}"
    
    if command -v hermes &> /dev/null; then
        echo -e "${GREEN}✓ Hermes already installed${NC}"
        echo -e "${YELLOW}  Updating Hermes...${NC}"
        hermes update 2>/dev/null || echo "Update skipped"
    else
        echo -e "${YELLOW}Installing Hermes Agent...${NC}"
        curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
        
        # Source bashrc
        if [ -f "$HOME/.bashrc" ]; then
            source "$HOME/.bashrc"
        fi
        
        # Add to PATH if needed
        export PATH="$HOME/.hermes/bin:$PATH"
    fi
    
    echo ""
}

# Clone/download configuration
get_config() {
    echo -e "${YELLOW}[4/8] Downloading configuration files...${NC}"
    
    # Create config directory
    mkdir -p "$CONFIG_DIR"
    
    # Clone from GitHub if repository exists, else prompt to create
    if git ls-remote --heads --quiet "$REPO_URL" 2>/dev/null; then
        if [ -d "$CONFIG_DIR/.git" ]; then
            cd "$CONFIG_DIR" && git pull
        else
            git clone "$REPO_URL" "$CONFIG_DIR"
        fi
    else
        echo -e "${YELLOW}Config repo not found. Creating local config...${NC}"
    fi
    
    echo -e "${GREEN}✓ Configuration files ready${NC}"
    echo ""
}

# Setup Hermes configuration
setup_hermes_config() {
    echo -e "${YELLOW}[5/8] Setting up Hermes configuration...${NC}"
    
    # Create .hermes directory
    mkdir -p "$HOME/.hermes"
    mkdir -p "$HOME/.hermes/memories"
    mkdir -p "$HOME/.hermes/skills"
    mkdir -p "$HOME/.hermes/cron"
    mkdir -p "$HOME/.hermes/sessions"
    
    # Copy configuration files
    echo -e "${YELLOW}  Copying config files...${NC}"
    
    # Main config
    if [ -f "$CONFIG_DIR/config.yaml" ]; then
        cp "$CONFIG_DIR/config.yaml" "$HOME/.hermes/config.yaml"
    fi
    
    # SOUL
    if [ -f "$CONFIG_DIR/SOUL.md" ]; then
        cp "$CONFIG_DIR/SOUL.md" "$HOME/.hermes/SOUL.md"
    fi
    
    # Memories
    if [ -d "$CONFIG_DIR/memories" ]; then
        cp "$CONFIG_DIR/memories/"* "$HOME/.hermes/memories/"
    fi
    
    # Skills
    if [ -d "$CONFIG_DIR/skills" ]; then
        cp -r "$CONFIG_DIR/skills/"* "$HOME/.hermes/skills/"
    fi
    
    # Cron jobs
    if [ -d "$CONFIG_DIR/cron" ]; then
        cp -r "$CONFIG_DIR/cron/"* "$HOME/.hermes/cron/"
    fi
    
    echo -e "${GREEN}✓ Configuration files copied${NC}"
    echo ""
}

# Setup environment variables
setup_env() {
    echo -e "${YELLOW}[6/8] Setting up environment variables...${NC}"
    
    # Create .env file
    ENV_FILE="$HOME/.hermes/.env"
    
    if [ -f "$CONFIG_DIR/.env" ]; then
        cp "$CONFIG_DIR/.env" "$ENV_FILE"
        echo -e "${YELLOW}  Copied .env from config (PLEASE EDIT WITH YOUR KEYS)${NC}"
    else
        # Create template .env
        cat > "$ENV_FILE" << 'EOF'
# ==============================================================================
# HERMES AGENT - Environment Variables
# IMPORTANT: Replace placeholder values with your actual API keys
# ==============================================================================

# OpenRouter (https://openrouter.ai) - RECOMMENDED - Best free models
OPENROUTER_API_KEY=sk-or-v1-your-key-here

# Groq (https://console.groq.com) - FAST, 14,400 req/day free
GROQ_API_KEY=gsk_your-key-here

# Google AI Studio (https://aistudio.google.com) - 1M tokens/min free
GOOGLE_API_KEY=your-google-api-key

# DeepSeek (https://platform.deepseek.com) - Cheap & good
DEEPSEEK_API_KEY=sk-your-key-here

# GitHub (for MCP server)
GITHUB_TOKEN=ghp_your-token-here

# Supabase (for database)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-or-service-key

# Tavily (for web search)
TAVILY_API_KEY=tvly-your-key-here

# Brave Search (for web search)
BRAVE_SEARCH_API_KEY=your-brave-key

# Ollama (for local models)
OLLAMA_BASE_URL=http://localhost:11434

# Telegram (for notifications)
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# User Info
USER_NAME=Niumination
USER_ROLE=Pranata Komputer Terampil Gol II/D
USER_ORG=Diskominfo Kabupaten Aceh Tengah
USER_LOCATION=Timur, Indonesia
EOF
    fi
    
    echo -e "${YELLOW}  ⚠️  Please edit $ENV_FILE and add your API keys${NC}"
    echo ""
}

# Install Python dependencies
install_dependencies() {
    echo -e "${YELLOW}[7/8] Installing Python dependencies...${NC}"
    
    # Install via uv (Hermes package manager)
    cd "$HOME/.hermes/hermes-agent" 2>/dev/null || true
    
    if command -v uv &> /dev/null; then
        uv pip install -e ".[mcp]" 2>/dev/null || echo "MCP install skipped"
    fi
    
    # Install additional packages
    pip3 install --quiet \
        supabase \
        python-dotenv \
        httpx \
        python-telegram-bot \
        schedule
    
    echo -e "${GREEN}✓ Dependencies installed${NC}"
    echo ""
}

# Install Ollama for local models (optional)
install_ollama() {
    echo -e "${YELLOW}[8/8] Setting up Ollama for local models (optional)...${NC}"
    
    read -p "Do you want to install Ollama for local AI models? (y/n): " -n 1 -r
    echo ""
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if command -v ollama &> /dev/null; then
            echo -e "${GREEN}✓ Ollama already installed${NC}"
        else
            echo -e "${YELLOW}Installing Ollama...${NC}"
            curl -fsSL https://ollama.com/install.sh | sh
            
            # Pull recommended model for 16GB RAM
            echo -e "${YELLOW}Pulling Qwen3 4B model (fits in 16GB RAM)...${NC}"
            ollama pull qwen3:4b
            
            echo -e "${GREEN}✓ Ollama setup complete${NC}"
        fi
    fi
    
    echo ""
}

# Final setup
final_setup() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${GREEN}   SETUP COMPLETE!${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
    
    echo -e "${YELLOW}Next steps:${NC}"
    echo ""
    echo -e "1. ${GREEN}Edit your API keys:${NC}"
    echo "   nano ~/.hermes/.env"
    echo ""
    echo -e "2. ${GREEN}Start Hermes:${NC}"
    echo "   hermes chat"
    echo ""
    echo -e "3. ${GREEN}Select a free model:${NC}"
    echo "   hermes model set openrouter/free"
    echo ""
    echo -e "4. ${GREEN}View available skills:${NC}"
    echo "   hermes skills list"
    echo ""
    echo -e "5. ${GREEN}Enable MCP servers:${NC}"
    echo "   hermes mcp add filesystem"
    echo "   hermes mcp add github"
    echo "   hermes mcp add playwright"
    echo ""
    echo -e "${YELLOW}Configuration backup location:${NC} $BACKUP_DIR"
    echo ""
    echo -e "${BLUE}Happy automating! 🚀${NC}"
}

# Run all steps
main() {
    check_requirements
    backup_existing
    install_hermes
    get_config
    setup_hermes_config
    setup_env
    install_dependencies
    install_ollama
    final_setup
}

# Run
main "$@"