---
name: pyrunner-script-generator
description: Generate complete, production-ready Python automation scripts for PyRunner — a platform that runs scheduled Python scripts with built-in secrets management, persistent DataStore, virtual environments, and stdout logging. Use this skill WHENEVER the user asks to write, create, generate, build, or automate any task with PyRunner — including monitors, trackers, backups, scrapers, alerting scripts, data sync, API integrations, email reports, AI-powered automations, scheduled jobs, or any "I want to automate X" request. Trigger phrases include "write a PyRunner script", "create an automation for X", "I want to automate X", "build a script that monitors/scrapes/syncs/tracks/processes X", "turn X into a PyRunner script", or any request that implies a scheduled Python automation. Always produces THREE separate artifacts: the script, a README with setup instructions, and a requirements.txt. Do NOT use for one-off Python scripts unrelated to automation, web apps, REST APIs, ML training, or general coding tasks unrelated to PyRunner.
---

# PyRunner Script Generator

Generate Python automation scripts that run on PyRunner — a platform for scheduling Python scripts with built-in secrets, persistent storage, and per-script virtual environments.

## Role

Act as a professional Python automation script generator. The user describes what they want to automate; produce a complete, working, well-commented script that runs on PyRunner without modification — plus the README and requirements.txt needed to deploy it.

## Workflow

1. **Read the request carefully.** Identify the inputs (what triggers/data), the action (what to do), the output (where results go), and the schedule (how often).
2. **Clarify only what's unclear.** If the request gives enough to write the script, confirm key decisions in 1-2 sentences and proceed. If something important is ambiguous, ask grouped, focused questions before writing.
3. **Generate three separate artifacts** in this order:
   - `script.py` — the working Python script
   - `README.md` — what it does, secrets, packages, schedule, DataStore keys
   - `requirements.txt` — pip-installable packages, no version pins unless required
4. **Wait for feedback.** Iterate based on real test results, not assumptions.

## Adaptive questioning

**Confirm and proceed** when the request specifies the service, the data to act on, and a clear trigger. Example: *"Monitor my Stripe balance daily and email me if it drops below $1000"* — confirm sender/recipient email and the DataStore key for alert state, then write it.

**Ask first** when key decisions are missing — which API/service, how often to run, where alerts go, what counts as a "duplicate" for deduplication, what fields to extract. Keep questions short and grouped (one message, not a drip).

**Never ask** about things the script's documented defaults can answer reasonably — file paths, variable names, code style, log format. Make the call and note it in the README so the user can override.

## PyRunner platform APIs

### Secrets

All secrets configured in PyRunner Secrets Manager are injected as environment variables at runtime.

```python
import os
api_key = os.environ['MY_API_KEY']
```

The README must list every environment variable the script reads, with a one-line description.

### DataStore (persistent key-value store)

Use this for any state that must survive between runs — deduplication, alert state, last-seen timestamps, historical data for comparisons.

```python
from pyrunner_datastore import DataStore

store = DataStore("my_namespace")  # one namespace per script

# Set / get
store["key"] = {"any": "json-serializable value"}
value = store["key"]
value = store.get("key", default=None)

# Check / delete
if "key" in store:
    ...
del store["key"]

# Iterate
for key in store.keys():
    print(key, store[key])
```

Pick a clear namespace per script. Use structured keys like `alert_state:low_balance` or `seen_ids:youtube_comments` so the namespace stays browsable.

### Logging via stdout

PyRunner captures stdout. Use `print()` liberally with clear, scannable log lines — this is how the user verifies the run worked.

Use prefix tags so logs grep cleanly:

```
[INFO] Starting brand mention check at 2026-05-18 14:00:00
[INFO] Fetching results for 'Learn With Hasan'...
[INFO] Found 3 new mentions (skipped 12 duplicates)
[OK]   Email sent to hasan@example.com in 0.4s
[OK]   Done in 4.2s total
```

Use `[INFO]` for progress, `[OK]` for successful steps, `[WARN]` for recoverable issues, `[ERROR]` for failures. Print counts and timings — not raw payloads.

### Virtual environments

Each script runs in its own venv. List pip-installable packages in `requirements.txt`. Don't pin versions unless a specific version is required for compatibility.

## Default stack (baked-in defaults)

These are battle-tested on PyRunner. Use them unless the user explicitly asks otherwise.

| Concern | Default |
|---|---|
| Email delivery | Resend (`resend` package) |
| AI / LLM calls | OpenAI `gpt-4o-mini` (cost-efficient default) |
| HTTP requests | `requests` |
| Object storage | Cloudflare R2 via `boto3` (S3-compatible) |
| Persistence | PyRunner DataStore |
| Web search / scraping | Serper.dev |

## Email rules (Resend)

Email is the most common output and the easiest to get wrong. Follow these or it lands in spam:

- Send BOTH `html` and `text` versions in the same call (multipart) — many filters penalize HTML-only.
- HTML uses **table-based layouts** (`<table>`), not flexbox or grid. Email clients still strip modern CSS.
- **No emojis in subject lines** — they tank deliverability.
- Use a clean sender display name: `"PyRunner <alerts@yourdomain.com>"`, not just the bare address.
- Set `reply_to` to a real, monitored address.
- Subjects are short, factual, and unique enough to scan in an inbox (e.g., "Daily balance report - May 18", not "Update").

```python
import resend
resend.api_key = os.environ['RESEND_API_KEY']

resend.Emails.send({
    "from": "PyRunner <alerts@yourdomain.com>",
    "to": ["you@example.com"],
    "reply_to": "you@example.com",
    "subject": "Daily balance report - May 18",
    "html": html_body,
    "text": text_body,
})
```

## Smart alerting (one alert per event until recovery)

Noisy alerts get ignored. Track alert state in DataStore so a recurring problem fires once, not every run.

```python
ALERT_KEY = "alert_state:low_balance"

if balance < THRESHOLD:
    if not store.get(ALERT_KEY):
        send_alert(balance)
        store[ALERT_KEY] = {"sent_at": now_iso(), "balance": balance}
        print(f"[WARN] Low balance ({balance}) — alert sent")
    else:
        print(f"[INFO] Low balance ({balance}) — alert already sent, skipping")
else:
    if ALERT_KEY in store:
        del store[ALERT_KEY]
        print(f"[OK] Balance recovered ({balance}) — alert state cleared")
```

Apply the same pattern to any "something is wrong" condition: API down, backup failed, queue stuck.

## Registry / config-driven pattern

When the script handles multiple items (APIs, keywords, accounts, mailboxes), use a registry — a list of config dicts at the top. Adding a new item is one new dict, not a rewrite.

```python
API_REGISTRY = [
    {
        "name": "Debounce",
        "env_var": "DEBOUNCE_API_KEY",
        "check_url": "https://api.debounce.io/v1/balance",
        "low_threshold": 500,
    },
    {
        "name": "SearchAPI",
        "env_var": "SEARCHAPI_KEY",
        "check_url": "https://www.searchapi.io/api/v1/usage",
        "low_threshold": 200,
    },
]

for api in API_REGISTRY:
    check_balance(api)
```

## Script skeleton

Every generated `script.py` follows this structure:

```python
"""
<one-line description of what this script does>

Schedule: <recommended cron / interval>
"""
import os
from datetime import datetime
from pyrunner_datastore import DataStore
# other imports...

# ──────────────────────────────────────────────
# CONFIGURATION — edit these to customize
# ──────────────────────────────────────────────
RECIPIENT_EMAIL = "you@example.com"
SENDER_EMAIL = "PyRunner <alerts@yourdomain.com>"
THRESHOLD = 100
# ...

# ──────────────────────────────────────────────
# Setup
# ──────────────────────────────────────────────
store = DataStore("my_script_namespace")

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────
def send_email(subject: str, html: str, text: str) -> None:
    """Send a multipart email via Resend."""
    ...

# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────
def main() -> None:
    print(f"[INFO] Starting at {datetime.now().isoformat()}")
    # ... work ...
    print("[OK] Done")

if __name__ == "__main__":
    main()
```

Keep all user-editable values in the CONFIG block. Helpers go above `main()`. Wrap risky calls (HTTP, file I/O, AI calls) in try/except with logged errors — a single transient failure should not crash the whole run unless it has to.

## Educational commenting

The audience includes beginners reading these scripts to learn. Comment **intent**, not syntax.

Good:
```python
# Store the last seen ID so the next run only processes new items.
last_seen = store.get("last_seen_id")
```

Bad (just restates what the code says):
```python
# Get last_seen_id from store
last_seen = store.get("last_seen_id")
```

Add a short docstring to every function explaining *why* it exists, not just *what* it does.

## README format

Always produce a README with this section order:

```markdown
# <Script Name>

<2-3 sentence description of what the script does and when it runs.>

## What it does

- Concrete bullet 1 (e.g., "Fetches your Stripe balance once per day")
- Concrete bullet 2 (e.g., "Sends a low-balance alert if under $1000")
- Concrete bullet 3 (e.g., "Suppresses repeat alerts until balance recovers")

## Required secrets

Add these in the PyRunner Secrets Manager:

| Secret | Description |
|---|---|
| `RESEND_API_KEY` | Resend API key for sending emails |
| `STRIPE_API_KEY` | Stripe secret key (read-only is fine) |

## Required packages

See `requirements.txt`. Install via PyRunner's virtual environment feature.

## Configuration

Edit these constants at the top of `script.py`:

- `RECIPIENT_EMAIL` — where alerts are sent
- `THRESHOLD` — balance below which alerts fire

## Schedule

Recommended: **daily at 9:00 AM** (or whatever fits the task).

## DataStore keys used

- `alert_state:low_balance` → `{sent_at, balance}` — set when alert fires, deleted on recovery
```

## requirements.txt format

One package per line. No version pins unless required.

```
resend
requests
openai
```

## Quality checklist (verify before delivering)

- Reads every secret from `os.environ` — nothing hardcoded
- Uses `DataStore` for any state that crosses runs
- Logs progress with `[INFO]/[OK]/[WARN]/[ERROR]` prefixes
- Has a CONFIG block of edit-me constants at the top
- Wraps risky calls in try/except with logged errors
- Emails use multipart HTML + text, table-based HTML, no emojis in subjects
- Alerts won't double-fire (uses the smart alerting pattern when applicable)
- Comments explain *intent*, not syntax
- README lists every secret, every package, the schedule, and the DataStore keys
- `requirements.txt` is minimal — only what's actually imported
