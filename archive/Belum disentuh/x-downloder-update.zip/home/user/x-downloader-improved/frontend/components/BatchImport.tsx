"use client";

import React, { useState } from 'react';
import { X } from 'lucide-react';
import { toast } from 'sonner';

interface BatchImportProps {
  onClose: () => void;
  onStartBatch: (urls: string[], quality: string, cookies: string) => void;
}

export default function BatchImport({ onClose, onStartBatch }: BatchImportProps) {
  const [urlsText, setUrlsText] = useState('');
  const [quality, setQuality] = useState('best');
  const [cookies, setCookies] = useState('none');

  const handleStart = () => {
    const urls = urlsText
      .split('\n')
      .map(u => u.trim())
      .filter(u => u.length > 5 && u.startsWith('http'));

    if (urls.length === 0) {
      toast.error("Please enter at least one valid URL");
      return;
    }

    onStartBatch(urls, quality, cookies);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[200] p-4" onClick={onClose}>
      <div className="glass border border-white/10 rounded-3xl w-full max-w-2xl" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-5 border-b border-white/10 flex justify-between">
          <div className="font-semibold text-xl">Batch Import</div>
          <button onClick={onClose}><X /></button>
        </div>

        <div className="p-6 space-y-5">
          <div>
            <div className="text-sm text-white/60 mb-2">Paste multiple URLs (one per line)</div>
            <textarea
              value={urlsText}
              onChange={(e) => setUrlsText(e.target.value)}
              placeholder="https://pornhub.com/...
https://missav.com/..."
              className="w-full h-48 bg-zinc-900 border border-white/10 rounded-2xl p-4 font-mono text-sm resize-y"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-white/60 mb-1.5">Quality</div>
              <select value={quality} onChange={e => setQuality(e.target.value)} className="w-full bg-zinc-900 border border-white/10 px-4 py-3 rounded-2xl">
                <option value="best">Best</option>
                <option value="1080p">1080p</option>
                <option value="720p">720p</option>
                <option value="audio">Audio only</option>
              </select>
            </div>
            <div>
              <div className="text-sm text-white/60 mb-1.5">Cookies</div>
              <select value={cookies} onChange={e => setCookies(e.target.value)} className="w-full bg-zinc-900 border border-white/10 px-4 py-3 rounded-2xl">
                <option value="none">None</option>
                <option value="chrome">Chrome</option>
                <option value="firefox">Firefox</option>
              </select>
            </div>
          </div>
        </div>

        <div className="px-6 py-5 border-t border-white/10 flex justify-end gap-3">
          <button onClick={onClose} className="px-6 py-2.5 rounded-2xl hover:bg-white/5">Cancel</button>
          <button 
            onClick={handleStart}
            className="px-8 py-2.5 bg-white text-black font-medium rounded-2xl"
          >
            Start Batch Download
          </button>
        </div>
      </div>
    </div>
  );
}
