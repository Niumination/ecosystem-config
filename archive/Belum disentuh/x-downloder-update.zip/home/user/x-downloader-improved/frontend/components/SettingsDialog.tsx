"use client";

import React, { useState } from 'react';
import { X, Folder, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settings: any;
  onSave: (settings: any) => void;
}

export default function SettingsDialog({ open, onOpenChange, settings, onSave }: SettingsDialogProps) {
  const [localSettings, setLocalSettings] = useState(settings);

  const handleSave = () => {
    onSave(localSettings);
    onOpenChange(false);
  };

  if (!open) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={() => onOpenChange(false)}>
        <motion.div 
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 10 }}
          transition={{ ease: [0.23, 1, 0.32, 1] }}
          className="glass w-full max-w-lg border border-white/10 rounded-3xl overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-7 pt-6 pb-4 border-b border-white/10 flex justify-between items-center">
            <div>
              <div className="font-semibold text-xl">Settings</div>
              <div className="text-xs text-white/50">Preferences &amp; behavior</div>
            </div>
            <button onClick={() => onOpenChange(false)} className="p-2 -mr-1 text-white/60 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-7 space-y-6 text-sm">
            {/* Output Directory */}
            <div>
              <div className="flex items-center gap-2 text-white/70 mb-2">
                <Folder className="w-4 h-4" /> Output Directory
              </div>
              <input 
                type="text" 
                value={localSettings.output_dir || ''} 
                onChange={(e) => setLocalSettings({...localSettings, output_dir: e.target.value})}
                className="w-full px-4 py-3 bg-zinc-900 border border-white/10 rounded-2xl focus:border-blue-500/50 outline-none"
              />
            </div>

            {/* Concurrent Downloads */}
            <div>
              <div className="flex justify-between mb-2">
                <div>Concurrent Downloads</div>
                <div className="font-mono text-blue-400">{localSettings.concurrent_downloads}</div>
              </div>
              <input 
                type="range" 
                min="1" 
                max="8" 
                step="1"
                value={localSettings.concurrent_downloads || 3}
                onChange={(e) => setLocalSettings({...localSettings, concurrent_downloads: parseInt(e.target.value)})}
                className="w-full accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-white/40 mt-1">
                <div>1</div><div>8</div>
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-4 pt-2">
              {[
                { label: "Embed metadata", key: "embed_metadata" },
                { label: "Embed thumbnail", key: "embed_thumbnail" },
                { label: "Auto-update yt-dlp", key: "auto_update_ytdlp" },
              ].map((item) => (
                <label key={item.key} className="flex items-center justify-between cursor-pointer group">
                  <div>{item.label}</div>
                  <div 
                    onClick={() => setLocalSettings({
                      ...localSettings, 
                      [item.key]: !localSettings[item.key]
                    })}
                    className={`w-10 h-6 rounded-full relative transition-all ${localSettings[item.key] ? 'bg-blue-600' : 'bg-white/10'} group-hover:ring-1 ring-white/20`}
                  >
                    <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all shadow ${localSettings[item.key] ? 'right-0.5' : 'left-0.5'}`} />
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className="px-7 py-5 bg-black/30 border-t border-white/10 flex justify-end gap-3">
            <button 
              onClick={() => onOpenChange(false)}
              className="px-6 py-2.5 text-sm rounded-2xl hover:bg-white/5 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              className="px-8 py-2.5 bg-white text-black text-sm font-medium rounded-2xl hover:bg-white/90 active:bg-white transition-all flex items-center gap-2"
            >
              Save Changes
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
