"use client";

import React, { useState } from 'react';
import { Play, X } from 'lucide-react';

interface FormatPreviewProps {
  url: string;
  onClose: () => void;
}

export default function FormatPreview({ url, onClose }: FormatPreviewProps) {
  const [loading, setLoading] = useState(false);
  const [formats, setFormats] = useState('');
  const [error, setError] = useState('');

  const fetchFormats = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`http://localhost:8000/api/preview-formats?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      
      if (data.success) {
        setFormats(data.formats);
      } else {
        setError(data.error || 'Failed to fetch formats');
      }
    } catch (e) {
      setError('Failed to connect to backend');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[200] p-4" onClick={onClose}>
      <div 
        className="glass border border-white/10 rounded-3xl w-full max-w-4xl max-h-[85vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <div>
            <div className="font-semibold">Format Preview</div>
            <div className="text-xs text-white/50 truncate max-w-[400px]">{url}</div>
          </div>
          <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6 flex-1 overflow-auto">
          {!formats && !error && (
            <div className="flex justify-center py-12">
              <button 
                onClick={fetchFormats} 
                disabled={loading}
                className="px-8 py-3 bg-white text-black rounded-2xl flex items-center gap-2 font-medium"
              >
                <Play className="w-4 h-4" /> {loading ? 'Fetching formats...' : 'Show Available Formats'}
              </button>
            </div>
          )}

          {error && <div className="text-red-400 p-4 bg-red-950/40 rounded-2xl">{error}</div>}

          {formats && (
            <pre className="text-xs font-mono bg-black/50 p-5 rounded-2xl overflow-auto whitespace-pre text-zinc-300 max-h-[60vh]">
              {formats}
            </pre>
          )}
        </div>

        <div className="px-6 py-4 border-t border-white/10 text-xs text-white/40">
          Tip: Copy format ID (e.g. 137) to use advanced options later.
        </div>
      </div>
    </div>
  );
}
