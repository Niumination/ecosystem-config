"use client";

import React from 'react';
import { motion } from 'framer-motion';
import { X, Trash2, CheckCircle, AlertCircle, Clock, Download } from 'lucide-react';

interface DownloadItem {
  id: number;
  url: string;
  title: string;
  site: string;
  quality: string;
  status: string;
  progress: number;
  speed: string;
  eta: string;
  filename: string;
  error: string;
}

interface QueueItemProps {
  item: DownloadItem;
  onCancel: () => void;
  onRemove: () => void;
  onPreview?: () => void;
}

export default function QueueItem({ item, onCancel, onRemove }: QueueItemProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'downloading': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'pending': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'error': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'cancelled': return 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20';
      default: return 'bg-zinc-500/10 text-zinc-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'error': return <AlertCircle className="w-4 h-4" />;
      case 'downloading': return <Download className="w-4 h-4 animate-pulse" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const isActive = ['downloading', 'pending'].includes(item.status);

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="download-row glass border border-white/10 rounded-2xl p-5 group"
    >
      <div className="flex items-center justify-between gap-5">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-1.5">
            <div className={`status-badge flex items-center gap-1.5 border ${getStatusColor(item.status)}`}>
              {getStatusIcon(item.status)}
              <span className="font-medium capitalize">{item.status}</span>
            </div>
            
            <div className="text-xs px-2.5 py-px rounded bg-white/5 text-white/60 font-mono tracking-widest">
              {item.site}
            </div>
            
            <div className="text-xs px-2.5 py-px rounded bg-white/5 text-white/60">
              {item.quality}
            </div>
          </div>

          <div className="font-medium text-lg tracking-tight truncate pr-8">
            {item.title || item.url}
          </div>
          
          <div className="text-xs text-white/40 mt-0.5 font-mono truncate">
            {item.url.length > 80 ? item.url.substring(0, 78) + '...' : item.url}
          </div>
        </div>

        <div className="flex items-center gap-5">
          {isActive && (
            <div className="w-40 text-right">
              <div className="flex justify-between items-baseline text-xs mb-1.5 font-mono">
                <div>{item.progress.toFixed(0)}%</div>
                <div className="text-white/40">{item.speed}</div>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${item.progress}%` }}
                  transition={{ ease: [0.23, 1.0, 0.32, 1] }}
                />
              </div>
              {item.eta && (
                <div className="text-[10px] text-white/50 mt-1 font-mono">ETA: {item.eta}</div>
              )}
            </div>
          )}

          {item.status === 'completed' && item.filename && (
            <div className="max-w-[240px] text-xs text-white/60 truncate font-mono pr-1">
              {item.filename}
            </div>
          )}

          <div className="flex gap-1 opacity-70 group-hover:opacity-100 transition-all">
            {item.status === 'downloading' && (
              <button onClick={onCancel} className="p-2.5 hover:bg-white/5 rounded-xl" title="Cancel">
                <X className="w-4 h-4" />
              </button>
            )}
            
            <button 
              onClick={onPreview}
              className="px-3 py-1.5 text-xs border border-white/10 rounded-xl hover:bg-white/5"
            >
              Preview
            </button>
            
            <button onClick={onRemove} className="p-2.5 hover:bg-white/5 rounded-xl text-white/40 hover:text-white/70" title="Remove">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {item.error && (
        <div className="mt-3 text-xs px-4 py-2 bg-red-950/60 text-red-400 rounded-xl border border-red-900/60">
          {item.error}
        </div>
      )}
    </motion.div>
  );
}
