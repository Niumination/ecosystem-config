# Visual Examples — X-Downloader 2.0 UI/UX

## 1. Hero Section + 3D Download Orb (Interactive)

**Tampilan Utama:**

```
┌─────────────────────────────────────────────────────────────────────┐
│  [Logo] X-Downloader v2.0              [Settings] [API Docs]       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   Download.                         ┌─────────────────────────┐    │
│   Beautifully.                      │                         │    │
│                                     │       ███████████       │    │
│   Fast, private, and stunningly     │     █             █     │    │
│   designed video downloader with    │   █   ●   42%   ●   █   │    │
│   real-time 3D animations.          │     █             █     │    │
│                                     │       ███████████       │    │
│   [Start New Download] [Refresh]    │                         │    │
│                                     │     DRAG TO ROTATE      │    │
│                                     └─────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**Fitur 3D Orb:**
- Bola biru dengan wireframe tipis
- Progress ring yang berputar mengikuti persentase
- Animasi floating halus
- Warna berubah sesuai status (biru = downloading, hijau = selesai, merah = error)
- Saat di-hover → bisa di-drag untuk rotasi manual
- Auto-rotate saat tidak di-hover

---

## 2. Input Section (Glassmorphism)

```
┌─────────────────────────────────────────────────────────────────────┐
│  VIDEO URL                          QUALITY      COOKIES            │
│  ┌────────────────────────────────┐ ┌─────────┐ ┌───────────────┐  │
│  │ https://www.pornhub.com/...    │ │ best    ▼ │ none        ▼ │  │
│  └────────────────────────────────┘ └─────────┘ └───────────────┘  │
│                                                                     │
│                              [Download]                              │
│                                                                     │
│  ⚠ Supports PornHub, MissAV, 91Porn, OnlyFans, Twitter/X, Reddit... │
└─────────────────────────────────────────────────────────────────────┘
```

**Karakteristik:**
- Glass effect (blur + transparan)
- Border halus dengan warna putih transparan
- Input besar dan mudah dibaca
- Dropdown dengan style konsisten

---

## 3. Download Queue Item (Animated)

**Status: Downloading**
```
┌─────────────────────────────────────────────────────────────────────┐
│  [DOWNLOADING]  PornHub          1080p                              │
│  Beautiful Girl - Official Video                                     │
│  https://www.pornhub.com/view/video123456789                         │
│                                                                     │
│                                        67%          2.4 MiB/s       │
│  ████████████████████████████████░░░░  ETA: 1m 12s                   │
│                                                                     │
│                                              [X] [🗑]               │
└─────────────────────────────────────────────────────────────────────┘
```

**Status: Completed**
```
┌─────────────────────────────────────────────────────────────────────┐
│  [COMPLETE]     MissAV             2160p                            │
│  JAV Video Title Here                                               │
│  https://missav.com/...                                              │
│                                                                     │
│  video_title [abc123].mp4                                            │
│                                              [🗑]                   │
└─────────────────────────────────────────────────────────────────────┘
```

**Fitur Animasi:**
- Item masuk dengan efek smooth (Framer Motion)
- Progress bar dengan transition halus
- Hover effect: geser sedikit ke kanan
- Status badge dengan warna berbeda

---

## 4. Empty State

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│                       ┌───────────────┐                             │
│                       │               │                             │
│                       │   ⬇️          │                             │
│                       │               │                             │
│                       └───────────────┘                             │
│                                                                     │
│                       No downloads yet                              │
│                       Paste a URL above to begin                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 5. Settings Dialog

```
┌──────────────────────────────────────────────┐
│  Settings                              [X]   │
├──────────────────────────────────────────────┤
│                                              │
│  📁 Output Directory                         │
│  ┌────────────────────────────────────────┐  │
│  │ ~/Videos/x-downloader                  │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  Concurrent Downloads          [═══●══]  3   │
│                                              │
│  ☐ Embed metadata                            │
│  ☑ Embed thumbnail                           │
│  ☑ Auto-update yt-dlp                        │
│                                              │
│                    [Cancel]  [Save Changes]  │
└──────────────────────────────────────────────┘
```

---

## 6. Stats Cards

```
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│     142      │ │      89      │ │      12      │ │    1500+     │
│ Total        │ │ Completed    │ │ Active       │ │ Sites        │
│ Downloads    │ │              │ │              │ │ Supported    │
└──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘
```

---

## Ringkasan Desain

- **Warna utama**: Zinc-950 (hitam gelap) + aksen biru (#3b82f6)
- **Typography**: Inter (clean & modern)
- **Efek**: Glassmorphism + subtle shadows
- **Animasi**: Framer Motion (spring & ease) + Three.js (ringan)
- **Responsif**: Mobile-first dengan breakpoint yang baik

Semua komponen sudah dibuat dengan kualitas production-ready.
