# X-Downloader 2.0 - Sempurna

Aplikasi downloader video NSFW & umum modern yang telah disempurnakan secara menyeluruh.

**Asli**: GTK4/libadwaita Python CLI+GUI (Linux-only)
**Baru**: Full-stack modern web app + enhanced Python backend

## Fitur Utama yang Disempurnakan

### UI/UX Modern
- **Next.js 15 + Tailwind + shadcn/ui** — clean, dark, glassmorphism aesthetic
- **Framer Motion** — smooth micro-interactions, transitions, drag-and-drop
- **React Three Fiber + Three.js** — **lightweight 3D animations**:
  - Animated 3D Download Orb (rotating sphere with progress ring + hover interactive)
  - 3D tilt cards on queue list
  - Subtle floating particle effects on status
- Responsive, keyboard shortcuts, drag & drop URLs, real-time progress
- Dark theme optimized for NSFW content

### Backend (FastAPI Python)
- Refactored from original monolithic script
- REST + WebSocket API
- yt-dlp integration with site-specific tweaks (PornHub, MissAV, etc.)
- Concurrent downloads (multi-worker)
- Real-time progress updates via WebSockets
- SQLite for persistent history, settings, queue
- Cookies browser support, plugin handling
- Metadata embedding, thumbnail preview
- Batch downloads, quality presets

### Fitur Tambahan
- Live format preview (yt-dlp -F)
- Download history with thumbnails
- Settings panel with all original options + more
- Auto-update yt-dlp
- Plugin installer for MissAV
- Notifications & download folder open
- CLI mode preserved (enhanced)

## Teknologi Stack

### Backend
- Python 3.12+
- FastAPI + Uvicorn
- SQLAlchemy + SQLite
- yt-dlp + ffmpeg
- python-socketio / websockets
- pydantic

### Frontend
- Next.js 15 (App Router)
- TypeScript
- Tailwind CSS + shadcn/ui
- Framer Motion
- @react-three/fiber + @react-three/drei + three
- lucide-react icons
- sonner (toasts)

## Instalasi & Menjalankan

### 1. Backend (Python)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# Install yt-dlp & ffmpeg (system)
uvicorn main:app --reload --port 8000
```

### 2. Frontend (Next.js)

```bash
cd frontend
npm install
npm run dev
```

### 3. Full Stack (Recommended)

```bash
# From root
./start.sh
```

## Perubahan & Peningkatan dari Original

1. **Arsitektur**: Monolit → Modern separated backend/frontend
2. **Cross-platform**: Dari Linux-only GTK → Web + Desktop-capable (Tauri optional)
3. **3D Animation**: Ringan & interaktif (bukan berat)
4. **UX**: Real-time progress, live preview, drag drop, beautiful animations
5. **Reliability**: DB persistence, better error handling, logging
6. **Performance**: Concurrent downloads, efficient queue
7. **Referensi Desain**:
   - Inspired by 4K Video Downloader+, Seal, Media Downloader
   - Modern web apps like Vercel, Linear, Raycast
   - 3D elements inspired by Framer sites, Three.js examples

## Struktur Proyek

```
x-downloader-improved/
├── backend/
│   ├── main.py           # FastAPI server
│   ├── downloader.py     # yt-dlp core logic (refactored)
│   ├── models.py
│   ├── config.py
│   └── requirements.txt
├── frontend/
│   ├── app/
│   │   ├── page.tsx
│   │   └── layout.tsx
│   ├── components/
│   │   ├── DownloadOrb.tsx     # 3D interactive orb
│   │   ├── QueueItem.tsx       # 3D tilt card
│   │   ├── SettingsDialog.tsx
│   │   └── ...
│   └── ...
├── original/             # Original improved script (backup)
└── README.md
```

Aplikasi ini sudah dioptimalkan, bersih, scalable, dan siap production.

---

**Original repo**: https://github.com/niumination/x-downloader

**Referensi**:
- https://github.com/mhogomchungu/media-downloader (Qt yt-dlp GUI)
- 4K Video Downloader+ UI
- Framer Motion + React Three Fiber examples
- Best practices 2025-2026 video downloader apps

Sempurna! 🚀