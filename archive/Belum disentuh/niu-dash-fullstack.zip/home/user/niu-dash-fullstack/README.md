# ⚡ NIU-DASH v3.0 — Fullstack Dark Nexus

**Modern Fullstack Project Dashboard** with **GitHub + Local separation**, **Interactive 3D**, **NextAuth**, **Kanban**, **Released & Ecosystem pages**, built with the most popular modern stack in 2026.

> Original repo: https://github.com/niumination/niu-dash

---

## ✨ Key Features (v3.0)

### 🗂️ **Source Separation (GitHub vs Local)**
- Projects are clearly divided into **2 major categories**:
  - **GitHub Projects** (`source: "github"`)
  - **Local Projects** (`source: "local"`)
- Sub-categories (`Ready`, `Dev`, `Ideas`, `Config`, `Legacy`) are preserved under each major source.

### 📄 **Separate Pages**
- **Dashboard** (Main feed with source filters)
- **Released** (Production-ready projects)
- **Ecosystem** (Tools & integrations)
- **Kanban Board** (Drag & drop status management)

### 🔐 **Authentication**
- **NextAuth** with GitHub OAuth
- Login page at `/auth/signin`
- User menu + logout in top bar

### 🎨 **Light / Dark Mode**
- Professional theme toggle in top bar
- Consistent styling across light and dark themes

### 🔄 **Real GitHub Sync**
- One-click sync with real GitHub API
- Auto-create/update projects from your GitHub repos

---

## 📸 Screenshots

### 1. Main Dashboard
![Dashboard](screenshots/dashboard.png)

### 2. GitHub vs Local Projects
![Source Filter](screenshots/source-filter.png)

### 3. Kanban Board
![Kanban](screenshots/kanban.png)

### 4. Login Page
![Login](screenshots/login.png)

### 5. Settings Page
![Settings](screenshots/settings.png)

### 6. Light Mode
![Light Mode](screenshots/light-mode.png)

> **To generate screenshots**, run the app and use browser dev tools or tools like **Puppeteer** / **Playwright**.

---

## 🚀 Getting Started

### 1. Clone & Install

```bash
git clone https://github.com/niumination/niu-dash.git
cd niu-dash
npm install
```

### 2. Environment Setup

Create `.env` from example:

```bash
cp .env.example .env
```

**Required variables**:

```env
# Database (Supabase / Neon / Local Postgres)
DATABASE_URL="postgresql://postgres:xxx@db.xxx.supabase.co:5432/postgres"

# GitHub OAuth (NextAuth)
GITHUB_ID=your_github_oauth_id
GITHUB_SECRET=your_github_oauth_secret

# GitHub Token (for real sync)
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 3. Setup Database

```bash
npx prisma migrate dev --name init
npx prisma generate
npm run db:seed
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🛠️ Available Scripts

```bash
npm run dev              # Development server
npm run build            # Production build
npm run start            # Production server
npm run db:seed          # Seed initial data
./scripts/deploy.sh      # Production deployment helper
```

---

## ☁️ Deploy to Vercel + Supabase (Recommended)

### Step-by-step:

1. **Push code** to GitHub
2. **Create Supabase project** → copy `DATABASE_URL`
3. Go to [Vercel](https://vercel.com)
4. Import your repo
5. Add environment variables:
   - `DATABASE_URL`
   - `GITHUB_ID`
   - `GITHUB_SECRET`
   - `GITHUB_TOKEN`
6. Deploy

**After deploy**, run migration on production:

```bash
npx prisma migrate deploy
npx prisma db seed
```

---

## 📁 Project Structure Highlights

```
app/
├── auth/signin/            # Login page
├── settings/               # Settings page
├── api/
│   ├── projects/
│   ├── github/sync/
│   ├── auth/[...nextauth]/
│   ├── released/
│   └── ecosystem/
components/
├── UserMenu.tsx            # User avatar + logout
├── ThemeToggle.tsx
├── KanbanBoard.tsx
├── ThreeBackground.tsx
prisma/
├── schema.prisma
└── seed.ts
scripts/
└── deploy.sh
```

---

## 🔐 Authentication Flow

- Login via GitHub at `/auth/signin`
- Session managed by NextAuth
- User info shown in top bar (`UserMenu`)
- Logout redirects back to login page

---

## 🧠 Architecture Decisions

- **Source separation** implemented at database level (`source` field)
- Separate pages for **Released** and **Ecosystem**
- Real GitHub sync uses authenticated API calls
- Theme provider using `next-themes`
- Professional glassmorphism + neon cyber design

---

## 📌 Roadmap / Next Steps

- [x] Source separation (GitHub vs Local)
- [x] NextAuth + Login page
- [x] Light/Dark mode
- [x] Deploy script
- [ ] Add project creation modal
- [ ] Real-time collaboration
- [ ] Activity timeline
- [ ] Mobile-first responsive improvements

---

**Built with ❤️ by Niumination • Aceh Tengah • 2026**

Original static version → Fullstack modern upgrade with 3D + separation logic + authentication.