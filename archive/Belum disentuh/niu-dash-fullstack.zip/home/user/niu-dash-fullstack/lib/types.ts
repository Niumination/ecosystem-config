export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  category: string;
  status: string;
  tags: string[];
  githubUrl: string | null;
  liveUrl: string | null;
  stars: number;
  forks: number;
  language: string | null;
  priority: number;
  tier: string | null;
  createdAt: string;
  updatedAt: string;
}

export type Category = 'All' | 'Ready' | 'Dev' | 'Ideas' | 'Config' | 'Legacy';
export type Status = 'All' | 'ACTIVE' | 'STAGING' | 'PAUSED' | 'DONE';

export interface ProjectFilters {
  category: Category;
  status: Status;
  search: string;
  sort: 'newest' | 'oldest' | 'az' | 'za' | 'stars';
}