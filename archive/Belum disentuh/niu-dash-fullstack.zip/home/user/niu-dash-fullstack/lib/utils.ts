import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('id-ID', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(new Date(date));
}

export function getStatusColor(status: string) {
  switch (status) {
    case 'ACTIVE': return 'text-emerald-400 border-emerald-400/30';
    case 'STAGING': return 'text-amber-400 border-amber-400/30';
    case 'PAUSED': return 'text-orange-400 border-orange-400/30';
    case 'DONE': return 'text-sky-400 border-sky-400/30';
    default: return 'text-zinc-400 border-zinc-400/30';
  }
}

export function getCategoryColor(category: string) {
  switch (category) {
    case 'Ready': return 'text-emerald-400';
    case 'Dev': return 'text-cyan-400';
    case 'Ideas': return 'text-amber-400';
    case 'Config': return 'text-violet-400';
    case 'Legacy': return 'text-zinc-400';
    default: return 'text-white';
  }
}

export function getCategoryIcon(category: string) {
  switch (category) {
    case 'Ready': return '⚡';
    case 'Dev': return '⟐';
    case 'Ideas': return '◇';
    case 'Config': return '⚙';
    case 'Legacy': return '◫';
    default: return '◈';
  }
}
