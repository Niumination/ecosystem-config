import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const githubProjects = [
  { name: "niu-private", description: "Document Vault & Kanban Project Board", category: "Ready", status: "DONE", source: "github", tags: ["TypeScript", "Vault", "Kanban"], githubUrl: "https://github.com/niumination/niu-private", stars: 6, forks: 1, language: "TypeScript", priority: 9, tier: "High" },
  { name: "ClaudeCode", description: "AI coding agent Python/Rust. Multi-provider LLM", category: "Dev", status: "ACTIVE", source: "github", tags: ["Python", "Rust", "AI", "LLM"], githubUrl: "https://github.com/niumination/claudecode", stars: 41, forks: 8, language: "Python", priority: 10, tier: "High" },
  { name: "Flame-ADE", description: "AI-native terminal emulator 7MB. Tauri + Rust + React", category: "Ready", status: "ACTIVE", source: "github", tags: ["Rust", "Tauri", "React", "AI"], githubUrl: "https://github.com/niumination/flame-ade", stars: 29, forks: 7, language: "Rust", priority: 10, tier: "High" },
  { name: "roboto_origin", description: "Fully Open-Source DIY Humanoid Robot", category: "Ideas", status: "STAGING", source: "github", tags: ["Robot", "Hardware", "DIY"], githubUrl: "https://github.com/niumination/roboto_origin", stars: 64, forks: 12, language: "Python", priority: 5, tier: "High" },
  { name: "Niumination-Portal", description: "React + Express. Dashboard IPD, task tracker, SPBE", category: "Ready", status: "ACTIVE", source: "github", tags: ["React", "Express", "Fullstack"], githubUrl: "https://github.com/niumination/niu-portal", stars: 11, forks: 2, language: "TypeScript", priority: 9, tier: "High" },
];

const localProjects = [
  { name: "Niu-LKH", description: "Laporan Kegiatan Harian - Afrizal Munthe", category: "Ready", status: "DONE", source: "local", tags: ["Web", "Laporan", "ASN", "React"], priority: 9, tier: "High" },
  { name: "PemdiAcehTengah", description: "Portal Pemetaan Proses Bisnis Aceh Tengah", category: "Ready", status: "DONE", source: "local", tags: ["Next.js", "GovTech"], priority: 10, tier: "High" },
  { name: "zaryu-terminal-dotfiles", description: "Terminal dotfiles — Zsh, Neovim, Tmux, Git", category: "Config", status: "DONE", source: "local", tags: ["Terminal", "Dotfiles", "Zsh"], priority: 8, tier: "High" },
  { name: "HermesV-Github", description: "Hermes Agent Portable on Github Codespace", category: "Dev", status: "ACTIVE", source: "local", tags: ["Hermes", "Codespace"], priority: 7, tier: "Medium" },
  { name: "Hackintosh ThinkPad X13", description: "Panduan optimasi Hackintosh ThinkPad X13 Yoga", category: "Config", status: "DONE", source: "local", tags: ["Hackintosh", "OpenCore"], priority: 6, tier: "Medium" },
];

async function main() {
  console.log('🌱 Seeding NIU-DASH v3...');

  // Clear existing data
  await prisma.project.deleteMany();

  // Seed GitHub projects
  for (const proj of githubProjects) {
    await prisma.project.create({
      data: {
        ...proj,
        slug: proj.name.toLowerCase().replace(/\s+/g, '-'),
      }
    });
  }

  // Seed Local projects
  for (const proj of localProjects) {
    await prisma.project.create({
      data: {
        ...proj,
        slug: proj.name.toLowerCase().replace(/\s+/g, '-'),
      }
    });
  }

  // Seed Released
  await prisma.releasedProject.createMany({
    data: [
      { name: "Niu-Dash", status: "production", repoName: "niu-dash", githubUrl: "https://github.com/niumination/niu-dash" },
      { name: "Flame-ADE", status: "production", repoName: "flame-ade" },
    ]
  });

  console.log('✅ Seeded successfully');
}

main().finally(() => prisma.$disconnect());
