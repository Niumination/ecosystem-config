#!/bin/bash

# NIU-DASH v3.0 — Production Deploy Script
# Usage: ./scripts/deploy.sh

set -e

echo "⚡ NIU-DASH v3.0 Deployment Script"
echo "=================================="

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}1. Building production...${NC}"
npm run build

echo -e "${BLUE}2. Running Prisma migration (production)...${NC}"
npx prisma migrate deploy

echo -e "${BLUE}3. Seeding database...${NC}"
npm run db:seed

echo -e "${GREEN}✅ Build & Migration complete!${NC}"

echo ""
echo -e "${YELLOW}Next steps for Vercel + Supabase:${NC}"
echo "1. Push to GitHub"
echo "2. Connect repo on Vercel"
echo "3. Add environment variables on Vercel:"
echo "   - DATABASE_URL"
echo "   - GITHUB_ID"
echo "   - GITHUB_SECRET"
echo "   - GITHUB_TOKEN"
echo ""
echo -e "${GREEN}Ready for deployment!${NC}"