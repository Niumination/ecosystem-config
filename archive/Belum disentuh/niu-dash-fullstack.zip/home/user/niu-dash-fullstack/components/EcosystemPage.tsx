"use client";

import React from 'react';
import { useQuery } from '@tanstack/react-query';

export default function EcosystemPage() {
  const { data: ecosystem = [] } = useQuery({
    queryKey: ['ecosystem'],
    queryFn: async () => {
      const res = await fetch('/api/ecosystem');
      return res.json();
    },
  });

  return (
    <div>
      <div className="mb-8">
        <div className="text-4xl font-semibold tracking-[-1.2px]">Ecosystem</div>
        <div className="text-white/50 mt-1">Tools, services, and integrations in the Niumination ecosystem</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {ecosystem.length === 0 && (
          <div className="col-span-full text-center py-16 text-white/40">Ecosystem data will appear here.</div>
        )}
        {ecosystem.map((item: any) => (
          <div key={item.id} className="glass border border-white/10 p-6 rounded-3xl">
            <div className="font-semibold">{item.name}</div>
            <div className="text-sm text-white/60 mt-1">{item.description}</div>
            <div className="mt-4 text-xs px-3 py-1 rounded bg-white/5 inline-block">{item.type}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
