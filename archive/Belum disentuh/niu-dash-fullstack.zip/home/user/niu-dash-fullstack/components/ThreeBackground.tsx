"use client";

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Stars, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

function Particles() {
  const pointsRef = useRef<THREE.Points>(null!);
  
  const positions = useMemo(() => {
    const count = 280;
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count * 3; i += 3) {
      pos[i] = (Math.random() - 0.5) * 48;
      pos[i + 1] = (Math.random() - 0.5) * 26;
      pos[i + 2] = (Math.random() - 0.5) * 38;
    }
    return pos;
  }, []);

  const colors = useMemo(() => {
    const col = new Float32Array(positions.length);
    for (let i = 0; i < col.length; i += 3) {
      col[i] = 0.0;
      col[i + 1] = 0.94;
      col[i + 2] = 1.0;
    }
    return col;
  }, [positions.length]);

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.018;
      pointsRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.03) * 0.1;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={colors.length / 3}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.035}
        vertexColors
        transparent
        opacity={0.85}
        sizeAttenuation
      />
    </points>
  );
}

function FloatingCubes() {
  const groupRef = useRef<THREE.Group>(null!);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.04;
    }
  });

  const cubes = useMemo(() => {
    return Array.from({ length: 5 }).map((_, i) => ({
      position: [
        (i - 2) * 7 + (Math.random() - 0.5) * 3,
        Math.random() * 7 - 2,
        Math.random() * -18 - 8,
      ] as [number, number, number],
      scale: 0.6 + Math.random() * 0.6,
    }));
  }, []);

  return (
    <group ref={groupRef}>
      {cubes.map((cube, index) => (
        <mesh key={index} position={cube.position} scale={cube.scale}>
          <boxGeometry args={[1.1, 1.1, 1.1]} />
          <meshBasicMaterial 
            color="#00f0ff" 
            transparent 
            opacity={0.06} 
            wireframe 
          />
        </mesh>
      ))}
    </group>
  );
}

export default function ThreeBackground() {
  return (
    <div className="absolute inset-0 z-0 opacity-70">
      <Canvas
        camera={{ position: [0, 2, 22], fov: 55 }}
        style={{ background: 'transparent' }}
      >
        <ambientLight intensity={0.1} />
        <Particles />
        <FloatingCubes />
        <Stars 
          radius={90} 
          depth={40} 
          count={180} 
          factor={3} 
          saturation={0} 
          fade 
          speed={0.6}
        />
      </Canvas>
    </div>
  );
}
