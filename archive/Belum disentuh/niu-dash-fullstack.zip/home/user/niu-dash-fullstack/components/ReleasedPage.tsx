"use client";

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { ExternalLink, Github } from 'lucide-react';

export default function ReleasedPage() {
  const { data: released = [], isLoading } = useQuery({
    queryKey: ['released'],
    queryFn: async () => {
      const res = await fetch('/api/released');
      return res.json();
    },
  });

  return (
    <div>
      <div className="mb-8">
        <div className="text-4xl font-semibold tracking-[-1.2px]">Released Projects</div>
        <div className="text-white/50 mt-1">Production-ready &amp; completed projects</div>
      </div>

      {isLoading ? (
        <div className="text-white/40">Loading released projects...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {released.length === 0 && (
            <div className="col-span-full text-center py-12 text-white/40">No released projects yet.</div>
          )}

          {released.map((proj: any) => (
            <div key={proj.id} className="glass border border-white/10 rounded-3xl p-6">
              <div className="font-semibold text-lg mb-1 tracking-tight">{proj.name}</div>
              <div className="text-xs text-emerald-400 mb-4 font-mono tracking-[1px]">{proj.status?.toUpperCase()}</div>

              <div className="text-sm text-white/70 mb-5 line-clamp-3">
                {proj.notes || "Production ready project."}
              </div>

              <div className="flex gap-2">
                {proj.githubUrl && (
                  <a href={proj.githubUrl} target="_blank" className="text-xs flex items-center gap-1.5 px-3 py-1.5 border border-white/10 rounded-full hover:bg-white/5">
                    <Github className="w-3.5 h-3.5" /> GitHub
                  </a>
                )}
                {proj.liveUrl && (
                  <a href={proj.liveUrl} target="_blank" className="text-xs flex items-center gap-1.5 px-3 py-1.5 border border-white/10 rounded-full hover:bg-white/5">
                    <ExternalLink className="w-3.5 h-3.5" /> Live Site
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
