"use client";

import { useSession, signOut } from "next-auth/react";
import { LogOut, User, Settings } from "lucide-react";
import { useState } from "react";

export function UserMenu() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);

  if (!session) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-2xl border border-white/10 hover:bg-white/5 transition-all"
      >
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#00f0ff] to-[#c084fc] flex items-center justify-center text-xs font-medium text-black">
          {session.user?.name?.[0] || "U"}
        </div>
        <div className="text-sm font-medium pr-1 hidden md:block">
          {session.user?.name?.split(" ")[0] || "User"}
        </div>
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-56 glass border border-white/10 rounded-2xl py-1 shadow-xl z-50">
          <div className="px-4 py-3 border-b border-white/10">
            <div className="font-medium">{session.user?.name}</div>
            <div className="text-xs text-white/50">{session.user?.email}</div>
          </div>

          <a href="/settings" className="flex items-center gap-3 px-4 py-3 text-sm hover:bg-white/5">
            <Settings className="w-4 h-4" /> Settings
          </a>

          <button
            onClick={() => signOut({ callbackUrl: "/auth/signin" })}
            className="flex w-full items-center gap-3 px-4 py-3 text-sm text-red-400 hover:bg-white/5"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      )}
    </div>
  );
}
