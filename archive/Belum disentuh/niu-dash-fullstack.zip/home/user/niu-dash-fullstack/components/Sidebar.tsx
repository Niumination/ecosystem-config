"use client";

import React from 'react';
import { 
  Zap, Play, Clock, Pause, Star, 
  Filter, RefreshCw, Github, HardDrive 
} from 'lucide-react';

interface SidebarProps {
  stats: any;
  categoryFilter: string;
  setCategoryFilter: (val: any) => void;
  statusFilter: string;
  setStatusFilter: (val: any) => void;
  sourceFilter: 'all' | 'github' | 'local';
  setSourceFilter: (val: any) => void;
  sortBy: string;
  setSortBy: (val: any) => void;
  onSync: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({
  stats,
  categoryFilter,
  setCategoryFilter,
  statusFilter,
  setStatusFilter,
  sourceFilter,
  setSourceFilter,
  sortBy,
  setSortBy,
  onSync,
  activeTab,
  setActiveTab
}: SidebarProps) {
  const categories = [
    { label: 'All', value: 'All', count: stats.total, icon: '◈' },
    { label: 'Ready', value: 'Ready', count: stats.ready, icon: '⚡' },
    { label: 'Dev', value: 'Dev', count: stats.dev, icon: '⟐' },
    { label: 'Ideas', value: 'Ideas', count: stats.ideas, icon: '◇' },
    { label: 'Config', value: 'Config', count: stats.config, icon: '⚙' },
  ];

  const statuses = ['All', 'ACTIVE', 'STAGING', 'PAUSED', 'DONE'];

  return (
    <div className="w-72 border-r border-white/10 bg-[#050508]/95 backdrop-blur-xl flex flex-col h-full overflow-y-auto sidebar">
      <div className="p-8 pt-7">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00f0ff] to-[#c084fc] flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <div className="font-mono text-xl tracking-[-1.5px] font-semibold">NIU⚡DASH</div>
              <div className="text-[10px] text-white/40 -mt-1">v3.0 FULLSTACK</div>
            </div>
          </div>
        </div>

        {/* Main Tabs */}
        <div className="mb-8">
          <div className="text-xs tracking-[1.5px] text-white/40 mb-3">VIEWS</div>
          <div className="flex flex-col gap-px">
            {[
              { id: 'dashboard', label: 'Dashboard' },
              { id: 'released', label: 'Released' },
              { id: 'ecosystem', label: 'Ecosystem' },
              { id: 'kanban', label: 'Kanban Board' },
            ].map(tab => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 text-sm text-left rounded-2xl transition-all flex items-center gap-2 ${activeTab === tab.id ? 'bg-white/10 text-[#00f0ff]' : 'hover:bg-white/5 text-white/70'}`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Source Filter (GitHub vs Local) */}
        <div className="mb-7">
          <div className="text-xs tracking-[1.5px] text-white/40 mb-3">SOURCE</div>
          <div className="flex gap-2">
            {[
              { label: 'All', value: 'all', icon: <Filter className="w-3 h-3" /> },
              { label: 'GitHub', value: 'github', icon: <Github className="w-3 h-3" /> },
              { label: 'Local', value: 'local', icon: <HardDrive className="w-3 h-3" /> },
            ].map((s) => (
              <button
                key={s.value}
                onClick={() => setSourceFilter(s.value)}
                className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs rounded-2xl border transition-all ${
                  sourceFilter === s.value 
                    ? 'bg-[#00f0ff] text-black border-[#00f0ff]' 
                    : 'border-white/20 hover:bg-white/5'
                }`}
              >
                {s.icon} {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Filters */}
        <div className="mb-7">
          <div className="text-xs tracking-[1.5px] text-white/40 mb-3">CATEGORIES</div>
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setCategoryFilter(cat.value)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl mb-px text-sm transition-all ${categoryFilter === cat.value ? 'bg-white/10 text-[#00f0ff]' : 'text-white/70 hover:bg-white/5'}`}
            >
              <div className="flex items-center gap-3">
                <span className="text-lg w-5">{cat.icon}</span> {cat.label}
              </div>
              <div className="font-mono text-xs opacity-60">{cat.count}</div>
            </button>
          ))}
        </div>

        {/* Status */}
        <div className="mb-7">
          <div className="text-xs tracking-[1.5px] text-white/40 mb-3">STATUS</div>
          <div className="flex flex-wrap gap-1.5">
            {statuses.map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1 text-xs rounded-full border transition-all ${statusFilter === s ? 'bg-white text-black border-white' : 'border-white/20 hover:bg-white/5'}`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div>
          <button 
            onClick={onSync}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl border border-white/10 hover:bg-white/5 text-sm mb-2"
          >
            <RefreshCw className="w-4 h-4" /> SYNC GITHUB REPOS
          </button>
        </div>
      </div>
    </div>
  );
}
