"use client";

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, ExternalLink, Github, Star, GitBranch, Calendar, Edit2 } from 'lucide-react';
import { Project } from '@/lib/types';
import { getCategoryIcon, getStatusColor, getCategoryColor, formatDate } from '@/lib/utils';
import { toast } from 'sonner';

interface DetailPanelProps {
  project: Project;
  onClose: () => void;
  onUpdate: () => void;
}

export default function DetailPanel({ project, onClose, onUpdate }: DetailPanelProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [status, setStatus] = useState(project.status);

  const handleStatusUpdate = async (newStatus: string) => {
    try {
      const res = await fetch(`/api/projects/${project.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        setStatus(newStatus);
        onUpdate();
        toast.success(`Status updated to ${newStatus}`);
      }
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  return (
    <motion.div
      initial={{ x: 60, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 60, opacity: 0 }}
      transition={{ type: "spring", bounce: 0.02, duration: 0.3 }}
      className="w-[400px] border-l border-white/10 bg-[#0a0a0f]/95 backdrop-blur-2xl overflow-y-auto detail-panel flex-shrink-0 z-50"
    >
      <div className="sticky top-0 z-10 px-7 pt-7 pb-4 border-b border-white/10 bg-[#0a0a0f]/95 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="text-3xl opacity-75">{getCategoryIcon(project.category)}</div>
          <div>
            <div className="font-semibold text-xl tracking-[-0.5px]">{project.name}</div>
            <div className={`${getCategoryColor(project.category)} text-xs tracking-[2px] font-mono mt-px`}>
              {project.category} • {project.tier || 'Medium'} TIER
            </div>
          </div>
        </div>
        <button 
          onClick={onClose} 
          className="p-2 hover:bg-white/10 rounded-full transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="p-7 space-y-7">
        {/* Status + Quick Actions */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs tracking-widest text-white/40">CURRENT STATUS</div>
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="text-xs flex items-center gap-1 text-[#00f0ff] hover:underline"
            >
              <Edit2 className="w-3 h-3" /> EDIT
            </button>
          </div>
          
          <div className={`inline-flex px-4 py-1 rounded-full text-sm border font-medium ${getStatusColor(status)}`}>
            {status}
          </div>

          {isEditing && (
            <div className="mt-3 flex gap-1 flex-wrap">
              {['ACTIVE', 'STAGING', 'PAUSED', 'DONE'].map((s) => (
                <button 
                  key={s}
                  onClick={() => handleStatusUpdate(s)}
                  className="px-3 py-1 text-xs rounded-full border border-white/20 hover:bg-white/10"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Description */}
        <div>
          <div className="text-xs tracking-widest text-white/40 mb-2">DESCRIPTION</div>
          <div className="text-sm leading-relaxed text-white/90">
            {project.description || "No description available."}
          </div>
        </div>

        {/* Meta Info */}
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="glass p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-xs text-white/40 mb-1">
              <Calendar className="w-3.5 h-3.5" /> CREATED
            </div>
            <div className="font-mono text-sm">{formatDate(project.createdAt)}</div>
          </div>
          <div className="glass p-4 rounded-2xl">
            <div className="flex items-center gap-2 text-xs text-white/40 mb-1">
              <Star className="w-3.5 h-3.5" /> STATS
            </div>
            <div className="flex items-center gap-4 font-mono text-sm">
              <div>{project.stars} ★</div>
              <div>{project.forks} forks</div>
            </div>
          </div>
        </div>

        {/* Tags */}
        <div>
          <div className="text-xs tracking-widest text-white/40 mb-3">TAGS</div>
          <div className="flex flex-wrap gap-1.5">
            {project.tags.map((tag, idx) => (
              <div key={idx} className="tag px-3 py-px text-xs">{tag}</div>
            ))}
          </div>
        </div>

        {/* Language & GitHub */}
        <div className="space-y-4">
          {project.language && (
            <div>
              <div className="text-xs tracking-widest text-white/40 mb-1.5">PRIMARY LANGUAGE</div>
              <div className="font-mono text-[#00f0ff]">{project.language}</div>
            </div>
          )}

          <div className="flex flex-col gap-2">
            {project.githubUrl && (
              <a 
                href={project.githubUrl} 
                target="_blank" 
                className="flex items-center gap-3 px-4 py-3 rounded-2xl border border-white/10 hover:bg-white/5 text-sm transition-all group"
              >
                <Github className="w-4 h-4 group-hover:text-[#00f0ff]" /> 
                View on GitHub
                <ExternalLink className="ml-auto w-4 h-4" />
              </a>
            )}
            
            {project.liveUrl && (
              <a 
                href={project.liveUrl} 
                target="_blank" 
                className="flex items-center gap-3 px-4 py-3 rounded-2xl border border-[#00f0ff]/30 hover:bg-[#00f0ff]/10 text-sm transition-all group text-[#00f0ff]"
              >
                <ExternalLink className="w-4 h-4" /> 
                OPEN LIVE SITE
              </a>
            )}
          </div>
        </div>

        {/* Priority */}
        <div className="pt-2">
          <div className="flex items-center justify-between text-xs mb-2 text-white/50">
            <span>PRIORITY</span>
            <span className="font-mono">{project.priority}/10</span>
          </div>
          <div className="h-px bg-white/10 rounded">
            <div 
              className="h-px bg-gradient-to-r from-[#00f0ff] to-[#c084fc]" 
              style={{ width: `${project.priority * 10}%` }} 
            />
          </div>
        </div>
      </div>

      <div className="p-7 pt-2 border-t border-white/10 text-[10px] text-white/40 font-mono">
        PROJECT ID: {project.id.slice(0, 12)}... • LAST UPDATED {formatDate(project.updatedAt)}
      </div>
    </motion.div>
  );
}
