"use client";

import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Project } from '@/lib/types';
import { getCategoryIcon } from '@/lib/utils';
import { toast } from 'sonner';

interface KanbanBoardProps {
  projects: Project[];
  onUpdate: () => void;
}

const STATUSES = ['ACTIVE', 'STAGING', 'PAUSED', 'DONE'];

export default function KanbanBoard({ projects, onUpdate }: KanbanBoardProps) {
  const columns = STATUSES.map(status => ({
    id: status,
    title: status,
    projects: projects.filter(p => p.status === status),
  }));

  const onDragEnd = async (result: any) => {
    const { destination, source, draggableId } = result;
    
    if (!destination) return;
    if (destination.droppableId === source.droppableId) return;

    const projectId = draggableId;
    const newStatus = destination.droppableId;

    try {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (res.ok) {
        toast.success(`Moved to ${newStatus}`);
        onUpdate();
      }
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div>
      <div className="mb-6">
        <div className="text-2xl font-semibold tracking-tight">Kanban Board</div>
        <div className="text-white/50 text-sm">Drag &amp; drop projects between status columns</div>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((column) => (
            <div key={column.id} className="kanban-column">
              <div className="mb-3 px-1 flex justify-between items-center">
                <div className="font-medium flex items-center gap-2 text-sm">
                  {column.title}
                  <span className="text-xs px-2 py-px rounded bg-white/10">{column.projects.length}</span>
                </div>
              </div>

              <Droppable droppableId={column.id}>
                {(provided) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className="bg-[#0a0a0f] border border-white/10 rounded-3xl p-3 min-h-[600px]"
                  >
                    {column.projects.map((project, index) => (
                      <Draggable key={project.id} draggableId={project.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className="kanban-card glass border border-white/10 rounded-2xl p-4 mb-3 cursor-grab active:cursor-grabbing"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="text-lg">{getCategoryIcon(project.category)}</div>
                              <div className="text-[10px] px-2 py-px bg-white/10 rounded font-mono tracking-widest">
                                {project.source?.toUpperCase() || 'LOCAL'}
                              </div>
                            </div>
                            
                            <div className="font-semibold text-sm tracking-tight leading-tight mb-1 pr-2">
                              {project.name}
                            </div>
                            
                            <div className="text-xs text-white/60 line-clamp-2">
                              {project.description}
                            </div>
                            
                            <div className="flex justify-between items-center mt-4 text-[10px] text-white/50">
                              <div>{project.stars} ★</div>
                              <div className="font-mono">{project.language}</div>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>
    </div>
  );
}
