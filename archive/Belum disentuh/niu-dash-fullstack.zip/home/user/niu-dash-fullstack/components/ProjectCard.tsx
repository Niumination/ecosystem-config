"use client";

import React from 'react';
import { motion } from 'framer-motion';
import { Star, GitBranch } from 'lucide-react';
import { Project } from '@/lib/types';
import { getCategoryIcon, getStatusColor, getCategoryColor } from '@/lib/utils';

interface ProjectCardProps {
  project: Project;
  onClick: () => void;
  index: number;
}

export default function ProjectCard({ project, onClick, index }: ProjectCardProps) {
  const sourceBadge = project.source === 'github' 
    ? { label: 'GH', color: 'bg-[#00f0ff]/10 text-[#00f0ff] border-[#00f0ff]/30' } 
    : { label: 'LOCAL', color: 'bg-amber-500/10 text-amber-400 border-amber-500/30' };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ delay: Math.min(index * 0.012, 0.3) }}
      onClick={onClick}
      className="project-card group glass border border-white/10 hover:border-[#00f0ff]/30 rounded-3xl p-6 cursor-pointer flex flex-col h-full"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="text-3xl opacity-90 group-hover:scale-110 transition-transform">
            {getCategoryIcon(project.category)}
          </div>
          <div>
            <div className="font-semibold text-[15.5px] tracking-[-0.25px] group-hover:text-[#00f0ff] transition-colors pr-2">
              {project.name}
            </div>
            <div className={`text-[10px] font-mono tracking-[1.8px] mt-px ${getCategoryColor(project.category)}`}>
              {project.category.toUpperCase()}
            </div>
          </div>
        </div>

        <div className={`px-3 py-px text-[10px] rounded-full border font-mono tracking-wider flex-shrink-0 ${getStatusColor(project.status)}`}>
          {project.status}
        </div>
      </div>

      {/* Description */}
      <div className="flex-1 text-sm text-white/75 leading-snug line-clamp-3 mb-5 pr-1">
        {project.description || "No description provided."}
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5 mb-5">
        {project.tags?.slice(0, 4).map((tag, idx) => (
          <div key={idx} className="tag text-[10px] px-2.5 py-px rounded-md">
            {tag}
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-white/10 text-xs">
        <div className="flex items-center gap-4 text-white/60">
          <div className="flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5" /> {project.stars}
          </div>
          <div className="flex items-center gap-1.5">
            <GitBranch className="w-3.5 h-3.5" /> {project.forks}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="font-mono text-[10px] text-white/50">{project.language}</div>
          <div className={`px-2 py-px text-[9px] rounded font-mono tracking-widest border ${sourceBadge.color}`}>
            {sourceBadge.label}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
