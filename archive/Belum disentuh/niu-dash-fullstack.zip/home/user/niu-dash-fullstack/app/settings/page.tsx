"use client";

import { useSession } from "next-auth/react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default function SettingsPage() {
  const { data: session } = useSession();

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/60">Please sign in to access settings.</p>
          <Link href="/auth/signin" className="text-[#00f0ff] mt-2 inline-block">Go to Login</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050508] text-white">
      <div className="max-w-4xl mx-auto px-8 pt-12 pb-20">
        <div className="flex items-center gap-4 mb-10">
          <Link href="/" className="flex items-center gap-2 text-sm text-white/60 hover:text-white">
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Link>
        </div>

        <div className="mb-12">
          <div className="text-4xl font-semibold tracking-tight">Settings</div>
          <p className="text-white/50 mt-2">Manage your account and preferences</p>
        </div>

        {/* Profile Section */}
        <div className="glass border border-white/10 rounded-3xl p-8 mb-8">
          <div className="text-sm tracking-[1.5px] text-white/40 mb-4">PROFILE</div>
          
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#00f0ff] to-[#c084fc] flex items-center justify-center text-3xl font-medium text-black">
              {session.user?.name?.[0] || "U"}
            </div>
            
            <div>
              <div className="text-2xl font-semibold">{session.user?.name}</div>
              <div className="text-white/60">{session.user?.email}</div>
              <div className="text-xs mt-1 px-3 py-0.5 bg-white/10 rounded inline-block">GitHub Connected</div>
            </div>
          </div>
        </div>

        {/* Preferences */}
        <div className="glass border border-white/10 rounded-3xl p-8">
          <div className="text-sm tracking-[1.5px] text-white/40 mb-4">PREFERENCES</div>
          
          <div className="flex items-center justify-between py-4 border-b border-white/10">
            <div>
              <div className="font-medium">Theme</div>
              <div className="text-sm text-white/60">Switch between light and dark mode</div>
            </div>
            <ThemeToggle />
          </div>

          <div className="flex items-center justify-between py-4">
            <div>
              <div className="font-medium">GitHub Sync</div>
              <div className="text-sm text-white/60">Auto-sync projects from GitHub</div>
            </div>
            <div className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">Enabled</div>
          </div>
        </div>

        <div className="mt-10 text-xs text-white/40 text-center">
          NIU⚡DASH v3.0 • Built with ❤️ in Aceh Tengah
        </div>
      </div>
    </div>
  );
}
