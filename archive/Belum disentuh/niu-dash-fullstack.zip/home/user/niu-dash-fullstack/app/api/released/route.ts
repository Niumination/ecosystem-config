import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  const released = await prisma.releasedProject.findMany({ orderBy: { dateMarked: 'desc' } });
  return NextResponse.json(released);
}

export async function POST(req: Request) {
  const body = await req.json();
  const item = await prisma.releasedProject.create({ data: body });
  return NextResponse.json(item);
}
