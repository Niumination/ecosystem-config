import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  const items = await prisma.ecosystemItem.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json(items);
}
