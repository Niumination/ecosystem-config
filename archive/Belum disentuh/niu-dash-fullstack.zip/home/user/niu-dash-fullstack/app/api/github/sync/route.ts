import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST() {
  try {
    const token = process.env.GITHUB_TOKEN;
    
    if (!token) {
      return NextResponse.json({ 
        error: 'GitHub token not configured' 
      }, { status: 400 });
    }

    // Fetch repos from GitHub
    const res = await fetch('https://api.github.com/users/Niumination/repos?per_page=100&sort=updated', {
      headers: {
        Authorization: `token ${token}`,
        Accept: 'application/vnd.github.v3+json',
      },
    });

    if (!res.ok) {
      throw new Error('Failed to fetch from GitHub');
    }

    const repos = await res.json();

    let newCount = 0;
    let updatedCount = 0;

    for (const repo of repos) {
      const existing = await prisma.project.findFirst({
        where: { githubUrl: repo.html_url }
      });

      const projectData = {
        name: repo.name,
        slug: repo.name.toLowerCase().replace(/\s+/g, '-'),
        description: repo.description || '',
        source: 'github',
        category: 'Dev', // default
        status: repo.archived ? 'PAUSED' : 'ACTIVE',
        tags: repo.topics || [],
        githubUrl: repo.html_url,
        stars: repo.stargazers_count,
        forks: repo.forks_count,
        language: repo.language,
        liveUrl: repo.homepage || null,
      };

      if (existing) {
        await prisma.project.update({
          where: { id: existing.id },
          data: projectData,
        });
        updatedCount++;
      } else {
        await prisma.project.create({
          data: {
            ...projectData,
            priority: 5,
            tier: 'Medium',
          },
        });
        newCount++;
      }
    }

    return NextResponse.json({
      success: true,
      new: newCount,
      updated: updatedCount,
      total: repos.length,
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ 
      error: 'GitHub sync failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
