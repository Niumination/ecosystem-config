"use client";

import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Github, HardDrive } from 'lucide-react';
import { toast } from 'sonner';
import { useSession } from 'next-auth/react';
import { UserMenu } from '@/components/UserMenu';

import ThreeBackground from '@/components/ThreeBackground';
import Sidebar from '@/components/Sidebar';
import ProjectCard from '@/components/ProjectCard';
import DetailPanel from '@/components/DetailPanel';
import KanbanBoard from '@/components/KanbanBoard';
import ReleasedPage from '@/components/ReleasedPage';
import EcosystemPage from '@/components/EcosystemPage';
import { ThemeToggle } from '@/components/ThemeToggle';

import { Project } from '@/lib/types';

export default function NiuDashV3() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'released' | 'ecosystem' | 'kanban'>('dashboard');
  
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | string>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | string>('All');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'github' | 'local'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'az' | 'stars'>('newest');

  // Fetch projects
  const { data: projects = [], isLoading, refetch } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const res = await fetch('/api/projects');
      return res.json();
    },
  });

  // Filtered projects
  const filteredProjects = React.useMemo(() => {
    let result = [...projects];

    if (sourceFilter !== 'all') {
      result = result.filter(p => p.source === sourceFilter);
    }
    if (categoryFilter !== 'All') {
      result = result.filter(p => p.category === categoryFilter);
    }
    if (statusFilter !== 'All') {
      result = result.filter(p => p.status === statusFilter);
    }
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        (p.description?.toLowerCase().includes(q)) ||
        p.tags?.some((t: string) => t.toLowerCase().includes(q))
      );
    }

    result.sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'az') return a.name.localeCompare(b.name);
      if (sortBy === 'stars') return b.stars - a.stars;
      return 0;
    });

    return result;
  }, [projects, sourceFilter, categoryFilter, statusFilter, search, sortBy]);

  const stats = React.useMemo(() => {
    const github = projects.filter((p: Project) => p.source === 'github');
    const local = projects.filter((p: Project) => p.source === 'local');

    return {
      total: projects.length,
      github: github.length,
      local: local.length,
      ready: projects.filter((p: Project) => p.category === 'Ready').length,
      dev: projects.filter((p: Project) => p.category === 'Dev').length,
      ideas: projects.filter((p: Project) => p.category === 'Ideas').length,
      config: projects.filter((p: Project) => p.category === 'Config').length,
      active: projects.filter((p: Project) => p.status === 'ACTIVE').length,
    };
  }, [projects]);

  const syncGitHub = async () => {
    try {
      const res = await fetch('/api/github/sync', { method: 'POST' });
      const data = await res.json();
      
      if (data.success) {
        toast.success(`GitHub Sync Complete`, {
          description: `${data.new} new • ${data.updated} updated`,
        });
        refetch();
      } else {
        toast.error(data.error || 'Sync failed');
      }
    } catch (e) {
      toast.error('GitHub sync error');
    }
  };

  return (
    <div className="min-h-screen bg-[#050508] text-white overflow-hidden relative">
      <div className="fixed inset-0 z-0 opacity-60">
        <ThreeBackground />
      </div>

      {/* Top Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-white/10 bg-[#050508]/95 backdrop-blur-2xl flex items-center px-8 justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-[#00f0ff] to-[#c084fc] flex items-center justify-center">
              <Zap className="w-5 h-5 text-black" />
            </div>
            <div>
              <div className="font-mono text-[21px] tracking-[-1.8px] font-semibold">NIU⚡DASH</div>
              <div className="text-[10px] text-white/40 -mt-1 tracking-[2px]">DARK NEXUS v3.0</div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm">
          <div className="px-4 py-1 rounded-full bg-white/5 text-xs border border-white/10 flex items-center gap-2 font-mono">
            {stats.total} PROJECTS
          </div>
          
          <ThemeToggle />

          <UserMenu />

          <button 
            onClick={syncGitHub}
            className="flex items-center gap-2 px-5 py-2 rounded-2xl border border-white/20 hover:bg-white/5 text-sm transition-all active:scale-[0.985]"
          >
            <Github className="w-4 h-4" /> SYNC GITHUB
          </button>
        </div>
      </div>

      <div className="flex pt-16 h-screen relative z-10">
        {/* Sidebar */}
        <Sidebar
          stats={stats}
          categoryFilter={categoryFilter}
          setCategoryFilter={setCategoryFilter}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          sourceFilter={sourceFilter}
          setSourceFilter={setSourceFilter}
          sortBy={sortBy}
          setSortBy={setSortBy}
          onSync={syncGitHub}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Search Bar */}
          {activeTab === 'dashboard' && (
            <div className="px-8 pt-6 pb-4 border-b border-white/10 bg-[#050508]/90">
              <div className="flex items-center gap-4">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search projects..."
                  className="flex-1 bg-[#121217] border border-white/10 focus:border-[#00f0ff]/60 px-5 py-3 rounded-2xl text-sm outline-none placeholder:text-white/40"
                />
                <div className="text-xs px-4 py-3 rounded-2xl border border-white/10 bg-white/5">
                  {filteredProjects.length} results
                </div>
              </div>
            </div>
          )}

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto px-8 py-6 relative">
            {activeTab === 'dashboard' && (
              <>
                {isLoading ? (
                  <div className="flex justify-center items-center h-96">
                    <div className="text-white/40">Loading projects...</div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4">
                    <AnimatePresence>
                      {filteredProjects.map((project: Project, idx) => (
                        <ProjectCard 
                          key={project.id} 
                          project={project} 
                          onClick={() => setSelectedProject(project)} 
                          index={idx} 
                        />
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </>
            )}

            {activeTab === 'kanban' && <KanbanBoard projects={projects} onUpdate={refetch} />}
            {activeTab === 'released' && <ReleasedPage />}
            {activeTab === 'ecosystem' && <EcosystemPage />}
          </div>
        </div>

        {/* Detail Panel */}
        <AnimatePresence>
          {selectedProject && activeTab === 'dashboard' && (
            <DetailPanel 
              project={selectedProject} 
              onClose={() => setSelectedProject(null)} 
              onUpdate={refetch} 
            />
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 z-50 h-9 border-t border-white/10 bg-[#050508]/95 text-[10px] font-mono flex items-center px-8 justify-between text-white/50">
        <div>NIUMINATION • FULLSTACK v3.0 • NEXT.JS + PRISMA + THREE.JS</div>
        <div>ACEH TENGAH • 2026</div>
      </div>
    </div>
  );
}
