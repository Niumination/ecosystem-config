"use client";

import { signIn } from "next-auth/react";
import { Github, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function SignIn() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050508] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(#1f2937_0.8px,transparent_1px)] bg-[length:4px_4px] opacity-40" />
      
      <div className="relative z-10 w-full max-w-md px-6">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#00f0ff] to-[#c084fc] mb-6">
            <span className="text-4xl">⚡</span>
          </div>
          <h1 className="text-4xl font-semibold tracking-[-1.5px]">NIU⚡DASH</h1>
          <p className="text-white/60 mt-2 tracking-wide">DARK NEXUS • v3.0</p>
        </div>

        <div className="glass border border-white/10 rounded-3xl p-8">
          <div className="text-center mb-8">
            <div className="text-xl font-medium tracking-tight">Welcome back</div>
            <p className="text-sm text-white/60 mt-2">Sign in to access your command center</p>
          </div>

          <button
            onClick={() => signIn("github", { callbackUrl: "/" })}
            className="w-full group flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-white text-black hover:bg-white/90 transition-all font-medium text-sm active:scale-[0.985]"
          >
            <Github className="w-5 h-5" />
            Continue with GitHub
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <div className="mt-6 text-center text-xs text-white/40">
            By signing in you agree to our Terms &amp; Privacy Policy
          </div>
        </div>

        <div className="text-center mt-8 text-xs text-white/40 tracking-[1px]">
          NIUMINATION • ACEH TENGAH
        </div>
      </div>
    </div>
  );
}
